/**
 * Created on Dec 13, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;


import jason.asSemantics.Unifier;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;


/**
 * @author meneguzzi
 *
 */
public class HTNExpander {
	private static final Logger logger = Logger.getLogger(HTNExpander.class.getName());
	
	/**
	 * A cache for the states after executing a primitive task, this one should be kept to the end of the algorithm.
	 */
	private final HashMap<Task, MultiState> resolvedTasks;
	/**
	 * A cache for mStateBefore, this one should be flushed constantly throughout execution
	 */
	private final HashMap<Task, MultiState> mStateBefore;
	private MultiState initialState;
	
	/**
	 * 
	 */
	public HTNExpander() {
		resolvedTasks = new HashMap<Task, MultiState>();
		mStateBefore = new HashMap<Task, MultiState>();
	}
	
	/**
	 * Creates a <i>fully expanded</i> HTN
	 * @param s0 The initial state of the problem 
	 * @param problem The network containing top level task to be expanded by the solver.
	 * @param domain The domain for the problem, with the methods to decompose 
	 *        <code>problem</code>.
	 * @return A fully decomposed {@link TaskNetwork} from which the plan can 
	 *         be extracted through {@link TaskNetwork#getOrderedTasks()}. 
	 *         
	 * Corresponds to Algorithm 2 in the AAMAS paper. 
	 */
	public TaskNetwork createFullyExpandedHTN(State s0, TaskNetwork problem, HTNDomain domain) {
		logger.info("Creating fully expanded HTN - (|) Method Expansion - (*) Operator Expansion");
		initialState = new MultiState(s0);
		return fullDecomposition(problem, domain);
	}
	
	/**
	 * Actual worker for {@link #createFullyExpandedHTN(State, TaskNetwork, HTNDomain)}.
	 * @param problem
	 * @param domain
	 * @return
	 */
	private final TaskNetwork fullDecomposition(TaskNetwork problem, HTNDomain domain) {
		//At this point we have finished expanding the HTN
		if(problem.allTasksArePrimitive() && getUnresolvedTask(problem) == null) {
			return problem;
		}
		Task t = getUnresolvedTask(problem);
		//Remove this print just for debugging purposes
		//debugPrintHTN(t, problem);
		if(t.isPrimitive()) {
			System.out.print("*");
			List<Operator> ops = findOperatorsFor(t, problem, domain, t.un);
			if(ops.isEmpty()) {
				throw new RuntimeException("No operators found for task "+t);
			}
			Operator active = ops.get(0);//domain.findOperatorsFor(t, t.un).get(0);
			t.op = active;
			if(active == null) {
				throw new RuntimeException("Tried to apply an invalid operator for task "+t);
			}
			
			//Here, we will have to compute the mState
			@SuppressWarnings("unused")
			MultiState possibleState = mState(t, problem);
			
			TaskNetwork nTn = fullDecomposition(problem, domain);
			if(nTn == null) {
				throw new RuntimeException("Could not continue to decompose network "+problem);
//				logger.warning("Could not continue to decompose network "+problem);
//				return null;
			} else {
				return nTn;
			}
			
		} else {
			System.out.print("|");
			Unifier un = new Unifier();
			
			Collection<MethodOption> active = findMethodsFor(t, problem, domain, un);
			if(active.isEmpty()) {
				throw new RuntimeException("No options found for task "+t+" in network "+problem);
//				logger.warning("No options found for task "+t+" in network "+problem);
//				return null;
			}
			TaskNetwork network = deltaStar(problem, t, active, false, domain);
			
			return fullDecomposition(network, domain);
		}
	}
	
	/**
	 * Returns all applicable operators for {@link Task} <code>t</code>
	 * @param t
	 * @param network
	 * @param domain
	 * @param u
	 * @return
	 */
	private final List<Operator> findOperatorsFor(Task t, TaskNetwork network, HTNDomain domain, Unifier u) {
		assert(t.isPrimitive());
		List<Operator> options = new ArrayList<Operator>();
		MultiState ms = mStateBefore(t,network);
		
		for(State s:ms) {
			options.addAll(domain.findOperatorsFor(s, t, u));
		}
		
		return options;
	}
	
	/**
	 * 
	 * @param t
	 * @param network
	 * @param domain
	 * @param u
	 * @return
	 */
	private final Collection<MethodOption> findMethodsFor(Task t, TaskNetwork network, HTNDomain domain, Unifier u) {
		List<MethodOption> options = new ArrayList<MethodOption>();
		MultiState ms = mStateBefore(t,network);
		for(State s:ms) {
			for(MethodOption o:domain.findMethodsFor(t, s, u)) {
				//We need to check that the same option has not been generated from a previous state
				if(!options.contains(o)) {
					options.add(o);
				}
			}
			//options.addAll(opt);
		}
		//---
//		List<MethodOption> options = domain.findMethodsFor(t, u);
		return options;
	}
	
	/**
	 * Expands the HTN using all possible applicable methods
	 * @param problem
	 * @param task
	 * @param methods
	 * @param domain 
	 */
	protected void expandWithAllMethodsInPlace(TaskNetwork problem, Task task, List<MethodOption> methods, HTNDomain domain) {
		deltaStar(problem,task,methods,true, domain);
	}
	
	/**
	 * 
	 * @param network
	 * @param task
	 * @param options
	 * @param domain 
	 * @return
	 */
	protected TaskNetwork expandWithAllMethods(TaskNetwork network, Task task, List<MethodOption> options, HTNDomain domain) {
		return deltaStar(network, task, options, false, domain);
	}
	
	/**
	 * 
	 * @param network
	 * @param task
	 * @param options
	 * @param inPlace
	 * @param domain 
	 * @return
	 */
	private final TaskNetwork deltaStar(TaskNetwork network, Task task, Collection<MethodOption> options, boolean inPlace, HTNDomain domain) {
		assert(network.hasTask(task));
		
		if(!inPlace) {
			network = new TaskNetwork(network);
		}
		
		List<Constraint> constraintsAfter = network.findConstraintsWithTaskAfter(task);
		List<Constraint> constraintsBefore = network.findConstraintsWithTaskBefore(task);
		network.removeTask(task);
		//--- Added with mStateBefore
		mStateBefore.remove(task);
		//---
		
		for(MethodOption mo:options) {
			assert(mo.m.getTask().equals(task));
			//logger.info("Expanding task '"+task+"' with method '"+mo.m+"'");
			TaskNetwork subst = mo.m.getInstantiatedTaskNetwork(domain, mo.un);
			
			for(Task t:subst.getTasks()) {
				network.addTask(t);
			}
			
			for(Constraint c:constraintsBefore) {
				network.addBeforeConstraint(subst.getLastTask(), c.getTask2());
			}
			
			for(Constraint c:constraintsAfter) {
				//We only add a precedence constraint to tasks whose possible states (pState(s0, c.task1, network)) support this method
				if(mState(c.task1,network).supports(mo.m.precond, mo.un)) {
					network.addBeforeConstraint(c.getTask1(), subst.getFirstTask());
				}
			}
			network.addConstraints(subst.constraints);
		}
		
		return network;
	}
	
	/**
	 * Returns the possible states at the specified task in the fully expanded HTN.
	 * @param task
	 * @return
	 */
	public HashMap<Task,MultiState> getMStates() {
		return resolvedTasks;
	}
	
	/**
	 * Returns whether or not <code>task</code> is Resolved, a resolved state has had its mState calculated.
	 * @param t
	 * @return
	 */
	private boolean isResolved(Task task) {
		return resolvedTasks.containsKey(task);
	}
	
	/**
	 * Returns the next unresolved task in the network, an unresolved task has no possible state attached to it.
	 * @param network
	 * @return
	 */
	private final Task getUnresolvedTask(TaskNetwork network) {
		LinkedList<Task> tasks = network.getOrderedTasks();
		for(Task t:tasks) {
			if(!isResolved(t)) {
				return t;
			}
		}
		return null;
	}
	
	/**
	 * Returns the possible state at task
	 * @param task
	 * @return
	 */
	private final MultiState possibleState(Task task) {
		assert(task.isPrimitive());
		assert(isResolved(task));
		return resolvedTasks.get(task);
	}
	
	/**
	 * Returns all possible states at {@link Task} <code>t</code>, these possible states are the states
	 * <b>after</b> <code>t</code> has been fully executed, and thus should not be used in calculating
	 * the applicability of <code>t</code> in terms of its method preconditions.
	 * @param s0
	 * @param t
	 * @param h
	 * @return
	 */
	private final MultiState mState(Task t, TaskNetwork h) {
		MultiState msRes = null;
//		assert(t.isPrimitive());
		//If we have already calculated the preceding state, no need to do it again
		if(isResolved(t)) {
			msRes = possibleState(t);
		} else {
			//If this is one of the first possible tasks in the network, the preceding state can only be the initial state
			if(h.isUnpreceded(t)) {
				msRes = initialState.applyOperator(t.op, t.un);
			} else {
				List<Constraint> prec = h.findConstraintsWithTaskAfter(t);
				assert(!prec.isEmpty()); // This list should be empty given the previous condition
				msRes = new MultiState();
				for(Constraint c: prec) {
					//It seems in some situations just querying the possibleState directly won't work
//					MultiState prev = possibleState(c.task1);
					MultiState prev = mState(c.task1, h);
					msRes.addAll(prev.applyOperator(t.op, t.un));
				}
			}
			resolvedTasks.put(t, msRes);
		}
//		logger.info("mState for "+t+" is "+msRes);
		return msRes;
	}
	
	/**
	 * A helper method for the converter to create an initial state.
	 * @return
	 */
	MultiState getInitialState() {
		return initialState;
	}
	
	/**
	 * Returns the possible state immediately <b>before</b> {@link Task} <code>t</code>, this method relies on the
	 * correct left to right decomposition of tasks.
	 * @param t
	 * @param h
	 * @return
	 */
	private final MultiState mStateBefore(Task t, TaskNetwork h) {
		MultiState msRes = null;
		if(mStateBefore.containsKey(t)) {
			msRes = mStateBefore.get(msRes);
		} else {
			//If this is one of the first possible tasks in the network, the preceding state can only be the initial state
			if(h.isUnpreceded(t)) {
				msRes = initialState;
			} else {
				List<Constraint> prec = h.findConstraintsWithTaskAfter(t);
				assert(!prec.isEmpty()); // This list should be empty given the previous condition
				msRes = new MultiState();
				for(Constraint c: prec) {
					MultiState prev = mState(c.task1, h);
					msRes.addAll(prev);
				}
				mStateBefore.put(t, msRes);
			}
		}
//		logger.info("mState before "+t+" is "+msRes);
		return msRes;
	}
	
	
	int iteration=0;
	DecimalFormat df = new DecimalFormat("0000");
	/**
	 * Debug print the current state of the HTN.
	 * @param network
	 */
	@SuppressWarnings("unused")
	private void debugPrintHTN(Task t, TaskNetwork network) {
		try {
			FileWriter writer = new FileWriter("debugHTN"+df.format(iteration)+".dot");
			HTNDotConverter.printHTNDot(writer, network);
			iteration++;
			writer.close();
			if(iteration > 200) System.exit(0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Creates a <i>fully expanded</i> HTN. Work is delegated to 
	 * {@link #createFullyExpandedHTN(TaskNetwork, HTNDomain)}.
	 * @param topLevelTask The top level task to be expanded by the solver.
	 * @param domain The domain for the problem, with the methods to decompose 
	 *        <code>topLevelTask</code>.
	 * @return A fully decomposed {@link TaskNetwork} from which the plan can 
	 *         be extracted through {@link TaskNetwork#getOrderedTasks()}.
	 * @deprecated This algorithm will now be moved to {@link HTNExpander}
	 */
	public TaskNetwork createFullyExpandedHTN(Task topLevelTask, HTNDomain domain) {
		TaskNetwork tn = new TaskNetwork(new Task[] {topLevelTask}, new Constraint[]{});
		return createFullyExpandedHTN(tn, domain);
	}
	
	/**
	 * Creates a <i>fully expanded</i> HTN 
	 * @param problem The network containing top level task to be expanded by the solver.
	 * @param domain The domain for the problem, with the methods to decompose 
	 *        <code>problem</code>.
	 * @return A fully decomposed {@link TaskNetwork} from which the plan can 
	 *         be extracted through {@link TaskNetwork#getOrderedTasks()}. 
	 *         
	 * @deprecated This algorithm will now be moved to {@link HTNExpander}
	 */
	public TaskNetwork createFullyExpandedHTN(TaskNetwork problem, HTNDomain domain) {
		TaskNetwork solution = new TaskNetwork(problem);
		while(!solution.allTasksArePrimitive()) {
			Task taskToExpand = null;
			List<MethodOption> methods = null;
			for(Task task:solution.getOrderedTasks()) {
				if(!task.isPrimitive() && 
				   (methods = domain.findMethodsFor(task, new Unifier())).size() > 0) {
					taskToExpand = task;
					break;
				}
			}
			
			if(taskToExpand != null)  {
				expandWithAllMethodsInPlace(solution, taskToExpand, methods, domain);
				logger.fine("Expanded solution to: "+solution);
			} else {
				logger.info("Could not find a task to expand Task Network "+solution);
				return null;
			}
			
		}
		return solution;
	}
}
