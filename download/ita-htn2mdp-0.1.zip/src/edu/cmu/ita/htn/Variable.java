/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

/**
 * @author meneguzzi
 *
 */
public class Variable {
	
}
