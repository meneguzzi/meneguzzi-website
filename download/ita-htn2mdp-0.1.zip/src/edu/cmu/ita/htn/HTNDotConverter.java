/**
 * Created on Dec 17, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Collection;

/**
 * @author meneguzzi
 *
 */
class HTNDotConverter {
	
	public static String printHTNDot(Collection<Constraint> constraints) {
		StringWriter writer = new StringWriter();
		PrintWriter out = new PrintWriter(writer);
		
		out.println("digraph {");
		out.println(" size=\"8.5,11\";");
		
		for(Constraint c:constraints) {
			out.print("\""+c.task1+"\"");
			out.print(" -> ");
			out.print("\""+c.task2+"\"");
			out.println(";");
		}
		out.println("}");
		
		out.flush();
		return writer.toString();
	}
	
	public static void printHTNDot(Writer writer, TaskNetwork network) {
		PrintWriter out = new PrintWriter(writer);
		
		out.println("digraph {");
		out.println(" size=\"8.5,11\";");
		
		for(Constraint c:network.constraints) {
			out.print("\""+c.task2+"\"");
			out.print(" -> ");
			out.print("\""+c.task1+"\"");
			out.println(";");
		}
		out.println("}");
		
		out.flush();
	}
}
