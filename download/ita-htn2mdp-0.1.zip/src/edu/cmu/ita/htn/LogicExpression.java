/**
 * Created on Jan 6, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import jason.asSemantics.Unifier;

/**
 * A logic expression, used primarily in the preconditions for Operators and Methods
 * @author meneguzzi
 *
 */
public interface LogicExpression {
	public static final List<Unifier> EMPTY_UNIF_LIST = Collections.emptyList();
	
	/**
	 * Returns whether or not this expression is a logical consequence of 
	 * state <code>s</code>, returning all possible unifiers for this consequence.
	 * @param s
	 * @param un
	 * @return
	 */
	public Iterator<Unifier> consequence(State s, Unifier un);
	
	/**
	 * 
	 * @return
	 */
	public boolean isUnary();
	
	/**
	 * Applies the unifier to this LogicExpression
	 * @param u
	 * @return
	 */
	public boolean apply(Unifier u);
	
	/**
	 * Returns all the {@link Proposition}s in this {@link LogicExpression}, care must be taken 
	 * given the number of objects created in the process.
	 * @return
	 */
	public Collection<Proposition> getPropositions();
	
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	public Object clone() ;
}
