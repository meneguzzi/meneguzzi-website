/**
 * Created on Dec 13, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.util.Iterator;

import jason.asSemantics.Unifier;
import jason.asSyntax.ASSyntax;
import jason.asSyntax.Literal;
import jason.asSyntax.Structure;

/**
 * @author meneguzzi
 *
 */
public class Operator extends Structure {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected LogicExpression preconds;
	protected State effects;
	
	protected double cost;
	
	public Operator(Operator op) {
		super(op);
		this.preconds = (LogicExpression) op.preconds.clone();
		this.effects = new State(op.effects);
		this.cost = op.cost;
	}
	
	/**
	 * A simple constructor for operators
	 * @param functor
	 */
	public Operator(String sOperator, LogicExpression preconds, State effects) throws Exception {
		this(ASSyntax.parseLiteral(sOperator),preconds, effects);
	}
	
	/**
	 * A simple constructor for operators
	 * @param functor
	 */
	public Operator(String sOperator, LogicExpression preconds, State effects, double cost) throws Exception {
		this(ASSyntax.parseLiteral(sOperator),preconds, effects, cost);
	}
	
	/**
	 * 
	 * @param lit
	 * @param preconds
	 * @param effects
	 */
	public Operator(Literal lit, LogicExpression preconds, State effects) {
		this(lit,preconds, effects, 0);
	}
	
	/**
	 * 
	 * @param lit
	 * @param preconds
	 * @param effects
	 * @param cost
	 */
	public Operator(Literal lit, LogicExpression preconds, State effects, double cost) {
		super(lit);
		this.preconds = (LogicExpression) preconds.clone();
		this.effects = new State(effects);
		this.cost = cost;
	}
	
	/**
	 * Returns the head of this operator (the invocation)
	 * @return
	 */
	public Structure getHead() {
		return new Structure(this);
	}

	public LogicExpression getPreconditions() {
		return preconds;
	}
	
	public State getEffects() {
		return effects;
	}
	
	/**
	 * Returns whether or not this operator is applicable to {@link State} <code>s0</code>.
	 * @param s0
	 * @return
	 */
	public boolean applicable(State s0) {
		Iterator<Unifier> iu = preconds.consequence(s0, new Unifier());
		return iu!= null && iu.hasNext();
	}
	
	/**
	 * 
	 * @param s0
	 * @param un
	 * @return
	 */
	final State applyOperator(State s0) {
		State sP = new State(s0);
		
		assert(applicable(s0));
		
		for(Proposition p:effects) {
			if(p.negated()) {
				sP.remove(p.getNegated());
				sP.add(p);
			} else {
				sP.add(p);
			}
		}
		
		assert(s0.isConsistent());
		
		return sP;
	}
	
	/**
	 * Creates an instance of this operator
	 * @param u
	 * @return
	 */
	public Operator instantiateOperator(Unifier u) throws Exception {
		Operator instance = new Operator(this);
		if(instance.apply(u)) {
			return instance;
		} else {
			throw new Exception("Cannot instantiate "+this+" with unifier "+u);
		}
	}
	
	/* (non-Javadoc)
	 * @see jason.asSyntax.Structure#apply(jason.asSemantics.Unifier)
	 */
	@Override
	public final boolean apply(Unifier u) {
		if(super.apply(u)) {
			boolean applied = false;
			applied = preconds.apply(u);
			if(!effects.isGround()) {
				applied |= effects.apply(u);
			}
			return applied;
		} else {
			return false;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public final double getCost() {
		return cost;
	}
	
	public final String getHeadToString() {
		return super.toString();
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append(super.toString());
		sb.append(":pre"+preconds.toString());
		sb.append(":eff"+effects.toString());
		
		return sb.toString();
	}
}
