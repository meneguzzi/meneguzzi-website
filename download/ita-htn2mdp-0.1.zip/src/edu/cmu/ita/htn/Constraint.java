/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;


/**
 * Represents a constraint on a task network, indicating that a 
 * {@link Task} task1 must be executed before a {@link Task} task2. 
 * @author meneguzzi
 *
 */
public class Constraint {
	protected Task task1, task2; 	

	public Constraint(Task task1, Task task2) {
		this.task1 = task1;
		this.task2 = task2;
	}

	public final Task getTask1() {
		return task1;
	}
	
	public final Task getTask2() {
		return task2;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "("+task1+" << "+task2+")";
	}
}
