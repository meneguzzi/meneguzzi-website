/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

/**
 * @author meneguzzi
 *
 */
public class TaskNetwork implements Comparator<Task>, Iterable<Task> {
	protected LinkedList<Task> orderedTasks;
	
	protected HashSet<Constraint> constraints;
	protected List<Task> tasks;
	
	/**
	 * 
	 */
	public TaskNetwork() {
		this.constraints = new HashSet<Constraint>();
		this.tasks = new ArrayList<Task>();
		this.orderedTasks = new LinkedList<Task>();
	}
	
	/**
	 * Creates a task network that assumes the elements in it are in full order (and creates constraints to this effect)
	 * @param tasks
	 */
	public TaskNetwork(Task tasks[]) {
		this();
		this.addTasks(tasks);
		this.orderedTasks.addAll(this.tasks);
		for(int i=0; i < tasks.length-1 ; i++) {
			this.addBeforeConstraint(tasks[i], tasks[i+1]);
		}
	}
	
	/**
	 * 
	 * @param tasks
	 * @param consts
	 */
	public TaskNetwork(Task tasks[], Constraint consts[]) {
		this();
		this.addConstraints(consts);
		this.addTasks(tasks);
	}
	
	/**
	 * Copy constructor
	 * @param network
	 */
	public TaskNetwork(TaskNetwork network) {
		this.constraints = new HashSet<Constraint>(network.constraints);
		this.tasks = new ArrayList<Task>(network.tasks);
		this.orderedTasks = new LinkedList<Task>();
		this.orderedTasks.addAll(tasks);
	}
	
	/**
	 * Returns whether or not this TaskNetwork is empty
	 * @return
	 */
	public final boolean isEmpty() {
		return tasks.isEmpty();
	}
	
	/**
	 * Returns all tasks in this network (for manipulation by the solver).
	 * @return
	 */
	public final List<Task> getTasks() {
		return tasks;
	}
	
	/**
	 * Removes the specified task from the network as well as any constraints referring to this task.
	 * 
	 * @param task
	 * @return
	 */
	public boolean removeTask(Task task) {
		if(tasks.remove(task)) {
			removeConstraintsAbout(task);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Removes all constraints regarding the specified task
	 * @param task
	 */
	private final void removeConstraintsAbout(Task task) {
		for(Iterator<Constraint> i = this.constraints.iterator(); i.hasNext(); ) {
			Constraint c = i.next();
			if(c.task1 == task || c.task2 == task) {
				i.remove();
			}
		}
	}
	
	public boolean removeConstraint(Constraint c) {
		return constraints.remove(c);
	}
	
	/**
	 * Returns the first task in this network
	 * @return
	 */
	public Task getFirstTask() {
		return getOrderedTasks().getFirst();
	}
	
	/**
	 * Returns the last task in this network
	 * @return
	 */
	public Task getLastTask() {
		return getOrderedTasks().getLast();
	}
	
	/**
	 * Returns whether or not all tasks in this HTN are primitive
	 * @return
	 */
	public boolean allTasksArePrimitive() {
		for(Task t: tasks) {
			if(!t.isPrimitive()) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Helper method
	 * @param tasks
	 */
	public void addTasks(Task ... tasks) {
		for(Task t:tasks) {
			this.tasks.add(t);
		}
		this.orderedTasks.clear();
	}
	
	/**
	 * Helper method
	 * @param tasks
	 */
	final void addTasks(List<Task> tasks) {
		this.tasks.addAll(tasks);
		this.orderedTasks.clear();
	}
	
	/**
	 * Adds a new task to this network.
	 * @param t
	 */
	public void addTask(Task t) {
		this.tasks.add(t);
		this.orderedTasks.clear();
	}
	
	/**
	 * Helper method
	 * @param consts
	 */
	public final void addConstraints(Constraint ... consts) {
		for(Constraint c: consts) {
			this.constraints.add(c);
		}
		this.orderedTasks.clear();
	}
	
	/**
	 * Helper method
	 * @param consts
	 */
	public final void addConstraints(Collection<Constraint> consts) {
		for(Constraint c: consts) {
			this.constraints.add(c);
		}
		this.orderedTasks.clear();
	}
	
	/**
	 * Adds a precedence constraint determining that {@link Task} task1 is to 
	 * be executed before {@link Task} task2.
	 * @param task1
	 * @param task2
	 */
	public void addBeforeConstraint(Task task1, Task task2) {
		this.addConstraint(new Constraint(task1, task2));
	}
	
	/**
	 * Adds a constraint 
	 * @param constraint
	 */
	public void addConstraint(Constraint constraint) {
		this.constraints.add(constraint);
		this.orderedTasks.clear();
	}
	
	/**
	 * Returns the set of tasks, ordered by the constraints in this HTN
	 * @return
	 */
	public LinkedList<Task> getOrderedTasks() {
		if(orderedTasks.size() != tasks.size()) {
			topologicalSort();
		}
		return orderedTasks;
	}
	
	/**
	 * 
	 * @param task
	 * @return
	 */
	public boolean hasTask(Task task) {
		for(Task t:tasks) {
			if(t.equals(task))
				return true;
		}
		return false;
	}
	
	/**
	 * Returns all constraints in which {@Task t} is the task to be executed 
	 * <i>before</i> some task.
	 * TODO optimize this method using hashing
	 * @param t
	 * @return
	 */
	public final List<Constraint> findConstraintsWithTaskBefore(Task t) {
		List<Constraint> relConsts = new ArrayList<Constraint>();
		for(Constraint c:constraints) {
			if(c.getTask1().equals(t)) {
				relConsts.add(c);
			}
		}
		return relConsts;
	}
	
	/**
	 * Returns all constraints in which {@Task t} is the task to be executed 
	 * <i>after</i> some task.
	 * TODO optimize this method using hashing
	 * @param t
	 * @return
	 */
	public final List<Constraint> findConstraintsWithTaskAfter(Task t) {
		List<Constraint> relConsts = new ArrayList<Constraint>();
		for(Constraint c:constraints) {
			if(c.task2.equals(t)) {
				relConsts.add(c);
			}
		}
		return relConsts;
	}
	
	/**
	 * Removes all <code>constraints</code> from this task network.
	 * @param constraints
	 */
	final void removeConstraints(List<Constraint> constraints) {
		for(Constraint c:constraints) {
			this.removeConstraint(c);
		}
	}
	
	/**
	 * Returns the length of the shortest path between <code>t1</code> and <code>t2</code>, 
	 * or -1 if no such path exists.
	 * @param t1
	 * @param t2
	 * @return
	 */
	public int minpath(Task t1, Task t2) {
		return minpath(t1, t2, new TreeSet<Task>());
	}
	
	/**
	 * Returns the length of the shortest path between <code>t1</code> and <code>t2</code> 
	 * keeping track of which tasks have been visited already, or -1 if no such path exists.
	 * @param t1
	 * @param t2
	 * @param visited
	 * @return
	 */
	private final int minpath(Task t1, Task t2, TreeSet<Task> visited) {
		if(t1.equals(t2)) {
			return 0;
		} else {
			List<Constraint> consts = findConstraintsWithTaskAfter(t2);
			for(Constraint c : consts) {
				if(c.task1.equals(t1)) {
					return 1;
				}
			}
			visited.add(t2);
			int best = -1;
			for(Constraint c : consts) {
				int l = minpath(t1, c.task1);
				if(l != -1 && l < best) {
					best = l;
				}
			}
			return (best == -1)? -1 : best+1; 
		}
	}
	
	/**
	 * Returns the longest length of path between <code>t1</code> and <code>t2</code>, 
	 * or -1 if no path exists.
	 * @param t1
	 * @param t2
	 * @return
	 */
	public int maxpath(Task t1, Task t2) {
		return maxpath(t1, t2, new TreeSet<Task>());
	}
	
	/**
	 * Returns the longest length of path between <code>t1</code> and <code>t2</code>, 
	 * keeping track of which tasks have been visited already, or -1 if no path
	 * exists.
	 * 
	 * @param t1
	 * @param t2
	 * @param visited
	 * @return
	 */
	private final int maxpath(Task t1, Task t2, TreeSet<Task> visited) {
		if(t1.equals(t2)) {
			return 0;
		} else {
			List<Constraint> consts = findConstraintsWithTaskAfter(t2);
			for(Constraint c : consts) {
				if(c.task1.equals(t1)) {
					return 1;
				}
			}
			visited.add(t2);
			int best = -1;
			for(Constraint c : consts) {
				int l = maxpath(t1, c.task1);
				if(l > best) {
					best = l;
				}
			}
			return (best == -1)? -1 : best+1; 
		}
	}
	
	/**
	 * Returns the (minimum) number of tasks that separate {@Task task1} from 
	 * {@Task task2}, assuming that task1 comes before task1, if the result 
	 * is 1 then task1 is immediately before task2. If task1 is not before task2
	 * then return -1.
	 * 
	 * TODO Make sure to check for loops and other problems with this search
	 * TODO Optimize this horribly inefficient algorithm
	 * @param task1
	 * @param task2
	 * @return
	 */
	protected final int tasksBefore(Task task1, Task task2) {
		if(task1.equals(task2))
			return 0;
		
		List<Constraint> consts = findConstraintsWithTaskBefore(task1);
		for(Constraint c:consts) {
			if(c.task2.equals(task2)) {
				return 1;
			}
		}
		
		int tasksBefore = -1;
		for(Constraint c:consts) {
			int tb = tasksBefore(c.getTask2(),task2); 
			tasksBefore = ((tasksBefore == -1) || (tb != -1 && tasksBefore > tb)) ? tb : tasksBefore;
		}
		
		return (tasksBefore != -1)? tasksBefore+1 : -1;
	}
	
	/**
	 * Returns a task that has no other tasks before it.
	 * @return
	 */
	public Task getUnpreceededTask() {
		List<Task> lTasks = (orderedTasks.size() == tasks.size())?orderedTasks:tasks;
		for(Task t:lTasks) { //If a task has any constraint referring to it as a successor, then we skip it
			for(Constraint c:constraints) {
				if(c.task2.equals(t)) {
					t = null;
					break;
				}
			}
			if(t!= null) {
				return t;
			}
		}
		return null;
	}
	
	/**
	 * Returns a list with all tasks that have no preceding tasks. 
	 * We should use this to determine when to use the initial state.
	 * This and the previous method would be better off if placed in an iterator (to avoid repetition of code) 
	 * A preliminary implementation is in {@link UnprecededTasksIterator}, test that iterator before replacing this method.
	 * @return
	 */
	public Collection<Task> getUnpreceededTasks() {
		Collection<Task> res = new LinkedList<Task>();
		for(Task t:tasks) {
			if(!hasPreceding(t)) {
				res.add(t);
			}
		}
		return res;
	}
	
	/**
	 * Returns whether or not task t has preceding tasks
	 * @param t
	 * @return
	 */
	public boolean isUnpreceded(Task t) {
		return !hasPreceding(t);
	}
	
	/**
	 * Returns whether or not the task has any preceding tasks. 
	 * A task that has no preceding tasks is one of the first in the network.
	 * @param t
	 * @return
	 */
	private final boolean hasPreceding(Task t) {
		for(Constraint c:constraints) {
			if(c.task2.equals(t)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Find a task that has zero outgoing precedence edges.
	 * @param tasks
	 * @return
	 */
	private final Task findZeroDegreeTask(Collection<Task> tasks) {
		for(Task t:tasks) {
			if(findConstraintsWithTaskBefore(t).size()==0) {
				return t;
			}
		}
		return null;
	}
	
	//I keep this one here just to make it more efficient
	private final HashSet<Constraint> backupC = new HashSet<Constraint>();
//	private final HashSet<Task> remaining = new HashSet<Task>();
	private final List<Task> remaining = new ArrayList<Task>();
//	private final TreeSet<Task> remaining = new TreeSet<Task>();
	/**
	 * Uses a topological sorting algorithm to impose total order in the tasks of this network.
	 * @param task1
	 * @param task2
	 * @return
	 */
	private final List<Task> topologicalSort() {
		remaining.addAll(tasks);
		
		backupC.clear();
		backupC.addAll(constraints);
		
		while(!remaining.isEmpty()) {
			Task t = findZeroDegreeTask(remaining);
			assert(t!=null);
			if(t == null) {
				throw new RuntimeException("Trying to sort a cyclic graph "+backupC+" \n "+HTNDotConverter.printHTNDot(backupC));
			}
			orderedTasks.offerFirst(t);
			remaining.remove(t);
			this.removeConstraintsAbout(t);
//			this.removeConstraints(findConstraintsWithTaskAfter(t));
//			this.removeConstraints(findConstraintsWithTaskBefore(t));
		}
		
		this.constraints.addAll(backupC);
		
		return orderedTasks;
	}
	
	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 * TODO Review this method, we must consider when the constraints do not impose total order
	 */
	@Override
	public int compare(Task o1, Task o2) {
		if(o1 == o2) {
			return 0;
		} 
		int tb = tasksBefore(o1, o2);
		if(tb >= 0) {
			return -tb;
		} else {
			return tasksBefore(o2,o1);
		}
	}
	
	/**
	 * Returns the number of tasks in this TaskNetwork.	
	 * @return
	 */
	public final int size() {
		return tasks.size();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("TN \n Tasks:\n");
		for(Task t:getTasks()) {
			sb.append("\t"+t+"\n");
		}
		sb.append("Constraints:\n");
		for(Constraint c:constraints) {
			sb.append("\t"+c+"\n");
		}
		return sb.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Iterable#iterator()
	 */
	@Override
	public Iterator<Task> iterator() {
		return getOrderedTasks().iterator();
	}
	
	
	/**
	 * An iterator over the tasks that have no preceding tasks.
	 * @author meneguzzi
	 *
	 */
	protected class UnprecededTasksIterator implements Iterator<Task> {
		private Iterator<Task> iTasks;
		private Task currentTask = null;
		
		private UnprecededTasksIterator() {
			iTasks = getOrderedTasks().iterator();
		}

		/* (non-Javadoc)
		 * @see java.util.Iterator#hasNext()
		 */
		@Override
		public boolean hasNext() {
			if(iTasks != null) {
				
				if(currentTask != null) {
					return true;
				}
				
				while(iTasks.hasNext()) {
					currentTask = iTasks.next();
					for(Constraint c:constraints) {
						if(c.task2 == currentTask) { 
							//Since we are using the ordered set of tasks, once we find one task that has 
							//preceding tasks, all the remaining ones also must have preceding tasks
							currentTask = null;
							iTasks = null;
							break;
						}
					}
					if(currentTask != null) {
						return true;
					}
				}
				iTasks = null;
			}
			return false;
		}

		/* (non-Javadoc)
		 * @see java.util.Iterator#next()
		 */
		@Override
		public Task next() {
			Task nextTask = currentTask;
			currentTask = null;
			return nextTask;
		}

		/* (non-Javadoc)
		 * @see java.util.Iterator#remove()
		 */
		@Override
		public void remove() {
			throw new RuntimeException("Can't remove tasks with the ordered tasks iterator");
		}
		
	}
}
