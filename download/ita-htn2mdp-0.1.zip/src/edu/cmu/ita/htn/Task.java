/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import jason.asSemantics.Unifier;
import jason.asSyntax.ASSyntax;
import jason.asSyntax.Structure;
import jason.asSyntax.Term;

import java.util.Comparator;
import java.util.List;


/**
 * @author meneguzzi
 *
 */
public class Task extends Structure {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected boolean isInstance = false;
	
	protected Unifier un;
	
	protected int instanceCount = 1;
	
	protected Operator op;
	
//	protected State possibleState;
	
	
	/**
	 * 
	 * @param name
	 */
	public Task(String sTask) throws Exception {
		super(ASSyntax.parseLiteral(sTask));
		this.un = new Unifier();
	}
	
	/**
	 * 
	 */
	public Task(String functor, List<Term> parameters, State preconds) {
		super(functor);
		this.setTerms(parameters);
		this.un = new Unifier();
	}
	
	/**
	 * Copy constructor
	 * @param t
	 */
	protected Task(Task t) {
		super(t);
		this.instanceCount = t.instanceCount;
		this.op = (t.op != null)? (new Operator(t.op)) : null;
		this.un = new Unifier();
		this.un.compose(t.un);
//		this.possibleState = (t.possibleState != null)? (new State(t.possibleState)) : null ;
	}

	/**
	 * Returns whether or not this task is primitive (i.e. is an action)
	 * @return
	 */
	public final boolean isPrimitive() {
		return op!=null;
	}
	
//	/**
//	 * Returns whether or not this state has been resolved by having a possible state associated with it.
//	 * @return
//	 */
//	public final boolean isResolved() {
//		return possibleState != null;
//	}
	
	/**
	 * @return the name
	 */
	public final String getName() {
		return getFunctor();
	}
	
//	/**
//	 * Returns the possible state at the time this primitive task is executed
//	 * @return
//	 */
//	public State getPossibleState(State s0) {
//		if(this.possibleState == null) {
//			if(this.op == null) {
//				this.possibleState = s0;
//			} else {
//				this.possibleState = this.op.applyOperator(s0);
//			}
//		}
//		return this.possibleState;
//	}
	
	/**
	 * 
	 * @return
	 */
	public final Unifier getUnifier() {
		return un;
	}
	
	/* (non-Javadoc)
	 * @see jason.asSyntax.Structure#apply(jason.asSemantics.Unifier)
	 */
	@Override
	public boolean apply(Unifier u) {
		if(isInstance) {
			this.un.compose(u);
			if(isPrimitive()) {
				op.apply(un);
			}
			return super.apply(u);
		} else {
			return false;
		}
	}
	
	/**
	 * 
	 * @return
	 * @deprecated
	 */
	public Task instantiateTask(Unifier un) {
//		if(isInstance) {
//			throw new RuntimeException("Cannot instantiate a non-abstract task");
//		} else {
			Task tInstance = new Task(this);
			instanceCount++;
			tInstance.isInstance = true;
			tInstance.apply(un);
			return tInstance;
//		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 * TODO Make sure this will work when we add parameters
	 */
	@Override
	public boolean equals(Object obj) {
		if(this==obj) {
			return true;
		} else if(obj == null) {
			return false;
		} if(obj instanceof Task) {
			Task t1 = (Task) obj;
			if(this.isInstance && t1.isInstance) {
				//XXX Hack to make multiple instances work
				//return super.equals(t1) && this.instanceCount == t1.instanceCount;
				return this == t1;
			}
			return super.equals(t1);
		} else {
			return false;
		}
	}
	
	/* (non-Javadoc)
	 * @see jason.asSyntax.DefaultTerm#hashCode()
	 */
	@Override
	public int hashCode() {
		return calcHashCode();
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return super.toString()+((isInstance)?"<"+instanceCount+">":"")+(isPrimitive()?"[primitive]":"");
	}

	/**
	 * @return
	 */
	public String getActionName() {
		return super.toString();
	}
	
	/* (non-Javadoc)
	 * @see jason.asSyntax.Structure#calcHashCode()
	 */
	@Override
	protected int calcHashCode() {
		// TODO Auto-generated method stub
		//return ((isInstance)?(7 * instanceCount):0) + super.calcHashCode();
		return super.calcHashCode();
	}
	
	public static final Comparator<Task> comparator = new TaskNetwork(); 
	
	class TaskComparator implements Comparator<Task> {

		/* (non-Javadoc)
		 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
		 */
		@Override
		public int compare(Task o1, Task o2) {
			if(o1 == o2) {
				return 0;
			} else if(o1.equals(o2)) {
				return o1.instanceCount - o2.instanceCount;
			} else {
				return o1.toString().compareTo(o2.toString());
			}
		}
		
	}
}
