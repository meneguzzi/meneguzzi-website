/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import aima.core.probability.decision.MDP;
import aima.core.probability.decision.MDPPolicy;
import aima.core.probability.decision.MDPRewardFunction;
import aima.core.probability.decision.MDPSource;
import aima.core.probability.decision.MDPTransitionModel;
import edu.cmu.ita.htn.RunStats.Timer;
import edu.cmu.ita.htn.RunStats.TimerName;
import edu.cmu.ita.htn.parser.HTNParser;
import edu.cmu.ita.htn.parser.ParseException;
import edu.cmu.ita.mdp.TransitionMatrix;
import edu.cmu.ita.mdp.aima.MDPAction;
import edu.cmu.ita.mdp.aima.MDPSourceImpl;
import edu.cmu.ita.mdp.aima.MDPState;
import edu.cmu.ita.mdp.graph.MDPDotConverter;

/**
 * @author meneguzzi
 *
 */
public class TaskNetworkToMDP {
	
	private static final Logger logger = Logger.getLogger(TaskNetworkToMDP.class.getName());
	
	private MDPSource<MDPState, MDPAction> mdpSource;
	private TaskNetwork fullyExpanded;
	private RunStats stats;
	
	/**
	 * Converts the specified task network into an MDP and generates an optimal policy for that HTN
	 * @param s0
	 * @param problem
	 * @param htnDomain
	 * @param discountFactor
	 * @return
	 * @throws Exception
	 */
	public MDPPolicy<MDPState, MDPAction> convertHTNAndPlan(edu.cmu.ita.htn.State s0, TaskNetwork problem, HTNDomain htnDomain, double discountFactor) throws Exception {
		startTimer(TimerName.CONVERTER);
		mdpSource = convertTaskNetwork(s0, problem, htnDomain);
		endTimer(TimerName.CONVERTER);
		
		MDP<MDPState, MDPAction> mdp = mdpSource.asMdp();
		
		startTimer(TimerName.SOLVER);
		MDPPolicy<MDPState, MDPAction> policy = mdp.policyIteration(discountFactor);
		endTimer(TimerName.SOLVER);
		
		return policy;
	}
	
	/**
	 * XXX At some point we might want to convert the entire method library into an MDP without the notion of an initial state.
	 * @param topLevel
	 * @param htnDomain
	 * @param discountFactor
	 * @return
	 * @throws Exception
	 * 
	 * @deprecated 
	 */
	@SuppressWarnings("unused")
	private MDPSource<MDPState, MDPAction> convertTaskNetwork(Task topLevel, HTNDomain htnDomain, double discountFactor) throws Exception {
		return null;
	}
	
	/**
	 * Converts the HTN domain into an {@link MDPSource}
	 * @param s0
	 * @param network
	 * @param htnDomain
	 * @return
	 * @throws Exception
	 */
	public MDPSource<MDPState, MDPAction> convertTaskNetwork(edu.cmu.ita.htn.State s0, TaskNetwork network, HTNDomain htnDomain) throws Exception {
		startTimer(TimerName.EXPANDER);
		HTNExpander expander = new HTNExpander();
		fullyExpanded = expander.createFullyExpandedHTN(s0, network, htnDomain);
		endTimer(TimerName.EXPANDER);
		
		HashMap<Task,MultiState> mStates = expander.getMStates();
		
		gatherStatsHTNStates(mStates);
		
		List<MDPAction> actions = createMDPActions(fullyExpanded.getOrderedTasks());
		
		//We insert s0 here as a task so the full expansion will have constraints s0 << topLevelDerivations
		Task t0 = HTNFactory.createTask("s0");
		mStates.put(t0, expander.getInitialState());
		Collection<Task> unprec = fullyExpanded.getUnpreceededTasks();
		fullyExpanded.addTask(t0);
		for(Task t:unprec) {
			fullyExpanded.addBeforeConstraint(t0, t);
		}
		
		List<Task> tasks = new ArrayList<Task>(fullyExpanded.getOrderedTasks());
		
		startTimer(TimerName.STATES);
		List<MDPState> states = createMDPStates(mStates, tasks);
		endTimer(TimerName.STATES);
		
		List<MDPState> nonFinalStates = new ArrayList<MDPState>();
		List<MDPState> finalStates = new ArrayList<MDPState>();
		
		startTimer(TimerName.TRANSITION);
		MDPTransitionModel<MDPState, MDPAction> transitionModel = createTransitionModel(actions, fullyExpanded, states, finalStates);
		endTimer(TimerName.TRANSITION);
		
		for(MDPState s:states) {
			if(s.isFinal()) {
				finalStates.add(s);
			} else {
				nonFinalStates.add(s);
			}
		}
		
		MDPRewardFunction<MDPState> rewardFunction = createRewardFunction(states, fullyExpanded);
		
		MDPSourceImpl mdpSource = new MDPSourceImpl(actions, nonFinalStates, finalStates, states.get(0), rewardFunction, transitionModel);
		
		return mdpSource;
	}
	
	/**
	 * Creates {@link MDPState}s like in Algorithm 3 from the IJCAI paper.
	 * @param mStates
	 * @param tasks
	 * @return
	 */
	private final List<MDPState> createMDPStates(HashMap<Task, MultiState> mStates, List<Task> tasks) {
		logger.info("Creating MDP states");
		
		MDPState states[] = new MDPState[tasks.size()];
		
		for(int i=0; i<tasks.size(); i++) {
			Task ti = tasks.get(i);
			MultiState m = new MultiState(mStates.get(ti),false);
			MultiState si = new MultiState(m, false);
			
			for(int j=0; j<i; j++) {
				Task tj = tasks.get(j);
				si.removeAll(mStates.get(tj));
			}
			states[i] = new MDPState(i, si.toString(), si, ti);
			
			for(int j=0; j<i; j++) {
				Task tj = tasks.get(j);
				if(states[i].htnState.intersects(mStates.get(tj))) {
					states[i].overlapping.add(states[j]);
				}
				states[i].htnState.removeAll(mStates.get(tj));
			}
			//We add s itself to the overlapping list to make it easier to calculate things in #createTransitionTables
			if(!si.isEmpty()) {
				states[i].getOverlapping().add(states[i]);
			}
		}
		return Arrays.asList(states);
	}
	
	/**
	 * Creates the set of {@link MDPAction}s for the MDP by checking unique action names
	 * @param tasks
	 * @return
	 */
	private final List<MDPAction> createMDPActions(List<Task> tasks) {
		HashSet<String> uniqueActions = new HashSet<String>();
		List<MDPAction> actions = new LinkedList<MDPAction>();
		int id=0;
		for(Task t:tasks) {
			String actionName = t.getActionName();
			if(!uniqueActions.contains(actionName)) {
				actions.add(new MDPAction(id++, actionName));
			}
		}
		return actions;
	}
	
	/**
	 * Not a brilliant implementation of converting the transition matrices
	 * @param actions
	 * @param fullyExpanded
	 * @param states
	 * @param finalStates
	 * @return
	 */
	private final MDPTransitionModel<MDPState, MDPAction> createTransitionModel(List<MDPAction> actions, TaskNetwork fullyExpanded, List<MDPState> states, List<MDPState> finalStates) {
		logger.info("Creating Transition Model for MDP");
		MDPTransitionModel<MDPState, MDPAction> transitionModel = new MDPTransitionModel<MDPState, MDPAction>(finalStates);
		HashMap<Task, MDPState> stateTable = new HashMap<Task, MDPState>();
		for(MDPState s:states) {
			stateTable.put(s.getTask(), s);
		}
		
		for(MDPAction action:actions) {
			TransitionMatrix matrix = new TransitionMatrix(states.size());
			
			for(Constraint c : fullyExpanded.constraints) {
				if(c.task2.getActionName().equals(action.getName())) {
					MDPState i = stateTable.get(c.task1);
					MDPState j = stateTable.get(c.task2);
					if(i== null) throw new RuntimeException("Tried to create a transition for a non-existent state: "+c.task1);
					if(j== null) throw new RuntimeException("Tried to create a transition for a non-existent state: "+c.task2);
					//If i is the origin of any transition, then it cannot be final
					i.setFinal(false);
					
//					double s = matrix.get(i, j);
//					matrix.set(i, j, s+1);
					for(MDPState si:i.overlapping) {
						for(MDPState sj:j.overlapping) {
							int sid = si.getId();
							int sjd = sj.getId();
							double s = matrix.get(sid, sjd);
							matrix.set(sid, sjd, s+(1/j.modulo()));
						}
					}
				}
			}
			matrix.normalizeToOne(0,0);
			
			for(int i=0; i<states.size(); i++) {
				for(int j=0; j<states.size(); j++) {
					double prob = matrix.get(i, j);
					if(prob != 0) {
						MDPState si = states.get(i);
						MDPState sj = states.get(j);
						transitionModel.setTransitionProbability(si, action, sj, prob);
					}
				}
			}
		}
		
		return transitionModel;
	}
	
	/**
	 * Creates the reward function by assigning a reward value to each state in the resulting MDP.
	 * This function is defined in the paper as being for a combination of action and state, 
	 * but here we simplify it to match the reward function used in the code from AIMA.
	 * @param states
	 * @param fullyExpanded
	 * @return
	 */
	private final MDPRewardFunction<MDPState> createRewardFunction(List<MDPState> states, TaskNetwork fullyExpanded) {
		MDPRewardFunction<MDPState> rewardFunction = new MDPRewardFunction<MDPState>();
		for(MDPState sp:states) {
			double reward = getBaseReward(sp.htnState);
			Task t0 = fullyExpanded.getFirstTask();
			double kappa = fullyExpanded.maxpath(t0, sp.getTask());
			//Here, the paper states that the reward is for (t0.getActionName(), sp.s) 
			reward = kappa*reward;
			rewardFunction.setReward(sp, reward);
		}
		return rewardFunction;
	}
	
	/**
	 * A "macro" method to add stats to the {@link RunStats} object if existent
	 * @param mStates
	 */
	private final void gatherStatsHTNStates(HashMap<Task,MultiState> mStates) {
		int htnStates = uniqueStates(mStates).size();
		if(stats!=null) {
			stats.htnStates = htnStates;
		}
		logger.info("Number of states in the HTN: "+htnStates);
	}
	
	/**
	 * A "macro" method to check the {@link RunStats} stats object before starting a {@link Timer}.
	 * @param tm
	 */
	private final void startTimer(TimerName tm) {
		if(stats!=null) {
			stats.startRuntime(tm);
		}
	}
	
	/**
	 * A "macro" method to check the {@link RunStats} stats object before ending a {@link Timer}.
	 * @param tm
	 */
	private final void endTimer(TimerName tm) {
		if(stats!=null) {
			stats.endRuntime(tm);
		}
	}
	
	/**
	 * Returns the base reward for a state in the MDP.
	 * XXX At the moment, the base reward of all states is 1.
	 * @param state
	 * @return
	 */
	private final int getBaseReward(MultiState state) {
		return 1;
	}
	
	/**
	 * Returns the number of unique states in the set of possible states
	 * @param mStates
	 * @return
	 */
	final MultiState uniqueStates(HashMap<Task, MultiState> mStates) {
		MultiState megaState = new MultiState();
		for(MultiState ms : mStates.values()) {
			megaState.addAll(ms);
		}
		return megaState;
	}
	
	/* ***********************************************************************
	 * Part of the class responsible for running the whole command-line converter
	 *********************************************************************** */
	
	/**
	 * The possible modes in which we can run the converter from the command line.
	 * @author meneguzzi
	 *
	 */
	enum Runmode {
		CONVERT_AND_PLAN, CONVERT_ONLY;
	}
	
	private static final void printUsage() {
		System.out.println("Usage: java edu.cmu.ita.htn.TaskNetworkToMDP -p <problem_file> -d <domain_file> [pars]");
		System.out.println("Parameters: ");
		System.out.println("     -o <output_file> - to output either the MDP policy or the MDP itself if used with -convert");
		System.out.println("     -df <discount_factor> - a value in (0,1] for the MDP planning");
		System.out.println("     -convert - tells the software to just convert the problem into an MDP");
		System.out.println("     -mg <MDP Graph File> - outputs a graph with the MDP transitions");
		System.out.println("     -hg <HTN Graph File> - outputs a graph with the fully decomposed HTN");
		System.out.println("     -stats [<Stats File>] - outputs the problem stats to the console, or to the optional file");
	}
	
	/**
	 * Main entry point for the HTN to MDP converter
	 * @param args
	 */
	public static void main(String[] args) {
		String domainFile = null, problemFile = null, outputFile = null, mdpGraph = null, htnGraph = null, statsFile = null;
		double discountFactor = 1.0;
		Runmode runmode = Runmode.CONVERT_AND_PLAN;
		
		boolean error = false;
		boolean outputStats = false;
		
		for(int i=0; i<args.length; i++) {
			if(args[i].equals("-d")) {
				if(++i < args.length) {
					domainFile = args[i];
				} else {
					System.err.println("-d parameter requires an HTN domain filename");
					error = true;
				}
			} else if(args[i].equals("-p")) {
				if(++i < args.length) {
					problemFile = args[i];
				} else {
					System.err.println("-p parameter requires an HTN problem filename");
					error = true;
				}
			} else if(args[i].equals("-o")) {
				if(++i < args.length) {
					outputFile = args[i];
				} else {
					System.err.println("-o parameter requires an output filename");
					error = true;
				}
			} else if(args[i].equals("-df")) {
				if(++i < args.length) {
					discountFactor = Double.parseDouble(args[i]);
				} else {
					System.err.println("-df parameter requires a discount factor in (0,1]");
					error = true;
				}
			} else if(args[i].equals("-convert")) {
				runmode = Runmode.CONVERT_ONLY;
			} else if(args[i].equals("-mg")) {
				if(++i < args.length) {
					mdpGraph = args[i];
				} else {
					System.err.println("-mg parameter requires an MDP graph output filename");
					error = true;
				}
			} else if(args[i].equals("-hg")) {
				if(++i < args.length) {
					htnGraph = args[i];
				} else {
					System.err.println("-hg parameter requires an HTN graph output filename");
					error = true;
				}
			} else if(args[i].equals("-stats")) {
				outputStats = true;
				if(i+1 < args.length) {
					statsFile = args[++i];
				}
			} else {
				System.err.println("Unrecognized parameter "+args[i]);
			}
		}
		
		if(error) {
			printUsage();
			System.exit(0);
		}
		
		try {
			HTNParser parser = new HTNParser();
			FileReader reader = new FileReader(domainFile);
			HTNDomain domain = parser.parseDomain(reader);
			reader = new FileReader(problemFile);
			Problem problem = parser.parseProblem(reader);
			PrintStream out;
			if(outputFile != null) {
				out = new PrintStream(outputFile);
			} else {
				out = System.out;
			}
			
			TaskNetworkToMDP converter = new TaskNetworkToMDP();
			converter.stats = new RunStats();
			converter.stats.startRuntime(TimerName.TOTAL);
			switch (runmode) {
			case CONVERT_AND_PLAN:
				MDPPolicy<MDPState, MDPAction> pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, discountFactor);
				out.println(pol.toString());
				break;
			case CONVERT_ONLY:
				MDPSource<MDPState, MDPAction> mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain);
				out.print(mdp.toString());
				break;
			default:
				break;
			}
			converter.stats.endRuntime(TimerName.TOTAL);
			converter.stats.computeStats(problem, domain, converter.fullyExpanded, converter.mdpSource);
			
			if(mdpGraph != null && converter.mdpSource != null) {
				FileWriter writer = new FileWriter(mdpGraph);
				logger.info("Writing MDP Graph into "+mdpGraph);
				MDPDotConverter.printMDPDot(writer, converter.mdpSource, true);
				writer.close();
			}
			
			if(htnGraph != null && converter.fullyExpanded != null) {
				FileWriter writer = new FileWriter(htnGraph);
				logger.info("Writing HTN Graph into "+htnGraph);
				HTNDotConverter.printHTNDot(writer, converter.fullyExpanded);
				writer.close();
			}
			
			if(outputStats) {
				if(statsFile != null) {
					logger.info("Writing stats to "+statsFile);
					FileWriter writer = new FileWriter(statsFile);
					writer.write(converter.stats.toString());
					writer.close();
				}
				System.out.println(converter.stats.toString());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
