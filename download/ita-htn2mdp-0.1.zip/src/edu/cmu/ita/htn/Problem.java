/**
 * Created on Dec 29, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

/**
 * A simple container class with a TaskNetwork and an initial state
 * @author meneguzzi
 *
 */
public class Problem {
	TaskNetwork tn;
	State s0;
	
	/**
	 * 
	 */
	public Problem(TaskNetwork tn, State s0) {
		this.tn = tn;
		this.s0 = s0;
	}

	/**
	 * @return the tn
	 */
	public final TaskNetwork getTn() {
		return tn;
	}

	/**
	 * @return the s0
	 */
	public final State getS0() {
		return s0;
	}
	
	
}
