/**
 * Created on Oct 10, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;

import edu.cmu.ita.htn.LogicExpressionImpl.LogicalOp;
import edu.cmu.ita.htn.parser.HTNParser;

import jason.asSyntax.ASSyntax;
import jason.asSyntax.Literal;
import jason.asSyntax.parser.ParseException;

/**
 * @author meneguzzi
 * 
 * TODO Possibly refactor the whole thing into {@link HTNDomain}
 *
 */
public class HTNFactory {
	public static final State STrue = new State();
	private static final HashMap<String, Proposition> propositions = new HashMap<String, Proposition>();
	private static final HashMap<String,Operator> operators = new HashMap<String, Operator>();
	private static final HashMap<String,Task> tasks = new HashMap<String, Task>();
	
	static final void resetInstances() {
		propositions.clear();
		operators.clear();
		tasks.clear();
	}
	
	/**
	 * 
	 * @param sLiteral
	 * @return
	 */
	public static Proposition createProposition(String sLiteral) {
		Proposition p = null;
		if(propositions.containsKey(sLiteral)) {
			p = propositions.get(sLiteral);
		} else {
			Literal lit;
			try {
				lit = ASSyntax.parseLiteral(sLiteral);
			} catch (ParseException e) {
				throw new RuntimeException(e);
			}
			p = new Proposition(lit);
			if(p.isGround()) {
				propositions.put(sLiteral, p);
			}
		}
		
		return p;
	}
	
	/**
	 * 
	 * @param pos
	 * @param sLiteral
	 * @return
	 */
	protected static Proposition createProposition(boolean pos, String sLiteral) {
		return createProposition((pos?"":"~")+sLiteral);
	}
	
	/**
	 * 
	 * @param sProps
	 * @return
	 */
	public static State createState(String ... sProps) {
		Proposition props[] = new Proposition[sProps.length];
		for(int i = 0; i<sProps.length; i++) {
			props[i] = createProposition(sProps[i]);
		}
		return new State(props);
	}
	
	/**
	 * 
	 * @param sOperator
	 * @param preconds
	 * @param effects
	 * @return
	 * @throws Exception
	 */
	public static Operator createOperator(String sOperator, LogicExpression preconds, State effects) {
		return createOperator(sOperator, preconds, effects, 0);
	}
	
	/**
	 * 
	 * @param sOperator
	 * @param preconds
	 * @param effects
	 * @param cost
	 * @return
	 * @throws Exception
	 */
	public static Operator createOperator(String sOperator, LogicExpression preconds, State effects, double cost) {
		Operator op = null;
		
		if(operators.containsKey(sOperator)) {
			op = operators.get(sOperator);
		} else {
			Literal lit;
			try {
				lit = ASSyntax.parseLiteral(sOperator);
			} catch (ParseException e) {
				throw new RuntimeException(e);
			}
			op = new Operator(lit, preconds, effects, cost);
			if(op.isGround()) {
				operators.put(sOperator, op);
			}
		}
		return op;
	}
	
	public static final Task createPrimitiveTask(Operator op) {
		Task task = createPrimitiveTask(op.getHeadToString());
		task.op = op;
		return task;
	}
	
	/**
	 * 
	 * @param sTask
	 * @return
	 */
	public static final Task createPrimitiveTask(String sTask) {
		Task task = createTask(sTask, true);
		if(!task.isPrimitive())
			throw new RuntimeException("Trying to create a primitive task with the same name as a non-primitive one");
		return task;
	}
	
	/**
	 * 
	 * @param sTask
	 * @return
	 */
	public static final Task createTask(String sTask) {
		return createTask(sTask, false);
	}
	
	/**
	 * 
	 * @param sTask
	 * @param preconds
	 * @param primitive
	 * @return
	 */
	private static final Task createTask(String sTask, boolean primitive) {
		Task t = null;
		
		if(tasks.containsKey(sTask)) {
			return tasks.get(sTask);
		} else {
			try {
				t = new Task(sTask);
				String empty[] = {};
				if(primitive) {
					t.op = new Operator(sTask, Proposition.TRUE, createState(empty));
				} 
//				tasks.put(sTask, t);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		
		return t;
	}
	
	public static final LogicExpression createLogicExpression(String sExpr) {
		HTNParser parser = new HTNParser();
		StringReader reader = new StringReader(sExpr);
		parser.ReInit(reader);
		try {
			return parser.log_expr();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * Creates a {@link LogicExpression} consisting of the conjunction of all Propositions in this state
	 * @param s
	 * @return
	 */
	public static final LogicExpression createLogicExpression(State s) {
		if(s.size() == 0) {
			return Proposition.TRUE;
		} else {
			Iterator<Proposition> i = s.iterator();
			LogicExpression lhs = i.next();
			while(i.hasNext()) {
				lhs = new LogicExpressionImpl(lhs, LogicalOp.and, i.next());
			}
				
			return lhs;
		}
	}
	
	/**
	 * Creates a {@link LogicExpression} consisting of the conjunction of all Propositions supplied
	 * @param s
	 * @return
	 */
	public static final LogicExpression createLogicExpression(Proposition ... props) {
		if(props.length == 0) {
			return Proposition.TRUE;
		} else {
			LogicExpression lhs = props[0];
			for(int i=1; i<props.length; i++) {
				lhs = new LogicExpressionImpl(lhs, LogicalOp.and, props[i]);
			}
				
			return lhs;
		}
	}
	
	/**
	 * Creates a {@link LogicExpression} consisting of the conjunction of all Propositions supplied
	 * @param s
	 * @return
	 */
	public static final LogicExpression createLogicExpression(String ... props) {
		return createLogicExpression(createState(props));
	}
}
