package edu.cmu.ita.htn;

import jason.asSyntax.Pred;
import jason.asSyntax.PredicateIndicator;
import jason.asSyntax.Term;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import aima.core.probability.decision.MDPSource;

import edu.cmu.ita.mdp.MDPProblem;
import edu.cmu.ita.mdp.aima.MDPAction;
import edu.cmu.ita.mdp.aima.MDPState;

/**
 * 
 * @author meneguzzi
 *
 */
public class RunStats {
	enum TimerName {
		EXPANDER  { public String toString() { return "HTN Expansion Time "; } },
		STATES    { public String toString() { return "MDP States Time    "; } },
		TRANSITION{ public String toString() { return "MDP Transition Time"; } },
		CONVERTER { public String toString() { return "HTN to MDP Time    "; } },
		SOLVER    { public String toString() { return "MDP Solver Time    "; } },
		TOTAL     { public String toString() { return "Total Runtime      "; } }
		}
	final Timer timers[] = new Timer[TimerName.values().length];
	long uniqueObjects;
	long uniquePreds;
	long herbrandBase;
	long htnStates;
	long uniqueStates;
	long totalMethods;
	long totalOperators;
	long totalTasks;
	long maxBranching;
	
	/**
	 * 
	 */
	public RunStats() {
		for(TimerName tm:TimerName.values()) {
			timers[tm.ordinal()] = new Timer(tm.toString());
		}
	}
	
	/**
	 * Starts counting the time for the specified {@link TimerName}. 
	 * @param tm
	 */
	void startRuntime(TimerName tm) {
		timers[tm.ordinal()].start();
	}
	
	/**
	 * End counting the time for the specified {@link TimerName}
	 * @param tm
	 */
	void endRuntime(TimerName tm) {
		timers[tm.ordinal()].end();
	}
	
	/**
	 * 
	 * @param problem
	 * @param domain
	 * @param fullyExpanded
	 * @param mdp
	 * @deprecated
	 */
	void computeStats(Problem problem, HTNDomain domain, TaskNetwork fullyExpanded, MDPProblem mdp) {
		uniqueStates = (mdp!=null)?mdp.getStates().size():0;
		herbrandBase = calculateRawStateSpace(problem, domain);
		totalMethods = domain.methods.size();
		totalOperators = domain.actions.size();
		totalTasks = fullyExpanded.tasks.size();
		maxBranching = calculateMaxBranching(domain);
	}
	
	/**
	 * 
	 * @param problem
	 * @param domain
	 * @param fullyExpanded
	 * @param mdp
	 */
	void computeStats(Problem problem, HTNDomain domain, TaskNetwork fullyExpanded, MDPSource<MDPState,MDPAction> mdp) {
		uniqueStates = (mdp!=null)?(mdp.getFinalStates().size()+mdp.getNonFinalStates().size()):0;
		herbrandBase = calculateRawStateSpace(problem, domain);
		totalMethods = domain.methods.size();
		totalOperators = domain.actions.size();
		totalTasks = fullyExpanded.tasks.size();
		maxBranching = calculateMaxBranching(domain);
	}
	
	private long calculateRawStateSpace(Problem problem, HTNDomain domain) {
		HashSet<Term> objects = new HashSet<Term>();
		HashSet<PredicateIndicator> preds = new HashSet<PredicateIndicator>();
		
		for(Pred p:problem.s0) {
			objects.addAll(getNonVars(p.getTerms()));
			preds.add(p.getPredicateIndicator());
		}
		
		for(Task t:domain.actions) {
			Operator op = t.op;
			for(Pred p:op.preconds.getPropositions()) {
				objects.addAll(getNonVars(p.getTerms()));
				preds.add(p.getPredicateIndicator());
			}
			for(Pred p:op.effects) {
				objects.addAll(getNonVars(p.getTerms()));
				preds.add(p.getPredicateIndicator());
			}
		}
		
		for(Method m:domain.methods) {
			for(Task task:m.taskNetwork) {
				objects.addAll(getNonVars(task.getTerms()));
			}
		}
		
		preds.remove(Pred.LTrue.getPredicateIndicator());
		preds.remove(Pred.LFalse.getPredicateIndicator());
		
		uniqueObjects = objects.size();
		uniquePreds = preds.size();
		long stateSpace = 0;
		for(PredicateIndicator pi:preds) {
			int arity = pi.getArity();
			stateSpace += Math.pow(uniqueObjects, arity);
		}
		
		return stateSpace;
	}
	
	/**
	 * Filters variables out of a list of terms
	 * @param terms
	 * @return
	 */
	private final List<Term> getNonVars(List<Term> terms) {
		List<Term> res = new ArrayList<Term>();
		for(Term t:terms) {
			if(t.isGround()) {
				res.add(t);
			}
		}
		return res;
	}
	
	private long calculateMaxBranching(HTNDomain domain) {
		long res = 0;
		for(Method m:domain.methods) {
			int b = m.taskNetwork.size();
			if(b > res) {
				res = b;
			}
		}
		return res;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Unique Objects : "+uniqueObjects); sb.append(System.getProperty("line.separator"));
		sb.append("Unique Preds   : "+uniquePreds); sb.append(System.getProperty("line.separator"));
		sb.append("Unique States  : "+uniqueStates); sb.append(System.getProperty("line.separator"));
		sb.append("Herbrand Base  : "+herbrandBase); sb.append(System.getProperty("line.separator"));
		sb.append("HTN States     : "+htnStates); sb.append(System.getProperty("line.separator"));
		sb.append("Total Methods  : "+totalMethods); sb.append(System.getProperty("line.separator"));
		sb.append("Total Operators: "+totalOperators); sb.append(System.getProperty("line.separator"));
		sb.append("Total Tasks    : "+totalTasks); sb.append(System.getProperty("line.separator"));
		sb.append("Max Branching  : "+maxBranching); sb.append(System.getProperty("line.separator"));
		//sb.append("Runtime        : "+runtime); sb.append(System.getProperty("line.separator"));
		sb.append("Times"); sb.append(System.getProperty("line.separator"));
		for(Timer t:timers) {
			sb.append(t.toString()); sb.append(System.getProperty("line.separator"));
		}
		return sb.toString();
	}
	
	/**
	 * A timer utility
	 * @author meneguzzi
	 *
	 */
	class Timer {
		long time;
		String name;
		
		public Timer(String name) {
			this.name = name;
		}
		
		void start() {
			time = System.currentTimeMillis();
		}
		
		void end() {
			time = System.currentTimeMillis() - time;
		}
		
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder(name!=null?name+": ":"");
			sb.append(time);
			return sb.toString();
		}
	}
}