/**
 * Created on Oct 10, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import jason.asSemantics.Unifier;
import jason.asSyntax.Literal;
import jason.asSyntax.LiteralImpl;
import jason.asSyntax.Term;

/**
 * @author meneguzzi
 * 
 */
public class Proposition extends LiteralImpl implements LogicExpression {
	
	public static final Proposition TRUE = new TrueProposition();
	public static final Proposition FALSE = new FalseProposition();

	/**
	 * @param functor
	 */
	Proposition(String functor) {
		super(functor);

	}

	protected Proposition(Literal l) {
		super(l);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Returns the name of this proposition
	 * 
	 * @return
	 */
	public String getName() {
		return getPredicateIndicator().toString();
	}

	/**
	 * Returns whether or not this proposition is true or false
	 * 
	 * @return
	 */
	public boolean isTrue() {
		return negated() == LPos;
	}

	/**
	 * Returns whether or not the supplied proposition is indeed the same
	 * 
	 * @param prop
	 * @return
	 */
	public boolean equals(Proposition prop) {
		if (prop == null) {
			return false;
		} else {
			//return this.toString().equals(prop.toString());
			return super.equals(prop);
		}
	}

	/**
	 * Returns a negated version of this proposition.
	 * 
	 * @return
	 */
	public Proposition getNegated() {
		return HTNFactory.createProposition(this.negated(), toStringAsTerm());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see edu.cmu.ita.htn.LogicExpression#consequence(edu.cmu.ita.htn.State,
	 * jason.asSemantics.Unifier)
	 */
	@Override
	public Iterator<Unifier> consequence(final State s, final Unifier un) {
		if(this.equals(TRUE)) {
			return LogicExpressionImpl.createUnifIterator(un);
		} else if (this.equals(FALSE)) {
			return EMPTY_UNIF_LIST.iterator();
		}
		final Iterator<Proposition> ip = s.getUnifiablePropositions(this, un);
		if (ip == null) {
			return EMPTY_UNIF_LIST.iterator();
		}
		return new Iterator<Unifier>() {
			boolean needsUpdate = true;
			private Unifier current;

			@Override
			public void remove() {
			}

			@Override
			public Unifier next() {
				if (needsUpdate)
					get();
				Unifier a = current;
				if (current != null)
					needsUpdate = true;
				return a;
			}
			
			@Override
			public boolean hasNext() {
				if (needsUpdate)
                    get();
                return current != null;
			}
			
			private final void get() {
				needsUpdate = false;
                current     = null;
                while(ip.hasNext()) {
                	Proposition b = ip.next();
                	Unifier u = un.clone();
                    if (u.unifiesNoUndo(Proposition.this, b)) {
                        current = u;
                        return;
                    }
                }
			}
		};
	}
	
	/* (non-Javadoc)
	 * @see jason.asSyntax.LiteralImpl#clone()
	 */
	@Override
	public Term clone() {
		return new Proposition(this);
	}
	
	/* (non-Javadoc)
	 * @see edu.cmu.ita.htn.LogicExpression#getPropositions()
	 */
	@Override
	public Collection<Proposition> getPropositions() {
		Collection<Proposition> res = new ArrayList<Proposition>();
		res.add(this);
		return res;
	}
	
	@SuppressWarnings("serial")
	static final class TrueProposition extends Proposition {
		/**
		 * 
		 */
		public TrueProposition() {
			super("true");
		}
		
		/* (non-Javadoc)
		 * @see edu.cmu.ita.htn.Proposition#consequence(edu.cmu.ita.htn.State, jason.asSemantics.Unifier)
		 */
		@Override
		public Iterator<Unifier> consequence(State s, Unifier un) {
			return LogicExpressionImpl.createUnifIterator(un);
		}
	}
	
	@SuppressWarnings("serial")
	static final class FalseProposition extends Proposition {
		/**
		 * 
		 */
		public FalseProposition() {
			super("false");
		}
		
		/* (non-Javadoc)
		 * @see edu.cmu.ita.htn.Proposition#consequence(edu.cmu.ita.htn.State, jason.asSemantics.Unifier)
		 */
		@Override
		public Iterator<Unifier> consequence(State s, Unifier un) {
			return EMPTY_UNIF_LIST.iterator();
		}
	}

	/* (non-Javadoc)
	 * @see edu.cmu.ita.htn.LogicExpression#isUnary()
	 */
	@Override
	public boolean isUnary() {
		return true;
	}
}
