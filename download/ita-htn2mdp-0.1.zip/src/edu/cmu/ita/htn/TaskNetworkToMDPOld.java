/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;
import java.util.logging.Logger;

import edu.cmu.ita.htn.RunStats.TimerName;
import edu.cmu.ita.htn.parser.HTNParser;
import edu.cmu.ita.htn.parser.ParseException;
import edu.cmu.ita.mdp.Action;
import edu.cmu.ita.mdp.BasicMDPProblem;
import edu.cmu.ita.mdp.MDPProblem;
import edu.cmu.ita.mdp.MDPSolver;
import edu.cmu.ita.mdp.Policy;
import edu.cmu.ita.mdp.State;
import edu.cmu.ita.mdp.TransitionMatrix;
import edu.cmu.ita.mdp.graph.MDPDotConverter;

/**
 * @author meneguzzi
 *
 */
public class TaskNetworkToMDPOld {
	
	private static final Logger logger = Logger.getLogger(TaskNetworkToMDPOld.class.getName());
	
	private MDPProblem mdp;
	private TaskNetwork fullyExpanded;
	
	/**
	 * Converts the specified task network into an MDP and generates an optimal policy for that HTN
	 * @param s0
	 * @param problem
	 * @param domain
	 * @param discountFactor
	 * @return
	 * @throws Exception 
	 */
	public Policy convertHTNAndPlan(edu.cmu.ita.htn.State s0, TaskNetwork problem, HTNDomain htnDomain, double discountFactor) throws Exception {
		mdp = convertTaskNetwork(s0, problem, htnDomain, discountFactor);
		MDPSolver solver = new MDPSolver(mdp);
		solver.solve();
		return solver.computeDeterministicPolicy();
	}
	
	/**
	 * TODO Make this algorithm like the one in the paper, fix potential bugs
	 * @param s0
	 * @param network
	 * @param htnDomain
	 * @param discountFactor
	 * @return
	 * @throws Exception
	 */
	public MDPProblem convertTaskNetwork(edu.cmu.ita.htn.State s0, TaskNetwork network, HTNDomain htnDomain, double discountFactor) throws Exception {
		HTNExpander expander = new HTNExpander();
		
		fullyExpanded = expander.createFullyExpandedHTN(s0, network, htnDomain);
		HashMap<Task,MultiState> mStates = expander.getMStates();
		
		logger.info("Number of unique states "+ uniqueStates(mStates).size());
		
		//We insert s0 here as a task so the full expansion will have constraints s0 << topLevelDerivations
		Task t0 = HTNFactory.createTask("s0");
		mStates.put(t0, expander.getInitialState());
		Collection<Task> unprec = fullyExpanded.getUnpreceededTasks();
		fullyExpanded.addTask(t0);
		for(Task t:unprec) {
			fullyExpanded.addBeforeConstraint(t0, t);
		}
		
		List<Task> tasks = new ArrayList<Task>(fullyExpanded.getOrderedTasks());
		
		StatePair states[] = createMDPStates(mStates, tasks);
		
		List<State> mdpStates = new ArrayList<State>(); {
			for(StatePair sp:states) {
				mdpStates.add(sp.mdpState);
			}
		}
		
		List<Action> actions = uniqueActions(tasks);
		List<TransitionMatrix> matrices = createTransitionTables(actions, fullyExpanded, states);
		
//		List<Integer> rewards = createRewards(states, fullyExpanded);
		createRewards(states, fullyExpanded);
		
		MDPProblem problem = createMDPProblem(mdpStates, actions, matrices, discountFactor);
		
		return problem;
	}
	
	/**
	 * Creates an MDP problem in Jean's format
	 * @param states
	 * @param actions
	 * @param matrices
	 * @param discount
	 * @return
	 */
	private final MDPProblem createMDPProblem(List<State> states, List<Action> actions, List<TransitionMatrix> matrices, double discount) {
		for(State s:states) {
			for(Action a:actions) {
				s.addAction(a);
			}
		}
		MDPProblem problem = new BasicMDPProblem(states, actions, matrices, discount);
		return problem;
	}
	
	
	
	/**
	 * Creates the reward function by assigning a reward value to each state in the resulting MDP.
	 * TODO This function is defined in the paper as being for a combination of action and state, 
	 * and we should do this accordingly.
	 * @param states
	 * @param fullyExpanded
	 * @return A list with the rewards for each state.
	 */
	private List<Integer> createRewards(StatePair[] states, TaskNetwork fullyExpanded) {
		List<Integer> rewards = new ArrayList<Integer>(states.length);
		for(StatePair sp:states) {
			int reward = getBaseReward(sp.htnState);
			Task t0 = fullyExpanded.getFirstTask();
			int kappa = fullyExpanded.maxpath(t0, sp.task);
			//Here, the paper states that the reward is for (t0.getActionName(), sp.s) 
			reward = kappa*reward;
			rewards.add(reward);
			sp.mdpState.setReward(reward);
		}
		return rewards;
	}
	
	/**
	 * Returns the base reward for a state in the MDP.
	 * XXX At the moment, the base reward of all states is 1.
	 * @param state
	 * @return
	 */
	final int getBaseReward(MultiState state) {
		return 1;
	}

	/**
	 * Returns a set with the unique actions in this problem.
	 * @param tasks
	 * @return
	 */
	final List<Action> uniqueActions(List<Task> tasks) {
		TreeSet<String> uniqueActions = new TreeSet<String>();
		for(Task task:tasks) {
			uniqueActions.add(task.getActionName());
		}
		List<Action> actions = new ArrayList<Action>();
		int id = -1;
		for(String task:uniqueActions) {
			actions.add(new Action(task, ++id));
		}
		
		return actions;
	}
	
	/**
	 * Returns the number of unique states in the set of possible states
	 * @param mStates
	 * @return
	 */
	final MultiState uniqueStates(HashMap<Task, MultiState> mStates) {
		MultiState megaState = new MultiState();
		for(MultiState ms : mStates.values()) {
			megaState.addAll(ms);
		}
		return megaState;
	}
	
	/**
	 * Creates MDP states like in Algorithm 3 from AAMAS paper
	 * 
	 * @param mStates
	 * @param network
	 * @param domain
	 * @return
	 */
	private final StatePair []createMDPStates(HashMap<Task, MultiState> mStates, List<Task> tasks) {
		logger.info("Creating MDP states");
		
		StatePair states[] = new StatePair[tasks.size()];
		
		for(int i=0; i<tasks.size(); i++) {
			Task ti = tasks.get(i);
			State s = new State(i, ti.toString(), "", 0);
			
			MultiState m = new MultiState(mStates.get(ti),false);
			MultiState si = new MultiState(m, false);
			
			for(int j=0; j<i; j++) {
				Task tj = tasks.get(j);
				si.removeAll(mStates.get(tj));
			}
			
			states[i] = new StatePair(i, s, si, ti);
			states[i].overlapping.add(i);
			for(int j=0; j<i; j++) {
				Task tj = tasks.get(j);
				//We add the index of i itself to the overlapping to make it easier to calculate things in #createTransitionTables
				if(states[i].htnState.intersects(mStates.get(tj))) {
					states[i].overlapping.add(j);
				}
				states[i].htnState.removeAll(mStates.get(tj));
			}
			//If this state ended up empty, we remove it
			//XXX Review this
			if(states[i].htnState.isEmpty()) {
				states[i].overlapping.remove(0);
			}
		}
		
		for(StatePair sp:states) {
			sp.mdpState.setLabel(sp.htnState.toString());
		}
		
		return states;
	}
	
	private final List<TransitionMatrix> createTransitionTables(List<Action> actions, TaskNetwork fullyExpanded, StatePair states[]) {
		logger.info("Creating Transition Tables for MDP");
		List<TransitionMatrix> matrices = new ArrayList<TransitionMatrix>(actions.size());
		
		for(Action action:actions) {
			TransitionMatrix matrix = new TransitionMatrix(states.length, action);
			
			for(Constraint c : fullyExpanded.constraints) {
				if(c.task2.getActionName().equals(action.getName())) {
					int i = indexOfState(c.task1.toString(), states);
					int j = indexOfState(c.task2.toString(), states);
					if(i== -1) throw new RuntimeException("Tried to create a transition for a non-existent state: "+c.task1);
					if(j== -1) throw new RuntimeException("Tried to create a transition for a non-existent state: "+c.task2);
//					double s = matrix.get(i, j);
//					matrix.set(i, j, s+1);
					for(int si:states[i].overlapping) {
						for(int sj:states[j].overlapping) {
							double s = matrix.get(si, sj);
							matrix.set(si, sj, s+(1/states[j].modulo()));
						}
					}
				}
			}
			matrix.normalizeToOne(0,0);
			matrices.add(matrix);
		}
		
		return matrices;
	}
	
	/**
	 * Finds the index of the named state in the List of states.
	 * TODO optimize this, as it is terribly inefficient.
	 * @param stateName
	 * @param states
	 * @return
	 */
	private final int indexOfState(String stateName, StatePair states[]) {
		for(int i=0; i<states.length; i++) {
			State s = states[i].mdpState;
			if(s.getId().equals(stateName))
				return i;
		}
		return -1;
	}

	
	/**
	 * 
	 * @param topLevel
	 * @param htnDomain
	 * @param discountFactor
	 * @return
	 * @throws Exception
	 * 
	 * @deprecated 
	 */
	public MDPProblem convertTaskNetwork(Task topLevel, HTNDomain htnDomain, double discountFactor) throws Exception {
		HTNExpander expander = new HTNExpander();
		
		//We insert s0 here as a task so the full expansion will have constraints s0 << topLevelDerivations
		Task t0 = HTNFactory.createPrimitiveTask("s0");
		TaskNetwork tn = new TaskNetwork(new Task[] {topLevel}, new Constraint[]{new Constraint(t0,topLevel)});
		
		TaskNetwork fullyExpanded = expander.createFullyExpandedHTN(tn, htnDomain);
		
		List<State> states = new ArrayList<State>(fullyExpanded.getTasks().size()+1);
		int i=0;
		State s = new State(i++, t0.toString(), "", 0);
		states.add(s);
		//TODO put the rewards properly
		for(Task t:fullyExpanded.getTasks()) {
			s = new State(i++, t.toString(), t.toString(), 0);
			states.add(s);
		}
		
		List<Action> actions = new ArrayList<Action>(htnDomain.getPrimitiveTasks().size());
		int id=-1;
		for(Task task: htnDomain.getPrimitiveTasks()) {
			actions.add(new Action(task.getName(), ++id));
		}
		
		List<TransitionMatrix> matrices = new ArrayList<TransitionMatrix>(actions.size());
		for(Action action:actions) {
			TransitionMatrix matrix = populateTransitionMatrix(fullyExpanded, action, states);
			matrix.normalizeToOne(0);
			matrices.add(matrix);
		}
		
		BasicMDPProblem problem = new BasicMDPProblem(states, actions, matrices, discountFactor);
		
		return problem;
	}
	
	/**
	 * Finds the index of the named state in the List of states.
	 * TODO optimize this, as it is terribly inefficient.
	 * @param stateName
	 * @param states
	 * @return
	 */
	protected int indexOf(String stateName, List<State> states) {
		for(int i=0; i<states.size(); i++) {
			State s = states.get(i);
			if(s.getId().equals(stateName))
				return i;
		}
		return -1;
	}
	
	/**
	 * Populates the transition matrix for a given action
	 * @param fullyExpanded
	 * @param action
	 * @param states
	 * @return
	 */
	protected TransitionMatrix populateTransitionMatrix(TaskNetwork fullyExpanded, Action action, List<State> states) {
		TransitionMatrix matrix = new TransitionMatrix(states.size(), action);
		
		for(Constraint c : fullyExpanded.constraints) {
			if(c.task2.getName().equals(action.getName())) {
				int i = indexOf(c.task1.toString(), states);
				int j = indexOf(c.task2.toString(), states);
				if(i== -1) throw new RuntimeException("Tried to create a transition for a non-existent action: "+c.task1);
				if(j== -1) throw new RuntimeException("Tried to create a transition for a non-existent action: "+c.task2);
				double s = matrix.get(i, j);
				matrix.set(i, j, s+1);
			}
		}
		
		return matrix;
	}
	
	/**
	 * Since we 
	 * @author meneguzzi
	 *
	 */
	class StatePair implements Comparable<StatePair> {
		int id;
		/**The MDP state*/
		State mdpState;
		/**The HTN state (or combination thereof as a multistate)*/
		MultiState htnState;
		/**The indexes of the states that overlap with this one*/
		List<Integer> overlapping;
		/** The task that led to the creation of this state*/
		Task task;
		
		public StatePair(int id, State s, MultiState htnState, Task task) {
			this.id = id;
			this.mdpState = s;
			this.htnState = htnState;
			this.overlapping = new ArrayList<Integer>();
			this.task = task;
		}
		
		public int modulo() {
			return overlapping.size();
		}
		
		public String toString() {
			return "("+mdpState.toString()+","+htnState+","+overlapping+")";
		}

		/* (non-Javadoc)
		 * @see java.lang.Comparable#compareTo(java.lang.Object)
		 */
		@Override
		public int compareTo(StatePair o) {
			int thisVal = id;
			int anotherVal = o.id;
			return (thisVal<anotherVal ? -1 : (thisVal==anotherVal ? 0 : 1));
		}
	}
	
	/* ***********************************************************************
	 * Part of the class responsible for running.
	 *********************************************************************** */
	
	/**
	 * The possible modes in which we can run the converter from the command line.
	 * @author meneguzzi
	 *
	 */
	enum Runmode {
		CONVERT_AND_PLAN, CONVERT_ONLY;
	}
	
	private static final void printUsage() {
		System.out.println("Usage: java edu.cmu.ita.htn.TaskNetworkToMDP -p <problem_file> -d <domain_file> [pars]");
		System.out.println("Parameters: ");
		System.out.println("     -o <output_file> - to output either the MDP policy or the MDP itself if used with -convert");
		System.out.println("     -df <discount_factor> - a value in (0,1] for the MDP planning");
		System.out.println("     -convert - tells the software to just convert the problem into an MDP");
		System.out.println("     -mg <MDP Graph File> - outputs a graph with the MDP transitions");
		System.out.println("     -hg <HTN Graph File> - outputs a graph with the fully decomposed HTN");
		System.out.println("     -stats [<Stats File>] - outputs the problem stats to the console, or to the optional file");
	}
	
	/**
	 * Main entry point for the HTN to MDP converter
	 * @param args
	 */
	public static void main(String[] args) {
		String domainFile = null, problemFile = null, outputFile = null, mdpGraph = null, htnGraph = null, statsFile = null;
		double discountFactor = 1.0;
		Runmode runmode = Runmode.CONVERT_AND_PLAN;
		
		boolean error = false;
		boolean outputStats = false;
		
		for(int i=0; i<args.length; i++) {
			if(args[i].equals("-d")) {
				if(++i < args.length) {
					domainFile = args[i];
				} else {
					System.err.println("-d parameter requires an HTN domain filename");
					error = true;
				}
			} else if(args[i].equals("-p")) {
				if(++i < args.length) {
					problemFile = args[i];
				} else {
					System.err.println("-p parameter requires an HTN problem filename");
					error = true;
				}
			} else if(args[i].equals("-o")) {
				if(++i < args.length) {
					outputFile = args[i];
				} else {
					System.err.println("-o parameter requires an output filename");
					error = true;
				}
			} else if(args[i].equals("-df")) {
				if(++i < args.length) {
					discountFactor = Double.parseDouble(args[i]);
				} else {
					System.err.println("-df parameter requires a discount factor in (0,1]");
					error = true;
				}
			} else if(args[i].equals("-convert")) {
				runmode = Runmode.CONVERT_ONLY;
			} else if(args[i].equals("-mg")) {
				if(++i < args.length) {
					mdpGraph = args[i];
				} else {
					System.err.println("-mg parameter requires an MDP graph output filename");
					error = true;
				}
			} else if(args[i].equals("-hg")) {
				if(++i < args.length) {
					htnGraph = args[i];
				} else {
					System.err.println("-hg parameter requires an HTN graph output filename");
					error = true;
				}
			} else if(args[i].equals("-stats")) {
				outputStats = true;
				if(i+1 < args.length) {
					statsFile = args[++i];
				}
			}
		}
		
		if(error) {
			printUsage();
			System.exit(0);
		}
		
		try {
			HTNParser parser = new HTNParser();
			FileReader reader = new FileReader(domainFile);
			HTNDomain domain = parser.parseDomain(reader);
			reader = new FileReader(problemFile);
			Problem problem = parser.parseProblem(reader);
			PrintStream out;
			if(outputFile != null) {
				out = new PrintStream(outputFile);
			} else {
				out = System.out;
			}
			
			TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
			RunStats stats = new RunStats();
			stats.startRuntime(TimerName.TOTAL);
			switch (runmode) {
			case CONVERT_AND_PLAN:
				Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, discountFactor);
				out.println(pol.toString());
				break;
			case CONVERT_ONLY:
				MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, discountFactor);
				out.print(mdp.toString());
				break;
			default:
				break;
			}
			stats.endRuntime(TimerName.TOTAL);
			stats.computeStats(problem, domain, converter.fullyExpanded, converter.mdp);
			
			if(mdpGraph != null && converter.mdp != null) {
				FileWriter writer = new FileWriter(mdpGraph);
				MDPDotConverter.printMDPDot(writer, converter.mdp, true);
				writer.close();
			}
			
			if(htnGraph != null && converter.fullyExpanded != null) {
				FileWriter writer = new FileWriter(htnGraph);
				HTNDotConverter.printHTNDot(writer, converter.fullyExpanded);
				writer.close();
			}
			
			if(outputStats) {
				if(statsFile != null) {
					logger.info("Writing stats to "+statsFile);
					FileWriter writer = new FileWriter(statsFile);
					writer.write(stats.toString());
					writer.close();
				}
				System.out.println(stats.toString());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
