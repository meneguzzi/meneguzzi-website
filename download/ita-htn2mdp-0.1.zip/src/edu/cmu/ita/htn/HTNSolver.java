/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import jason.asSemantics.Unifier;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;

import edu.cmu.ita.htn.parser.HTNParser;
import edu.cmu.ita.htn.parser.ParseException;


/**
 * @author meneguzzi
 *
 */
public class HTNSolver {
	private static final Logger logger = Logger.getLogger(HTNSolver.class.getName());
	private static final Random random = new Random(7);
	
	/**
	 * Solver method that delegates functionality to 
	 * {@link #solveHTN(State, TaskNetwork, HTNDomain)}.
	 * 
	 * @param initialTask The initial task to be decomposed by the solver.
	 * @param domain The domain for the problem, with the methods to decompose 
	 *        <code>initialTask</code>.
	 * @return A fully decomposed {@link TaskNetwork} from which the plan can 
	 *         be extracted through {@link TaskNetwork#getOrderedTasks()}.
	 * @deprecated This method is now meaningless given that we introduced the notion of an intial state 
	 */
	public TaskNetwork solveTask(Task initialTask, HTNDomain domain, State s0) {
		TaskNetwork tn = new TaskNetwork();
		tn.addTask(initialTask);
		return solveHTN(null,tn, domain);
	}
	
	/**
	 * Solves the {@link TaskNetwork} <code>problem</code> by decomposing the 
	 * tasks using the methods in {@link HTNDomain} <code>domain</code>. 
	 * @param s0 The initial state for which the HTN plan should be generated
	 * @param problem The {@link TaskNetwork} with the initial tasks to be 
	 *        decomposed by the solver.
	 * @param domain The domain for the problem, with the methods to decompose 
	 *        <code>problem</code>.
	 * @return A fully decomposed {@link TaskNetwork} from which the plan can 
	 *         be extracted through {@link TaskNetwork#getOrderedTasks()}. 
	 */
	public TaskNetwork solveHTN(State s0, TaskNetwork problem, HTNDomain domain) {
		TaskNetwork solution = new TaskNetwork(problem);
		while(!solution.allTasksArePrimitive()) {
			Task taskToExpand = null;
			List<MethodOption> options = null;
			for(Task task:solution.getOrderedTasks()) {
				if(task.isPrimitive()) {
					continue;
				} else {
					
					Unifier un = new Unifier();
					options = domain.findMethodsFor(task, un);
					taskToExpand = task;
					break;
				}
			}
			
			if(taskToExpand != null)  {
				expandWithMethodInPlace(solution, taskToExpand, options.get(0), domain);
				logger.info("Expanded solution to: "+solution);
				logger.info("Current plan is: "+solution.getOrderedTasks());
			} else {
				logger.warning("Could not find a task to expand Task Network "+solution);
				return null;
			}
			
		}
		return solution;
	}
	
	public LinkedList<Operator> pfdHTN(State s0, TaskNetwork problem, HTNDomain domain) {
		if(problem.isEmpty()) {
			return new LinkedList<Operator>();
		}
		Task t = problem.getUnpreceededTask();
		if(t.isPrimitive()) {
			//Ghallab expects there to be more than one operator here
			Operator active = t.op;
			if(active == null) {
				return null;//Null here means failure
			} else {
				if(!t.un.unifies(t, active)) {
					return null;
				} else {
					t.op.apply(t.un);
				}
			}
			TaskNetwork nTn = new TaskNetwork(problem);
			nTn.removeTask(t);
			State newS = s0.applyOperator(active, t.un);
			//debugging code
			assert(newS != null);
			if(newS == null) stopAndDebug(nTn);
			
			LinkedList<Operator> pi = pfdHTN(newS, nTn, domain);
			if(pi == null) {
				logger.warning("Could not continue to decompose network "+nTn);
				return null;
			} else {
				pi.offerFirst(active);
				return pi;
			}
		} else { //t is not primitive
			Unifier un = new Unifier();
			List<MethodOption> active = domain.findMethodsFor(t, s0, un);
			if(active.isEmpty()) {
				logger.warning("No options found for task "+t+" in network "+problem);
				return null;
			}
			MethodOption option = active.get(random.nextInt(active.size()));
			TaskNetwork network = delta(problem, t, option, false, domain);
			
			return pfdHTN(s0, network, domain);
		}
	}
	
	/**
	 * Refines the HTN by in place expanding the designated task using the specified method. 
	 * Expansion consists of removing the task from the network and replacing all constraints
	 * that referred to it by constraints that refer to elements in the expanded network.
	 * 
	 * 
	 * @param problem
	 * @param task
	 * @param domain TODO
	 * @param method
	 */
	protected void expandWithMethodInPlace(TaskNetwork problem, Task task, MethodOption mo, HTNDomain domain) {
		delta(problem, task, mo, true, domain);
	}
	
	/**
	 * 
	 * @param network
	 * @param task
	 * @param mo
	 * @param domain TODO
	 * @return
	 */
	protected TaskNetwork expandWithMethod(TaskNetwork network, Task task, MethodOption mo, HTNDomain domain) {
		return delta(network, task, mo, false, domain);
	}
	
	/**
	 * Refines the HTN by expanding the designated task using the specified method. 
	 * Expansion consists of removing the task from the network and replacing all constraints
	 * that referred to it by constraints that refer to elements in the expanded network. 
	 * This method roughly corresponds (minus the before and after constraints) to the delta
	 * operator found in the <i>Automated Planning: Theory and Practice</i> book.
	 * @param task
	 * @param domain TODO
	 * @param problem
	 * @param method
	 */
	private final TaskNetwork delta(TaskNetwork network, Task task, MethodOption mo, boolean inPlace, HTNDomain domain) {
		assert(network.hasTask(task));
		assert(mo.m.getTask().equals(task));
		logger.info("Expanding task '"+task.getName()+"' with method '"+mo.m.getName()+"'");
		
		if(!inPlace) {
			network = new TaskNetwork(network);
		}
		
		List<Constraint> constraintsAfter = network.findConstraintsWithTaskAfter(task);
		List<Constraint> constraintsBefore = network.findConstraintsWithTaskBefore(task);
		network.removeTask(task);
		
		TaskNetwork subst = mo.m.getInstantiatedTaskNetwork(domain, mo.un);
		for(Task t:subst.getTasks()) {
			network.addTask(t);
		}
		
		for(Constraint c:constraintsBefore) {
			network.addBeforeConstraint(subst.getLastTask(), c.getTask2());
		}
		
		for(Constraint c:constraintsAfter) {
			network.addBeforeConstraint(c.getTask1(), subst.getFirstTask());
		}
		network.addConstraints(subst.constraints.toArray(new Constraint[] {}));
		
		return network;
	}
	
	public List<Operator> solveHTN(String domainFile, String problemFile) throws IOException, ParseException {
		HTNParser parser = new HTNParser();
		HTNDomain htnDomain = parser.parseDomain(new FileReader(domainFile));
		Problem problem = parser.parseProblem(new FileReader(problemFile));
		//return solveHTN(problem.getS0(), problem.getTn(), htnDomain).getOrderedTasks();
		return pfdHTN(problem.getS0(), problem.getTn(), htnDomain);
	}
	
	private final void stopAndDebug(TaskNetwork htn) {
		try{
			FileWriter writer = new FileWriter("debug.dot");
			HTNDotConverter.printHTNDot(writer, htn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.warning("Error running solver, stopping and debugging");
		throw new RuntimeException("Error running solver, stopping and debugging");
	}
}
