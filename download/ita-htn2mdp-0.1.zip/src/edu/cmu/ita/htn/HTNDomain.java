/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import jason.asSemantics.Unifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;


/**
 * An HTN domain
 * @author meneguzzi
 *
 * TODO optimize method finding algorithms
 */
public class HTNDomain {
	private static final Logger logger = Logger.getLogger(HTNDomain.class.getName());
	
	protected List<Method> methods;
	protected List<Task> actions;
	
	protected HashMap<Task,Task> instances;
	
	/**
	 * 
	 */
	public HTNDomain() {
		this.methods = new ArrayList<Method>();
		this.actions = new ArrayList<Task>();
		this.instances = new HashMap<Task,Task>();
	}
	
	public HTNDomain(List<Method> methods, List<Task> tasks) {
		this.methods = new ArrayList<Method>(methods);
		this.actions = new ArrayList<Task>(tasks);
		this.instances = new HashMap<Task,Task>();
	}
	
	
	public void addMethod(Method m) {
		this.methods.add(m);
	}
	
	public void addAction(Task t) {
		this.actions.add(t);
	}
	
	/**
	 * Finds all relevant methods for {@link Task} task.
	 * 
	 * @param task
	 * @return
	 * 
	 * @deprecated See {@link #findMethodsFor(Task, Unifier)}.
	 */
	public List<Method> findMethodsFor(Task task) {
		List<Method> relevantMethods = new ArrayList<Method>();
		Unifier un = new Unifier();
		for(Method method:methods) {
			if(un.unifies(method.getTask(), task)) {
				relevantMethods.add(method);
			} else {
				un.clear();
			}
		}
		return relevantMethods;
	}
	
	/**
	 * Finds all relevant methods for {@link Task} task.
	 * 
	 * @param task
	 * @return
	 *
	 */
	public List<MethodOption> findMethodsFor(Task task, Unifier un) {
		List<MethodOption> options = new ArrayList<MethodOption>();
		
		Unifier newUn = new Unifier();
		for(Method m:methods) {
			newUn.compose(un);
			if(newUn.unifies(m.getTask(), task) ) {
				options.add(new MethodOption(m, newUn));
				newUn = new Unifier();
			} else {
				newUn.clear();
			}
		}
		
		return options;
	}
	
	/**
	 * Finds all relevant methods for {@link Task} task and filters equivalent options away, according to 
	 * {@link MethodOption#equals(Object)}, an option is the same if it involves the same {@link Method} 
	 * under the same {@link Unifier}.
	 * 
	 * @param task
	 * @return
	 *
	 */
	public List<MethodOption> findMethodsFor(Task task, State s, Unifier u) {
		List<MethodOption> options = new ArrayList<MethodOption>();
		
		Unifier newU = new Unifier();
		for(Method m:methods) {
			newU.compose(u);
			Iterator<Unifier> iu;
			if(newU.unifies(m.getTask(), task) && (iu = m.getPossibleUnifiers(s, newU)) != null) {
				while(iu.hasNext()) {
					MethodOption option = new MethodOption(m, iu.next());
					//we only add methods that do not already exist
					if(!options.contains(option)) {
						options.add(option);
					}
				}
				newU = new Unifier();
			} else {
				newU.clear();
			}
		}
		
		return options;
	}
	
//	public List<MethodOption> findMethodsFor(Task task, State s, Unifier u) {
//		List<MethodOption> options = new ArrayList<MethodOption>();
//		
//		Unifier newU = new Unifier();
//		for(Method m:methods) {
//			newU.compose(u);
//			if(newU.unifies(m.getTask(), task) && m.applicable(s, u)) {
//				options.add(new MethodOption(m, newU));
//				newU = new Unifier();
//			} else {
//				newU.clear();
//			}
//		}
//		
//		return options;
//	}
	
	/**
	 * Returns the list of primitive tasks in this domain.
	 * @return
	 */
	public List<Task> getPrimitiveTasks() {
		return actions;
	}
	
	/**
	 * Post process all primitive tasks in the domain to associate appropriate operators for tasks
	 * that have no possible decompositions.
	 * TODO this is a stopgap method to help in the parsing of HTN domains from files, 
	 * TODO we should make a permanent solution to this.
	 * 
	 */
	public void postProcessPrimitiveTasks() throws Exception {
		for(Method m:methods) {
			for(Task task:m.getTaskNetwork().getTasks()) {
				Unifier un = new Unifier();
				//If a task has no possible substitutions, either the task is primitive 
				//(so we find an operator to associate to it), or the domain is poorly specified
				if(this.findMethodsFor(task, un).isEmpty()) {
					un = new Unifier();
					List<Operator> opers = findOperatorsFor(task, un);
					if(opers.isEmpty()) {
						throw new Exception("Invalid domain: task "+task+" has no applicable methods and no associated operators");
					} else {
						if(opers.size() > 1) {
							logger.warning("More than one operator is applicable to primitive task "+task+" "+opers);
						}
						task.op = opers.get(0);
					}
				}
			}
		}
	}
	
	/**
	 * Finds operators that match the supplied task
	 * @param task
	 * @param un
	 * @return
	 */
	public List<Operator> findOperatorsFor(Task task, Unifier un) {
		List<Operator> opers = new ArrayList<Operator>();
		for(Task tPrimitive:actions) {
			if(un.unifies(task, tPrimitive)) {
				assert(tPrimitive.op != null);
				Operator op = new Operator(tPrimitive.op);
				op.apply(un);
				opers.add(op);
			}
		}
		return opers;
	}
	
	/**
	 * Finds operators that match the supplied task
	 * @param task
	 * @param un
	 * @return
	 */
	public List<Operator> findOperatorsFor(State s, Task task, Unifier un) {
		List<Operator> opers = new ArrayList<Operator>();
		for(Task tPrimitive:actions) {
			Iterator<Unifier> iu;
			if(un.unifies(task, tPrimitive) 
				&& 
				(iu = tPrimitive.op.getPreconditions().consequence(s, un)) !=null) {
				while(iu.hasNext()) {
					Unifier u=iu.next();
					assert(tPrimitive.op != null);
					Operator op = new Operator(tPrimitive.op);
					u.compose(un);
					op.apply(u);
					opers.add(op);
				}
			}
		}
		return opers;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Actions: "+actions);
		sb.append("Methods: "+methods);
		return sb.toString();
	}

	/**
	 * 
	 * @param t TODO
	 * @return
	 */
	public Task instantiateTask(Task t, Unifier un) {
		Task tInstance = new Task(t);
		t.instanceCount++;
		tInstance.isInstance = true;
		tInstance.apply(un);
		if(instances.containsKey(tInstance)) {
			Task tEx = instances.get(tInstance);
			tInstance.instanceCount = tEx.instanceCount++;
			t.instanceCount = tEx.instanceCount;
		} else {
			instances.put(tInstance, tInstance);
		}
		return tInstance;
//		return t.instantiateTask(un);
	}
}
