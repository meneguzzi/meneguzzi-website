/**
 * Created on Dec 21, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import jason.asSemantics.Unifier;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * This class represents a disjunction of possible states. We demand that all states in a {@link MultiState} are ground.
 * This is the class that will have a BDD/MDD.
 * @author meneguzzi
 *
 */
public class MultiState implements Iterable<State> {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected final Collection<State> states;
	
	public MultiState() {
		states = new HashSet<State>();
	}
	
	public MultiState(State s) {
		this();
		states.add(new State(s));
	}
	
	public MultiState(MultiState ms) {
		this();
		for(State s:ms.states) {
			states.add(new State(s));
		}
	}
	
	/**
	 * Constructor with the option of making a shallow copy of the states within the {@link MultiState}, 
	 * shallow copies should only be used once the contents of a state are guaranteed to remain
	 * static and are all ground. 
	 * @param s
	 * @param deepCopy
	 */
	public MultiState(State s, boolean deepCopy) {
		this();
		if(deepCopy) {
			states.add(new State(s));
		} else {
			states.add(s);
		}
	}
	
	/**
	 * Constructor with the option of making a shallow copy of the states within the {@link MultiState}, 
	 * shallow copies should only be used once the contents of a state are guaranteed to remain
	 * static and are all ground.
	 * @param ms
	 * @param deepCopy
	 */
	public MultiState(MultiState ms, boolean deepCopy) {
		this();
		if(deepCopy) {
			for(State s:ms.states) {
				states.add(new State(s));
			}
		} else {
			for(State s:ms.states) {
				states.add(s);
			}
		}
	}
	
	/**
	 * Adds the specified state to this multistate
	 * @param s
	 * @return
	 */
	public final boolean addState(State s) {
		assert(s.isGround());
		assert(s.isConsistent());
		return states.add(s);
	}
	
	/**
	 * Removes the specified state from this multistate
	 * @param s
	 * @return
	 */
	public final boolean removeState(State s) {
		return states.remove(s);
	}
	
	/**
	 * Returns whether or not any state in this multistate supports the specified state
	 * @param s
	 * @return
	 */
	public boolean supports(State s) {
		for(State s2:states) {
			if(s2.supports(s))
				return true;
		}
		
		return false;
	}
	
	/**
	 * Returns whether or not this multistate supports a {@link LogicExpression} <code>expr</code>, 
	 * a multistate supports an expression if the expression is a logic consequence of any of its 
	 * states under the supplied unifier.
	 * @param expr
	 * @param un
	 * @return
	 */
	public boolean supports(LogicExpression expr, Unifier un) {
		for(State s:states) {
			if(expr.consequence(s, un).hasNext()) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param ms
	 * @return
	 */
	public boolean addAll(MultiState ms) {
		boolean res = false;
		for(State s:ms.states) {
			res |= this.states.add(s);
		}
		return res;
	}
	
	/**
	 * Returns whether or not this State intersects with s
	 * @param s
	 * @return
	 */
	public boolean intersects(MultiState ms) {
		for(State s:ms.states) {
			if(this.states.contains(s)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param ms
	 * @return
	 */
	public boolean removeAll(MultiState ms) {
		return this.states.removeAll(ms.states);
	}
	
	/**
	 * Returns a list of the possible states
	 * @param s
	 * @return
	 */
	public Collection<State> supportingStates(State s) {
		LinkedList<State> res = new LinkedList<State>();
		for(State s2:states) {
			if(s2.supports(s)) {
				res.add(s2);
			}
		}
		return res;
	}
	
	/**
	 * 
	 * @param op
	 * @param u
	 * @return
	 */
	public MultiState applyOperator(Operator op, Unifier u) {
		MultiState res = new MultiState();
		for(State s:states) {
			State s2 = s.applyOperator(op, u);
			if(s2 != null) {
				res.addState(s2);
			}
		}
		return res;
	}
	
	/**
	 * Return the number of individual states comprising the disjunction in this state.
	 * @return
	 */
	public final int size() {
		return states.size();
	}
	
	/**
	 * Returns whether or not this state contains no substates
	 * @return
	 */
	public final boolean isEmpty() {
		return states.isEmpty();
	}

//	/* (non-Javadoc)
//	 * @see java.lang.Iterable#iterator()
//	 */
//	@Override
//	public Iterator<State> iterator() {
//		return states.iterator();
//	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("{");
		for(Iterator<State> i = states.iterator(); i.hasNext();) {
			sb.append(i.next() + (i.hasNext() ? " v " : ""));
		}
		sb.append("}");
		return sb.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Iterable#iterator()
	 */
	@Override
	public Iterator<State> iterator() {
		return states.iterator();
	}
}
