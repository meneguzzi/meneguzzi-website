/**
 * Created on Oct 10, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import jason.asSemantics.Unifier;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;


/**
 * A state in the HTN, which consists of a conjunction of {@link Proposition}s represented as a set.
 * Here we use the open world assumption
 * XXX Added the Comparable interface to try and speed things up a bit when using multisets
 * @author meneguzzi
 *
 */
public class State extends HashSet<Proposition> implements Comparable<State> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer hashCodeCache = null;
	
	/**
	 * 
	 */
	public State(Collection<Proposition> state) {
		super(state);
	}
	
	/**
	 * Helper method
	 * @param state
	 */
	public State(Proposition ... state) {
		super();
		for(Proposition p:state) {
			this.add(p);
		}
	}
	
	/**
	 * Copy constructor
	 * @param s
	 */
	public State(State s) {
		super();
		for(Proposition p:s) {
			this.add(new Proposition(p));
		}
	}
	
	/**
	 * Constructor with the option of making a shallow copy of the states within the {@link State}, 
	 * shallow copies should only be used once the contents of a state are guaranteed to remain
	 * static and are all ground.
	 * 
	 * @param s
	 * @param deepCopy
	 */
	public State(State s, boolean deepCopy) {
		super();
		if(deepCopy) {
			for(Proposition p:s) {
				this.add(new Proposition(p));
			}
		} else {
			for(Proposition p:s) {
				this.add(p);
			}
		}
	}

	/**
	 * Empty constructor
	 */
	public State() {
		super();
	}
	
	/* (non-Javadoc)
	 * @see java.util.HashSet#add(java.lang.Object)
	 */
	@Override
	public boolean add(Proposition e) {
		boolean modified = super.add(e);
		if(modified) {
			hashCodeCache = null;
		}
		return modified;
	}
	
	/* (non-Javadoc)
	 * @see java.util.HashSet#remove(java.lang.Object)
	 */
	@Override
	public boolean remove(Object o) {
		boolean modified = super.remove(o);
		if(modified) {
			hashCodeCache = null;
		}
		return modified;
	}
	
	/**
	 * Returns whether or not this state is consistent. A state <i>S</i> with 
	 * propositions <i>p</i> is consistent iff 
	 * <i>&forall; p, &not;&exists;&not;p</i>.
	 *   
	 * @return
	 */
	public boolean isConsistent() {
		for(Proposition p:this) {
			if(this.contains(p.getNegated())) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Returns whether or not this state is ground
	 * @return
	 */
	public final boolean isGround() {
		for(Proposition p:this) {
			if(!p.isGround()) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Applies a unifier to this state
	 * @param u
	 * @return Whether the unifier changed any variable in this state.
	 */
	public boolean apply(Unifier u) {
		if(this.isGround()) {
			return false;
		}
		State sBackup = new State(this);
		boolean succ = true;
		for(Proposition p:sBackup) {
			if(!p.apply(u)) {
				succ = false;
				break;
			}
		}
		if(succ) {
			this.clear();
			this.addAll(sBackup);
		}
		return succ;
	}
	
	/**
	 * Returns the intersection between <code>this</code> and <code>s</code>.
	 * @param s
	 * @return
	 */
	public State intersection(State s) {
		State inter = new State();
		for(Proposition p:s) {
			if(this.contains(p)) {
				inter.add(p);
			}
		}
		return inter;
	}
	
	public State negateAll() {
		State res = new State();
		for(Proposition p:this) {
			res.add(p.getNegated());
		}
		return res;
	}
	
	/**
	 * Returns whether or not this State intersects with s
	 * @param s
	 * @return
	 */
	public boolean intersects(State s) {
		for(Proposition p:s) {
			if(this.contains(p)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns whether or not this state supports another state s, this will return true if
	 * <i>this &supe; s</i>. At the moment, we just require <i>this</i> to contains all 
	 * elements from <i>s</i>.
	 * 
	 * TODO Make sure what is the assumption we need to know here, whether open world or closed world
	 * 
	 * @param s
	 * @return
	 */
	public boolean supports(State s) {
		for(Proposition p:s) {
			if(!this.contains(p) || this.contains(p.getNegated())) {
				return false;
			}
		}
		//return this.containsAll(s);
		return true;
	}
	
//	/**
//	 * Returns whether or not this state (assumed to be ground), supports the (possibly not ground) state specification
//	 * <code>s</code>.
//	 * 
//	 * TODO Change this to an iterator to make the whole process more efficient
//	 * XXX Incomplete, make sure we actually want to create this huge set of unifiers!!
//	 * 
//	 * @param u
//	 * @param s
//	 * @return
//	 */
//	public List<Unifier> supports(State s, Unifier u) {
//		if(this.isGround()) {
//			LinkedList<Unifier> res = new LinkedList<Unifier>();
//			HashMap<Proposition, Collection<Proposition>> candidates = new HashMap<Proposition, Collection<Proposition>>();
//			
//			//For each proposition in s, either there is an exact match for it (if s is ground), 
//			//or there is a number of candidates to be unified with s 
//			for(Proposition p:s) {
//				if(s.isGround()) {
//					if(!this.contains(p)) {
//						res.clear();
//						return res;
//					}
//				} else {
//					Collection<Proposition> c = findUnifiablePropositionsFor(p);
//					if(c.isEmpty()) {
//						res.clear();
//						return res;
//					} else {
//						candidates.put(p, c);
//					}
//				}
//			}
//			
//			return res;
//		} else {
//			throw new RuntimeException("Tried to check for support from a non-ground state "+this);
//		}
//	}
//	
//	/**
//	 * 
//	 * @param prop
//	 * @return
//	 */
//	private final Collection<Proposition> findUnifiablePropositionsFor(Proposition prop) {
//		LinkedList<Proposition> res = new LinkedList<Proposition>();
//		//if the proposition is ground we only need to find an exact match
//		if(prop.isGround()) {
//			if(this.contains(prop)) {
//				res.add(prop);
//			}
//			return res;
//		}
//		for(Proposition p:this) {
//			if(p.getFunctor().equals(prop) && p.getArity() == prop.getArity()) {
//				res.add(p);
//			}
//		}
//		return res;
//	}
	
	/**
	 * This implementation is really crappy, we need to create an iterator here that does this
	 * in a better way.
	 * @param p
	 * @param un
	 * @return
	 */
	public Iterator<Proposition> getUnifiablePropositions(final Proposition p, final Unifier un) {
		State s = new State();
		final Unifier un2 = new Unifier();
		
		if(p == Proposition.TRUE) {
			return s.iterator();
		} else if(p == Proposition.FALSE) {
			return null;
		}
		
		if(p.isGround()) {
			if(this.contains(p)) {
				s.add(p);
			} else {
				return null;
			}
		} else {
			for(Proposition pLocal:this) {
				un2.compose(un);
				if(un2.unifies(p, pLocal)) {
					un2.clear();
					s.add(pLocal);
				}
			}
		}
		
		return s.iterator();
	}
	
	/**
	 * Applies the operator 
	 * @param op
	 * @param u
	 * @return
	 */
	public State applyOperator(Operator op, Unifier u) {
		try {
			if(!op.isGround()) {
				op = op.instantiateOperator(u);
			}
		} catch (Exception e) {
			return null;
		}
		if(op.applicable(this)) {
			return op.applyOperator(this);
		} else {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(State o) {
		int len1 = this.size();
		int len2 = o.size();
		int n = Math.min(len1, len2);
		//This is an approximation of lexicographical comparison, 
		//we compare each proposition in the same order (since TreeSet is ordered)
		//and if they differ, we return that individual comparison.
		//If there is no difference in the characters when one set is shorter than the other
		//the shorter set comes first.
		Iterator<Proposition> i1 = this.iterator();
		Iterator<Proposition> i2 = o.iterator();
		Iterator<Proposition> iMain = (n==len1)?i1:i2;
		while(iMain.hasNext()) {
			Proposition p1 = i1.next();
			Proposition p2 = i2.next();
			int comp = p1.compareTo(p2);
			if(comp!=0) {
				return comp;
			}
		}
		return len1 - len2;
//		if(this.equals(o)) {
//			return 0;
//		} else {
//			if(this.size() > o.size()) {
//				return 1;
//			} else if(this.size() < o.size()) {
//				return -1;
//			} else { // If the sets have exactly the same size then compare them as strings
//				return this.toString().compareTo(o.toString());
//			}
//		}
	}
	
	/* (non-Javadoc)
	 * @see java.util.AbstractSet#hashCode()
	 */
	@Override
	public int hashCode() {
		if(hashCodeCache == null) {
			hashCodeCache = super.hashCode();
		}
		return hashCodeCache;
	}
}
