/**
 * Created on Jan 6, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import jason.asSemantics.Unifier;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * A crude first implementation of a logic expression
 * @author meneguzzi
 *
 */
public class LogicExpressionImpl implements LogicExpression {
	
	public enum LogicalOp { 
        none   { public String toString() { return ""; } }, 
        not    { public String toString() { return "not "; } }, 
        and    { public String toString() { return " & "; } },
        or     { public String toString() { return " | "; } };
    }
	
	private LogicalOp op = LogicalOp.none;
	private LogicExpression lhs,rhs;
	
	/**
	 * 
	 */
	public LogicExpressionImpl(LogicExpression lhs, LogicalOp oper, LogicExpression rhs) {
		this.lhs = lhs;
		this.op = oper;
		this.rhs = rhs;
	}
	
	/**
	 * 
	 */
	public LogicExpressionImpl(LogicExpression lhs, LogicalOp oper) {
		this.lhs = lhs;
		this.op = oper;
	}

	/* (non-Javadoc)
	 * @see edu.cmu.ita.htn.LogicExpression#consequence(edu.cmu.ita.htn.State, jason.asSemantics.Unifier)
	 */
	@Override
	public Iterator<Unifier> consequence(final State s, final Unifier un) {
		switch (op) {
		case not:
			if(!lhs.consequence(s, un).hasNext()) {
				return createUnifIterator(un);
			}
			break;
		case and:
			return new Iterator<Unifier>() {
                Iterator<Unifier> ileft   = getLHS().consequence(s,un);;
                Iterator<Unifier> iright  = null;
                Unifier           current = null;
                boolean           needsUpdate = true;
                
                public boolean hasNext() {
                    if (needsUpdate) 
                        get();
                    return current != null;
                }
                public Unifier next() {
                    if (needsUpdate)
                        get();
                    Unifier a = current;
                    if (current != null)
                        needsUpdate = true;
                    return a;
                }
                private void get() {
                    needsUpdate = false;
                    current     = null;
                    while ((iright == null || !iright.hasNext()) && ileft.hasNext())
                        iright = getRHS().consequence(s, ileft.next());
                    if (iright != null && iright.hasNext())
                        current = iright.next();
                }
                public void remove() {}
            };
			
		case or:
			return new Iterator<Unifier>() {
                Iterator<Unifier> ileft  = getLHS().consequence(s,un);
                Iterator<Unifier> iright = null;
                Unifier current          = null;
                boolean needsUpdate      = true;
                
                public boolean hasNext() {
                    if (needsUpdate) 
                        get();
                    return current != null;
                }
                public Unifier next() {
                    if (needsUpdate) 
                        get();
                    Unifier a = current;
                    if (current != null)
                        needsUpdate = true;
                    return a;
                }
                private void get() {
                    needsUpdate = false;
                    current     = null;
                    if (ileft != null && ileft.hasNext())
                        current = ileft.next();
                    else {
                        if (iright == null)
                            iright = getRHS().consequence(s,un);
                        if (iright != null && iright.hasNext())
                            current = iright.next();
                    }
                }
                public void remove() {}
            };
		default:
			break;
		}
		return null;
	}

	/** creates an iterator for a list of unifiers */
    static public Iterator<Unifier> createUnifIterator(final Unifier... unifs) {
        return new Iterator<Unifier>() {
            int i = 0;
            public boolean hasNext() {
                return i < unifs.length;
            }
            public Unifier next() {
                return unifs[i++];
            }
            public void remove() {}
        };
    }

	/**
	 * @return the op
	 */
	public final LogicalOp getOp() {
		return op;
	}

	/**
	 * @return the lhs
	 */
	public final LogicExpression getLHS() {
		return lhs;
	}

	/**
	 * @return the rhs
	 */
	public final LogicExpression getRHS() {
		return rhs;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() {
		if(rhs == null) {
			return new LogicExpressionImpl((LogicExpression) lhs.clone(), op);
		} else {
			return new LogicExpressionImpl((LogicExpression) lhs.clone(), op, (LogicExpression) rhs.clone());
		}
	}

	/* (non-Javadoc)
	 * @see edu.cmu.ita.htn.LogicExpression#apply(jason.asSemantics.Unifier)
	 */
	@Override
	public boolean apply(Unifier u) {
		boolean ret = false;
		ret |= lhs.apply(u);
		if(rhs != null) {
			ret |= rhs.apply(u);
		}
		return ret;
	}

	/* (non-Javadoc)
	 * @see edu.cmu.ita.htn.LogicExpression#isUnary()
	 */
	@Override
	public boolean isUnary() {
		return rhs == null;
	}
	
	/* (non-Javadoc)
	 * @see edu.cmu.ita.htn.LogicExpression#getPropositions()
	 */
	@Override
	public Collection<Proposition> getPropositions() {
		Collection<Proposition> res = new ArrayList<Proposition>();
		if(lhs != null) {
			res.addAll(lhs.getPropositions());
		}
		if(rhs != null) {
			res.addAll(rhs.getPropositions());
		}
		return res;
	}
	
	@Override
    public String toString() {
        if (isUnary()) {
            return op+"("+lhs+")";
        } else {
            return "("+lhs+op+rhs+")";
        }
    }
}
