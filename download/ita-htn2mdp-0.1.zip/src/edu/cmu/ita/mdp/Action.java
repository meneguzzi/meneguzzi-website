package edu.cmu.ita.mdp;

public class Action { 

	protected String name;
	// each state has action 0 through nActions
	protected int id; 
	// query (e.g., door id) if info-action; null otherwise
	protected String query = null; 
	// whether this action is information-gathering action
	boolean isInfo = false;
	
	protected double cost = 0; // cost of taking this action
	
	public Action(String s, int id) {
		this.name = s;
		this.id = id;
		isInfo = false;
	}	
	
	public Action(String name, int id, boolean isInfoAction) {
		this(name, id);
		isInfo = isInfoAction;
	}
	
	public int getId() { return id; }
	
	public boolean isInfoAction() { return isInfo; }

	public void setInfoAction(boolean b) { isInfo = b; }
	
	public String getName() { return name; }
	
	public String toString() { return name + ":" + id + " cost=" + cost;  }
	
	public boolean equals(Object a) {
		return ((Action)a).id == id;
	}
	
	public String getQuery() { return query; }
	
	public void setQuery(String query) {
		this.query = query;
	}
	public int hashCode() {
		return id; 
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}
	public double getCost() {
		return cost;
	}

}
