package edu.cmu.ita.mdp;

/**
 * An MDP state, composed of an ID and a reward value;
 * @author meneguzz
 * @modified jeanoh
 */
import java.util.Vector;

import edu.cmu.ita.util.IndexedObject;

public class State extends IndexedObject {

	protected String id;
	protected int intId; //This is a hack to solve the problem of the intId
	protected int reward;
	protected Vector<IntegerObservation> observations = new Vector<IntegerObservation>();

	protected String label;
	double _value = 0;
	Vector<Action> actions; // action queries that are specific to each state --jean  
	
	Action _optAction;
	boolean _goal = false;
	
	private static int INDEX = -1;
	
	public State(int intId, String id, String label, int reward) {
		super();
		this.intId = intId;
		this.id = id;
		this.reward = reward;
		this.actions = new Vector<Action>();
	}
	
	public State(String id, String label, int reward) {
		this(Integer.parseInt(id), id, label, reward);
	}
	
	public State(String id, int reward) {
		this(Integer.parseInt(id), id, null, reward); 
	}

	public void addAction(Action a) {
		actions.add(a);
	}
	public Vector<Action> getActions() { return actions; }	
	public Action getAction(int actionId) { return actions.get(actionId); }
	
	public void addObservation(IntegerObservation o) {
		observations.add(o);
	}

	public void setObservations(Vector<IntegerObservation> observations2) {
		this.observations = observations2;		
	}
	
	public Vector<IntegerObservation> getObservations() { return observations; }
	
	public String getId() {
		return id;
	}
	
	public int getIntId() {
		return intId;
	}

	public int getReward() {
		return reward;
	}

	public String toString() {
		//return id + " r=" + reward;
		return label + " r=" + reward;
	}

	// jeanoh
	public String getLabel() {
		return label;
	}

	// optimal policy
	public void setOptimalAction(Action id) {
		_optAction = id;
	}

	public Action getOptimalAction() {
		return _optAction;
	}

	// long-term expected reward of this state
	public void setValue(double v) {
		_value = v;
	}

	public double getValue() {
		return _value;
	}

	// goal state?
	public void setGoal(boolean b) {
		_goal = b;
	}

	public boolean isGoal() {
		return _goal;
	}
	
	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	
	/**
	 * @param reward the reward to set
	 */
	public void setReward(int reward) {
		this.reward = reward;
	}

	public boolean equals(State o) {
		return super.equals(o);
	}
	public int hashCode() { return super.hashCode(); }

	@Override
	protected void setIndex() {
		index = ++INDEX;
	}

}
