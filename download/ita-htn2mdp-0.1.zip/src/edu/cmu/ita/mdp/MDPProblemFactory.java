package edu.cmu.ita.mdp;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.plan.PlanTreeNode;

public class MDPProblemFactory {
	private static MDPProblemFactory factorySingleton;
	
	private MDPProblemFactory() {
		//Nothing for now
	}
	
	public static MDPProblemFactory getInstance() {
		if(factorySingleton == null) {
			factorySingleton = new MDPProblemFactory();
		}
		
		return factorySingleton;
	}
	
	/**
	 * Creates an {@link MDPProblem} from a {@link PlanLibrary}, with the 
	 * specified  <em>errorProbability</em> and <em>discountFactor</em>.
	 * @param library
	 * @param errorProbability
	 * @param discountFactor
	 * @return
	 */
	public MDPProblem fromPlanLibrary(PlanLibrary library, double errorProbability, double discountFactor) {
		List<PlanTreeNode> observableNodes = library.getObservableNodes();
		List<State> states = new ArrayList<State>(observableNodes.size());
		
		for(PlanTreeNode node:observableNodes) {
			State state = new State(node.getId(), node.getReward());
			states.add(state);
		}
		
		List<String> actionLabels = new ArrayList<String>(library.getLabels());
		List<Action> actions = new ArrayList<Action>(actionLabels.size());
		int id=-1;
		for(String nm: actionLabels) actions.add(new Action(nm, ++id));
		
		List<TransitionMatrix> matrices = new ArrayList<TransitionMatrix>(actions.size());
		for(Action action:actions) {
			TransitionMatrix matrix = new TransitionMatrix(states.size(), action);
			matrix.populateTransitionMatrix(library);
			matrix.normalizeToOne(errorProbability);
			matrices.add(matrix);
		}
		
		BasicMDPProblem problem = new BasicMDPProblem(states, actions, matrices, discountFactor);
		
		return problem;
	}
	
	/**
	 * Creates an {@link MDPProblem} from a {@link PlanLibrary}, with the 
	 * specified  errorProbability.
	 * 
	 * @param library
	 * @param errorProbability
	 * @return
	 */
	public MDPProblem fromPlanLibrary(PlanLibrary library, double errorProbability) {
		return this.fromPlanLibrary(library, errorProbability, 0);
	}
	
	/**
	 * Creates an {@link MDPProblem} from a {@link PlanLibrary}. 
	 * @param library
	 * @return
	 */
	public MDPProblem fromPlanLibrary(PlanLibrary library) {
		return fromPlanLibrary(library, 0);
	}
	
	
	public MDPProblem fromFile(File file) {
		return null;
	}
}
