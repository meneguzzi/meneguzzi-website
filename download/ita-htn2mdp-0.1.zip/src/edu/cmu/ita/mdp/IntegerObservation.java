package edu.cmu.ita.mdp;



public class IntegerObservation extends UserObservation {

	/** 
	 * the value of observation
	 */
	protected int value; 
	
	public IntegerObservation(int v) {
		super();
		value = v;
	}
	
	public int intValue() { return value; }
	
	public String toString() {
		return String.valueOf(value) + "@" + this.timeStamp;
	}
	
	public int hashCode() {
		return this.value;
	}
	
	@Override
	public boolean equals(Object o) {
		if(!(o instanceof IntegerObservation)) return false;
		IntegerObservation io = (IntegerObservation) o;
		return this.value == io.value;
	}
	
}
