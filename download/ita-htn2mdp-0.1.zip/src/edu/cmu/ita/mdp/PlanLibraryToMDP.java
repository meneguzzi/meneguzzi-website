package edu.cmu.ita.mdp;


import java.io.File;
import java.io.FileWriter;
import java.util.logging.Logger;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.tree.parser.PlanTreeBuilder;

public class PlanLibraryToMDP {
	private static Logger logger = Logger.getLogger(PlanLibraryToMDP.class.getName());
	
	protected File plInput;
	
	protected File mdpOutput;
	
	protected double transitionError = 0;
	
	protected double discountFactor = 0;
	
	/**
	 * Initializes the converter, processing command line parameters.
	 * TODO Improve the consistency checks for the parameter parsing.
	 * @param args
	 * @throws Exception
	 */
	PlanLibraryToMDP(String[] args) throws Exception {
		if(args.length == 0) {
			logger.warning("PlanLibraryToMDP requires at least the plan library specification.");
			throw new Exception("Insufficient parameters.");
		} else {
			plInput = new File(args[0]);
		}
		for(int i=1; i< args.length; i++) {
			if(args[i].equals("-o")) {
				mdpOutput = new File(args[++i]);
			} else if(args[i].equals("-e") || args[i].equals("--error")) {
				transitionError = Double.parseDouble(args[++i]);				
			} else if(args[i].equals("-d") || args[i].equals("--discount")) {
				discountFactor = Double.parseDouble(args[++i]);
			} else {
				logger.warning("Unknown parameter: "+args[i]);
			}
		}
	}
	
	/**
	 * Converts the plan library according to the parameters specified at the command line.
	 * @throws Exception
	 */
	public void convertPlanLibrary() throws Exception {
		PlanTreeBuilder builder = new PlanTreeBuilder();
		PlanLibrary library = builder.parsePlanTree(plInput);
		
		MDPProblemFactory factory = MDPProblemFactory.getInstance();
		
		MDPProblem problem = factory.fromPlanLibrary(library, transitionError, discountFactor);
		
		if(mdpOutput != null) {
			FileWriter writer = new FileWriter(mdpOutput);
			writer.write(problem.toString());
			writer.flush();
		} else {
			logger.info(problem.toString());
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			PlanLibraryToMDP main = new PlanLibraryToMDP(args);
			main.convertPlanLibrary();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
