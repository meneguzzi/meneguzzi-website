/**
 * @author jeanoh@cs.cmu.edu
 * @date Nov. 10, 2009
 */
package edu.cmu.ita.mdp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.logging.Logger;

public class DynamicMDPProblem implements MDPProblem {

	protected List<State> states;
	HashMap<String, State> _stateMap; // label -> state

	protected List<Action> actions;

	protected HashMap<Action, TransitionMatrix> transitionMatrices;

	protected double discount;
	
	/**
	 * The reward is defined as a weighted sum of reward from resulting state
	 * and the cost of taking action. Parameter gamma defines the weight of reward 
	 * from a resulting state; thus the weight of action cost is 1 - gamma.
	 */
	//public static double weightOfReward = 0.7; 

	Logger logger = Logger.getLogger(getClass().getName());
	
	public DynamicMDPProblem(List<State> states, List<Action> actions,
			List<TransitionMatrix> matrices, double discount) {
		this.states = states;
		this.actions = actions;
		this.transitionMatrices = new HashMap<Action, TransitionMatrix>(
				matrices.size());
		for (TransitionMatrix matrix : matrices) {
			transitionMatrices.put(matrix.action, matrix);
		}
		this.discount = discount;		
		_stateMap = new HashMap<String, State>(states.size()); // label -> state
		for (State s : states) {
			_stateMap.put(s.getLabel(), s);
		}
	}

	public void setDiscountFactor(double d) {
		discount = d;
	}
	
	/**
	 * Returns a hashmap that contains a set of states from which each observation can be found
	 * observation --> vector<Integer(StateId)>
	 */
	public HashMap<IntegerObservation, Vector<Integer>> getIntegerObservationMap(
			Vector<IntegerObservation> observations) {

		HashMap<IntegerObservation, Vector<Integer>> map = new HashMap<IntegerObservation, Vector<Integer>>(
				observations.size());
		for (IntegerObservation io : observations) {
			map.put(io, new Vector<Integer>());
		}
		for (State s : states) {
			Integer stateIndex = new Integer(s.getIndex());
			for (IntegerObservation obs : s.getObservations()) {
				try {
					Vector<Integer> sis = map.get(obs);
					sis.add(stateIndex);
				} catch (Exception ex) {
					ex.printStackTrace();
					System.out.println("obs=" + obs + " map=" + map
							+ "\nobsfound=" + map.get(obs));
					System.exit(0);
				}
			}
		}
		return map;
	}

	public State getState(int index) {
		return (State) states.get(index);
	}

	public State getStateByLabel(String label) {
		return (State) _stateMap.get(label);
	}

	/**
	 * Returns reward of taking action act from state s and reaching state sp as a result.
	 * Note that the reward is a weighted sum of the reward from resulting state 
	 * and the cost of taking action. Field weightOfReward defines the weight of reward, 
	 * and the weight of cost is (1-weightOfReward) accordingly.    
	 * @param s -- current state
	 * @param act -- action to take
	 * @param sp -- resulting state after taking action act from state s
	 */
	public double getReward(int s, Action act, int sp) {
		// reward from the resulting state
		double reward = (double) ((State) (states.get(sp))).getReward();
		// cost of taking this action
		double cost = act.getCost();
		//return (weightOfReward * reward) + ((1 - weightOfReward) * cost);
		return reward + cost;
	}

	@Override
	public double getDiscountFactor() {
		return discount;
	};

	@Override
	public List<Action> getActions() {
		return actions;
	}

	@Override
	public List<State> getStates() {
		return states;
	}

	@Override
	public Map<Action, TransitionMatrix> getTransitionMatrices() {
		return transitionMatrices;
	}

	@Override
	public double getTransitionProbability(int s, Action act, int sp) {
		TransitionMatrix tm = transitionMatrices.get(act);
		if(tm == null) {
			logger.info("act=" + act.getId() + "," + act.hashCode());// + "; m=" + this.transitionMatrices);
			for(Iterator<Action> i=this.transitionMatrices.keySet().iterator(); i.hasNext();) {
				Action action = i.next();
				System.out.println("  a=" + act + "; b=" + action );
			}
			System.exit(0);
		}
		return tm.get(s, sp);
	}

	@Override
	public Action getAction(int index) {
		return actions.get(index);
	}

	public Action getAction(int stateIndex, int actionIndex) {
		State state = getState(stateIndex);
		return state.getActions().get(actionIndex);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("discount: " + this.discount
				+ System.getProperty("line.separator"));
		StringBuilder sbStates = new StringBuilder();
		StringBuilder sbRewards = new StringBuilder();
		for (State state : states) {
			sbStates.append(" " + state.id);
			sbRewards.append(" " + state.reward);
		}

		sb.append("states:" + sbStates.toString()
				+ System.getProperty("line.separator"));
//		sb.append("rewards:" + sbRewards.toString()
//				+ System.getProperty("line.separator"));

		sb.append("actions:");
		//sb.append(System.getProperty("line.separator"));
		for (Action action : actions) {
			sb.append(" " + action);
			//sb.append(System.getProperty("line.separator"));
		}
		sb.append(System.getProperty("line.separator"));

		for (TransitionMatrix matrix : transitionMatrices.values()) {
			sb.append(System.getProperty("line.separator") + matrix.toString());
		}
		sb.append(System.getProperty("line.separator"));

		sb.append("rewards+cost:");
		sb.append(System.getProperty("line.separator"));
		for (State state: states) {
			sb.append(state.id + "\n");			
			for (Action action: state.getActions()) {
				sb.append(" " + action.getName() + "=" + getReward(state.getIntId(), action, state.getIntId()));
				sb.append(System.getProperty("line.separator"));
			}
			sb.append(System.getProperty("line.separator"));
		}	
		
		return sb.toString();
	}

}
