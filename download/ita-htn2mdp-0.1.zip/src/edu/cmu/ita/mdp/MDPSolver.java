//jeanoh@cs.cmu.edu
package edu.cmu.ita.mdp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import java.util.logging.Logger;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.tree.parser.PlanParseException;
import edu.cmu.ita.pl.tree.parser.PlanTreeBuilder;

/**
 * Solver for MDP (S,A,Tr,R): states, actions, transition probabilities, rewards
 * jeanoh@cs.cmu.edu
 */
public class MDPSolver {

	MDPProblem _mdp;
	int _s0 = 0; // initial state
	public static int SEED = 2009;
	static Random _coin = new Random();
	static int _L_ITER = 5000; // max number of rounds during learning; to avoid
	// looping for too long
	static int _T_ITER = 50; // max number of rounds during testing; to avoid
	// looping for too long
	public static int _MOD = 50;
	static double _EPSILON = 0.001;

	public static final int VI = -9; // value iteration
	int algorithm = VI;
	private static Logger logger = Logger.getLogger(MDPSolver.class.getName());

	public MDPSolver(MDPProblem mdp) {
		_mdp = mdp;
	}

	public void printStateValues() {
		for (State s : _mdp.getStates()) {
			System.out.print(String.format("%.3f  ", s.getValue()));
		}
		System.out.println("");
	}

	public void solve() {
		switch (algorithm) {
		case VI:
		default:
			// reset state values
			for(State s: _mdp.getStates()) s.setValue(0);
			valueIteration();
			break;
		}
	}

	/**
	 * Value Iteration (Sutton&Barto 1998, p102) returns policy in HashMap
	 * (state -> action)
	 */
	private void valueIteration() {
		double delta = 99999;
		//int convcnt = 0;

		// while(true){ //|S| x |A| x |S|
		for (int iter = 0; iter < _L_ITER; ++iter) {
			//boolean cv = true;
			int convcnt = 0;
			for (State s : _mdp.getStates()) {
				double v = s.getValue();

				// DEBUG
				//if(s.getIntId() == 0) System.out.println("State"+ s.getLabel());
				Vector<Double> acts = new Vector<Double>(s.getActions().size());
				// Vector acts = new Vector(_mdp.getActions().size()); //
				// expected
				// value of
				// each
				// action
				for (Action action : s.getActions()) {
					//System.out.print("  " + action.getName());
					double vA = 0;
					for (State state2 : _mdp.getStates()) { // for each next state

						// DEBUG
//						if(s.getIntId() == 0 
//							&& _mdp.getTransitionProbability(s.getIntId(),action, state2.getIntId()) > 0 
//							//&& s.getId() == state2.getId()
//								) {
//							System.out.println("\t" + action.getName() + "->[" + state2.getLabel() + "] " 
//									+ "T" + _mdp.getTransitionProbability(s.getIntId(),action, state2.getIntId()) 
//									+ " R=("+ _mdp.getReward(s.getIntId(), action, state2.getIntId()) 
//									+ "+" + (_mdp.getDiscountFactor() * state2.getValue()) + ")");						 
//						}
						
						vA += (_mdp.getTransitionProbability(s.getIntId(),
								action, state2.getIntId())
								* (_mdp.getReward(s.getIntId(), action, state2
										.getIntId()) + (_mdp
										.getDiscountFactor() * state2
										.getValue())));
					}
					acts.add(vA);
					// DEBUG
					//if(iter == 2) System.out.println("  action=" + action.getName() + " rew=" + action.getCost());
				}
				// value of the best action
				double v2 = ((Double) Collections.max(acts)).doubleValue();
				s.setValue(v2);
				// DEBUG
				//if(s.getIntId() == 0) System.out.println(" value=" + v2);
				
				delta = Math.abs(v - v2);
				//if (delta > _EPSILON) cv = false;
				if (delta < _EPSILON) ++convcnt;
			}
			//if (cv)	++convcnt;

			if (iter % _MOD == 0) {
				logger.info("iter=" + iter + ", delta=" + delta);
				printStateValues();
			}
			++iter;
			if (convcnt == _mdp.getStates().size()) { //(convcnt > 10) {
				System.out.println("Converged! iter=" + iter);
				// return computeDeterministicPolicy();
				return;
			}
		}
		System.out.println("Fail to converge after " + _L_ITER + " iter");
		// return computeDeterministicPolicy();
	}

	/**
	 * Returns HashMap<Integer, Double> policy computePolicy(): auxiliary method
	 * of ValueIteration. returns a policy in HashMap (stateIndex -->
	 * optimalAction) After values have converged, an optimal action can be
	 * selected for every state, based on the long-term expected reward.
	 */
	public Policy computeDeterministicPolicy() {

		Policy policy = new Policy(_mdp.getStates(), _mdp.getActions()); // deterministic policy
		for (State s : _mdp.getStates()) {
			double v = s.getValue();
			Action bestAct = null;
			double bestActValue = 0;
			// DEBUG
//			System.out.println("Solver.computeDeterministicPolicy:State " + s.getIntId() + ": val=" + s.getValue());

			// for (Action action : _mdp.getActions()) {
			for (Action action : s.getActions()) {
//				System.out.print("\taction " + action.getName());

				double vA = 0;
				for (State state2 : _mdp.getStates()) { // for each next state
					vA += (_mdp.getTransitionProbability(s.getIntId(), action,
							state2.getIntId()) * state2.getValue());
					// DEBUG
//					System.out.println("  to" + state2.getId() + "=" +_mdp.getTransitionProbability(s.getIntId(), action,
//							state2.getIntId()) + " v(s2)=" + state2.getValue());
				}
				// DEBUG
//				System.out.println("=" + vA + " best=" + bestAct + "("
//						+ bestActValue + ")");

				if (bestAct == null || vA > bestActValue || vA == bestActValue
						&& _coin.nextDouble() > 0.5) {
					bestActValue = vA;
					bestAct = action;
				}
				// ++a;
			}
			s.setOptimalAction(bestAct);
			policy.set(s.getIntId(), bestAct.getId(), 1.0);
			// DEBUG
//			logger.info(s.getLabel() + " ==> " + bestAct + " s.opt="
//					+ s.getOptimalAction());
		}
		return policy;
	}
	
    public Policy computeBoltzmannPolicy(double temp) {
    	
		Policy policy = new Policy(_mdp.getStates(), _mdp.getActions()); // deterministic policy
		for (State s : _mdp.getStates()) {
			
			int nActions = s.getActions().size();
			// normalized values for expected value of taking this action from the current state
			double[] normValues = new double[nActions];
			// old range of values must be collected from the current values
			double sum = 0;
			
			for (int actionId = 0; actionId < nActions; ++actionId) {
				Action action = s.getAction(actionId);
				double vA = 0;
				for (State state2 : _mdp.getStates()) { // for each next state
					vA += (_mdp.getTransitionProbability(s.getIntId(), action,
							state2.getIntId()) * state2.getValue());
				}
	    	    double v = Math.exp(vA / temp);
	    	    if(Double.isInfinite(v) || Double.isNaN(v)) {
	    	    	System.out.println("boltzmann: NaN or Inf v=" + v);
	    	    }
	    	    normValues[actionId] = v;
				sum += v;
			}

			for (int actionId = 0; actionId<nActions; ++actionId) {
				normValues[actionId] /= sum;
				if(sum == 0)  policy.set(s.getIntId(), actionId, 1.0 / nActions); // if sum is 0, uniform distribution
				else policy.set(s.getIntId(), actionId, normValues[actionId]);
			}
			// logger.info(s.getLabel() + " ==> " + act2prob);
		}
		return policy;
    }

/*    	
    	double s = 0; // s: sum of quality values of all meta actions SUM_m(e^{m.q/T})
    	for(Iterator i=_mPolicy.keySet().iterator(); i.hasNext(); ) {
    	    Integer key = (Integer) i.next();
    	    Strategy act = (Strategy)_mPolicy.get(key);
    	    double q = qvalue(key);
    	    q = __MAX - q;
    	    double v = Math.exp(q / _temp);
    	    if(Double.isInfinite(v) || Double.isNaN(v)) {
    		System.out.println("ERROR(PolicyLeaner.Boltz) q=" + q + ", temp=" + _temp + " v=" + v);
    	    }
    	    s += v;
    	    act.p = v; // a temporary value for probability: e^{q/T} for each meta action
    	}
    	//if(_agent.id() == 0) System.out.println("T=" + _temp + " sum=" + s);

    	if(s == 0) {
    	    int sz = _mPolicy.size();
    	    for(Iterator i=_mPolicy.keySet().iterator(); i.hasNext(); ) {
    		Integer key = (Integer) i.next();
    		Strategy act = (Strategy)_mPolicy.get(key);
    		act.p = 1.0 / sz;
    	    }
    	    return;
    	}

    	// acc: accumulated sum of probabilities of taking meta actions (used for the last one, 1-sum)
    	double acc = 0; 
    	for(Iterator i=_mPolicy.keySet().iterator(); i.hasNext(); ) {
    	    Integer key = (Integer) i.next();
    	    Strategy act = (Strategy)_mPolicy.get(key);
    	    double v = 0;
    	    if(!i.hasNext()) v = 1.0 - acc;
    	    else v = act.p / s;	// normalize the temporary value to valid probability

    	    if(//_agent.id() == 0  &&
    	       (s == 0 || Double.isInfinite(s) || Double.isNaN(v))) {
    		System.out.println("ERROR(PolicyLeaner.Boltz) s=" + s + ", p=" + act.p + " policy=" + _mPolicy);
    		System.exit(0);
    	    }
    	    act.p = v;
    	    acc += v;
    	}	
    	//if(_agent.id() == 0) System.out.println(_mPolicy);
        }
		policy.validate();
		return policy;
        */

	
	/**
	 * returns HashMap of stateIndex -> HashMap (action -> prob of taking the
	 * action)
	 */
	public Policy computeStochasticPolicy() {
		Policy policy = new Policy(_mdp.getStates(), _mdp.getActions()); // deterministic policy
		for (State s : _mdp.getStates()) {
			// value of the current state
			double v = s.getValue();
			int nActions = s.getActions().size();
			// normalized values for expected value of taking this action from the current state
			double[] normValues = new double[nActions];
			// old range of values must be collected from the current values
			double maxReward = -1;
			double minReward = 0;

			for (int actionId = 0; actionId < nActions; ++actionId) {
				Action action = s.getAction(actionId);
				double vA = 0;
				for (State state2 : _mdp.getStates()) { // for each next state
					vA += (_mdp.getTransitionProbability(s.getIntId(), action,
							state2.getIntId()) * state2.getValue());
				}
				normValues[actionId] = vA;
				if (vA > maxReward)
					maxReward = vA;
				if (vA < minReward)
					minReward = vA;
			}
			// normalize state values that may be negative due to costs
			// into *positive* range [0,1]			
			double sum = 0;
			for (int actionId = 0; actionId<nActions; ++actionId) {
				double p = normalize(minReward, maxReward, 0, 1, normValues[actionId]);
				sum += p;
				//logger.info("  norm[" + minReward + "," + maxReward + "]->v=" + normValues[actionId] + "=>" + p);
				normValues[actionId] = p;
			}
			// probability distribution: the values must sum to 1
			for (int actionId = 0; actionId<nActions; ++actionId) {
				double p = 0;
				if(sum == 0) p = 1.0 / nActions; // if sum is 0, uniform distribution
				else p = normValues[actionId] / sum;
				policy.set(s.getIntId(), actionId, p);
			}
			// logger.info(s.getLabel() + " ==> " + act2prob);
		}
		policy.validate();
		return policy;
	}

	/**
	 * Returns a normalized value for a given value in range [oldLow, oldHigh]
	 * into a new range [newLow, newHigh].
	 * 
	 * @param oldLow
	 * @param oldHigh
	 * @param newLow
	 * @param newHigh
	 * @param value
	 * @return
	 */
	public static double normalize(double oldLow, double oldHigh,
			double newLow, double newHigh, double value) {
		if (oldHigh == oldLow)
			return value;
		return (((value - oldLow) / (oldHigh - oldLow)) * (newHigh - newLow))
				+ newLow;
	}

	/**
	 * run(nTrials): test method for each run, start from the initial state s0;
	 * select actions according to (learned) policy; transit to the next state
	 * according to transition probability; repeat until reaching a goal state
	 * or maximum (T_ITER) iterations.
	 */
	public void run(int nTrials) {
		for (int y = 0; y < nTrials; ++y) {
			System.out.println("-- trial -- " + y);
			double accr = 0; // accumulative reward
			int s = _s0;
			State state = _mdp.getState(s);
			for (int x = 0; x < _T_ITER; ++x) {
				int fromS = s;
				state = _mdp.getState(s);
				Action optAction = state.getOptimalAction();
				System.out.print("S" + s + "-A(" + optAction + ")->");

				s = nextState(fromS, optAction);
				accr += _mdp.getReward(fromS, optAction, s);
				if (state.isGoal())
					break;
			}
			if (state.isGoal())
				System.out.println("G" + s + "-// R=[" + accr + "]");
			else
				System.out
						.println("Fail (didn't reach a goal)" + s + "------!");
		}
	}

	/**
	 * nextState(s, a): sample a next state using transition probability
	 * (s,a,s')
	 */
	public int nextState(int s, Action a) {
		int sz = _mdp.getStates().size();
		try {
			double flip = _coin.nextDouble();
			double sum = 0;
			for (int i = 0; i < sz; ++i) {
				double p = _mdp.getTransitionProbability(s, a, i);
				sum += p;
				if (flip <= sum)
					return i;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(ex + " s=" + s + " a=" + a);
			System.exit(0);
		}
		return sz - 1;
	}

	public State nextState(State s, Action a) {
		return _mdp.getState(nextState(s.getIntId(), a));
	}

	public static void usage() {
		System.out
				.println("java Solver [(examples/)plan-library-file(.xml)][]\n");
	}
	
	public static void mainOLD(String args[]) {
		

		if (args.length < 1) {
			usage();
			System.exit(0);
		}

		_coin = new Random(SEED);
		_MOD = 1;
		try {
			String filename = args[0];
			PlanTreeBuilder builder = new PlanTreeBuilder();
			PlanLibrary library = builder.parsePlanTree("examples/" + filename
					+ ".xml");

			MDPProblemFactory factory = MDPProblemFactory.getInstance();
			BasicMDPProblem problem = (BasicMDPProblem) factory
					.fromPlanLibrary(library, 0.2);
			logger.warning(problem.toString());

			problem.setDiscountFactor(0.9);

			System.out
					.println("discount factor=" + problem.getDiscountFactor());
			MDPSolver solver = new MDPSolver(problem);

			// Value Iteration
			solver.valueIteration();
			solver.run(2);

		} catch (PlanParseException e) {
			e.printStackTrace();
		}
	}

	// For ECAI2010 Figure 2 and 3 (optimal MDP policy)
	public static void main(String args[]) {

		//DynamicMDPProblem(List<State> states, List<Action> actions,
		// List<TransitionMatrix> matrices, double discount)
		List<Action> actions = new ArrayList<Action>(2);
		for(int i=0;i<2; ++i) actions.add(new Action(String.valueOf(i), i));

		List<State> states = new ArrayList(4);
		// State(id, reward)
		for(int i=0;i<4; ++i) {
			State state= new State(String.valueOf(i), -1);//default reward=-1
			states.add(state);
			for(int a=0; a<2; ++a) {
				// specific action from each state
				Action actualAct = new Action(String.valueOf(a), a);
				state.addAction(actualAct);
			}
		}		
		ArrayList<TransitionMatrix> trans = new ArrayList<TransitionMatrix>(2);		
		TransitionMatrix m0 = new TransitionMatrix(4, actions.get(0));
		TransitionMatrix m1 = new TransitionMatrix(4, actions.get(1));
		trans.add(m0);
		trans.add(m1);
		for(int i=0;i<4;++i) { // initialize with 0 	
			for(int j=0; j<4;++j) { 
				m0.set(i,j,0);
				m1.set(i,j,0);
			}
		}
		m0.set(0,1,1);
		m0.set(1,0,1);
		m0.set(2, 3, 0.8);
		m0.set(2, 2, 0.2);
		m0.set(3,3,1);

		m1.set(0,0,0.9);
		m1.set(0,2,0.1);
		m1.set(1,1,0.8);
		m1.set(1,3,0.2);
		m1.set(2, 2, 0.95);
		m1.set(2, 3, 0.05);
		m1.set(3,3,1);

		State goal = states.get(3);
		goal.reward = 5;
		goal.setGoal(true);

		DynamicMDPProblem p = new DynamicMDPProblem (states, actions, trans, 0.95);
		System.out.println(p);
		MDPSolver solver = new MDPSolver(p);

		// Value Iteration
		solver.valueIteration();
		System.out.println("policy:");
		//solver.computeStochasticPolicy().print();
    	double temp = 0.5; // temperature
		solver.computeBoltzmannPolicy(temp).print();
	}
	
	public HashMap<State, Action> solveMDP(MDPProblem mdp) {
		this._mdp = mdp;
		this.valueIteration();
		HashMap<State, Action> res = new HashMap<State, Action>();
		for(State s:mdp.getStates()) {
			res.put(s, s.getOptimalAction());
		}
		return res;
	}
}
