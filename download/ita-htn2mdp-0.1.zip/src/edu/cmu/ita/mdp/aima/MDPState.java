/**
 * Created on Jan 22, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.mdp.aima;

import java.util.LinkedList;
import java.util.List;

import edu.cmu.ita.htn.MultiState;
import edu.cmu.ita.htn.Task;

/**
 * @author meneguzzi
 *
 */
public class MDPState implements Comparable<MDPState> {
	protected boolean isFinal = true;
	
	protected int id;
	
	protected String label;
	
	/**
	 * The fully expanded HTN {@link MultiState} that corresponds to this {@link MDPState}
	 */
	public MultiState htnState;
	
	/**
	 * The HTN {@link Task} that led to the creation of this {@link MDPState}. 
	 */
	protected Task task;
	
	public List<MDPState> overlapping;
	
	
	/**
	 * 
	 */
	public MDPState(int id, String label, MultiState htnState, Task task) {
		this.id = id;
		this.label = label;
		this.htnState = htnState;
		this.task = task;
		this.overlapping = new LinkedList<MDPState>();
	}

	/**
	 * @return the isFinal
	 */
	public final boolean isFinal() {
		return isFinal;
	}

	/**
	 * @param isFinal the isFinal to set
	 */
	public final void setFinal(boolean isFinal) {
		this.isFinal = isFinal;
	}

	/**
	 * @return the id
	 */
	public final int getId() {
		return id;
	}

	/**
	 * @return the htnState
	 */
	public final MultiState getHtnState() {
		return htnState;
	}

	/**
	 * @return the label
	 */
	public final String getLabel() {
		return label;
	}
	
	/**
	 * @return the task
	 */
	public final Task getTask() {
		return task;
	}
	
	/**
	 * 
	 * @return
	 */
	public final List<MDPState> getOverlapping() {
		return overlapping;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return id+":"+label;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(MDPState o) {
		int thisVal = id;
		int anotherVal = o.id;
		return (thisVal<anotherVal ? -1 : (thisVal==anotherVal ? 0 : 1));
	}

	/**
	 * @return
	 */
	public int modulo() {
		return overlapping.size();
	}
}
