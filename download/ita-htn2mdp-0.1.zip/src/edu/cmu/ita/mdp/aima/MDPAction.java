/**
 * Created on Jan 22, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.mdp.aima;

/**
 * @author meneguzzi
 *
 */
public class MDPAction implements Comparable<MDPAction> {
	
	protected int id;
	
	protected String name;
	
	/**
	 * 
	 */
	public MDPAction(int id, String label) {
		this.id = id;
		this.name = label;
	}
	
	/**
	 * @return the id
	 */
	public final int getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public final String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return id+":"+name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(MDPAction o) {
		int thisVal = id;
		int anotherVal = o.id;
		return (thisVal<anotherVal ? -1 : (thisVal==anotherVal ? 0 : 1));
	}

}
