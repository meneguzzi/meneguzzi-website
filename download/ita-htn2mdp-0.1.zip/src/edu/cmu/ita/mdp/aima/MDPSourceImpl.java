/**
 * Created on Jan 22, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.mdp.aima;

import java.util.List;

import aima.core.probability.Randomizer;
import aima.core.probability.decision.MDP;
import aima.core.probability.decision.MDPPerception;
import aima.core.probability.decision.MDPRewardFunction;
import aima.core.probability.decision.MDPSource;
import aima.core.probability.decision.MDPTransitionModel;

/**
 * @author meneguzzi
 *
 */
public class MDPSourceImpl implements MDPSource<MDPState, MDPAction> {
	List<MDPAction> actions;
	List<MDPState> nonFinalStates;
	List<MDPState> finalStates;
	MDPState initialState;
	
	MDPRewardFunction<MDPState> rewardFunction;
	MDPTransitionModel<MDPState, MDPAction> transitionModel;
	/**
	 * 
	 */
	public MDPSourceImpl(List<MDPAction> actions, List<MDPState> nonFinalStates, List<MDPState> finalStates, MDPState initialState, 
			             MDPRewardFunction<MDPState> rewardFunction, MDPTransitionModel<MDPState, MDPAction> transitionModel) {
		this.actions = actions;
		this.nonFinalStates = nonFinalStates;
		this.finalStates = finalStates;
		this.initialState = initialState;
		this.rewardFunction = rewardFunction;
		this.transitionModel = transitionModel;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#asMdp()
	 */
	@Override
	public MDP<MDPState, MDPAction> asMdp() {
		return new MDP<MDPState, MDPAction>(this);
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#execute(java.lang.Object, java.lang.Object, aima.core.probability.Randomizer)
	 */
	@Override
	public MDPPerception<MDPState> execute(MDPState arg0, MDPAction arg1,
			Randomizer arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getAllActions()
	 */
	@Override
	public List<MDPAction> getAllActions() {
		return this.actions;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getFinalStates()
	 */
	@Override
	public List<MDPState> getFinalStates() {
		return this.finalStates;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getInitialState()
	 */
	@Override
	public MDPState getInitialState() {
		return this.initialState;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getNonFinalStates()
	 */
	@Override
	public List<MDPState> getNonFinalStates() {
		return this.nonFinalStates;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getRewardFunction()
	 */
	@Override
	public MDPRewardFunction<MDPState> getRewardFunction() {
		return this.rewardFunction;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getTransitionModel()
	 */
	@Override
	public MDPTransitionModel<MDPState, MDPAction> getTransitionModel() {
		return this.transitionModel;
	}

}
