package edu.cmu.ita.mdp;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class Policy {

	/**
	 * double[nStates][nActions]
	 */
	double[][] probability;
	public final static double EPSILON = 0.0001; // allow small errors
	Logger logger = Logger.getLogger(getClass().getName());
	
	private List<State> states;
	private List<Action> actions;
	
	public Policy(List<State> states, List<Action> actions) {
		this.states = new ArrayList<State>(states);
		this.actions = new ArrayList<Action>(actions);
		probability = new double[states.size()][actions.size()];
	}
	
	public Policy(int nStates, int nActions) {
		probability = new double[nStates][nActions];
	}
	
	public double[] get(int state) { return probability[state]; }
	public double get(int state, int action) { return probability[state][action]; }
	public void set(int state, int action, double p) { probability[state][action] = p; }
	
	/**
	 * A bit of a hack for deterministic policies, returns the action with probability 1 in the supplied state
	 * @param state
	 * @return
	 */
	public int getBestActionForState(int state) {
		for(int j=0; j<probability[state].length; j++) {
			if(probability[state][j] == 1.0) {
				return j;
			}
		}
		return -1;
	}
	
	/**
	 *  check the values for each state sum to 1 modulo small error<EPSILON
	 * @return true if sum is close to 1; false otherwise
	 */
	public boolean validate() {
		
		for(int s=0; s<probability.length; ++s) {
			double sum = 0;
			for(int a=0; a<probability[0].length; ++a) {
				sum += get(s, a);
			}
			if(Math.abs(sum - 1) > EPSILON) {
				logger.warning("Policy validation failed at state [" + s + "].");
				print();
				return false;			
			}
		}
		return true;
	}
	
	public void print() {
		System.out.println("--- Policy (s x a)---");
		for (int s = 0; s < probability.length; ++s) {
			System.out.print("s"+s + "\t");
			for (int a = 0; a < probability[s].length; ++a) {
				System.out.print(probability[s][a] + ", ");
			}
			System.out.println("");
		}	
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(State s:states) {
			Action act = s.getOptimalAction();
			sb.append(s.getLabel() + " -> "+act.toString()+System.getProperty("line.separator"));
//			sb.append(s.toString() + " -> "+act.toString()+System.getProperty("line.separator"));
		}
		return sb.toString();
	}
}
