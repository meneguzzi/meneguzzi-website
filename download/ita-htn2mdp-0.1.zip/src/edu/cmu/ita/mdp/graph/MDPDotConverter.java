/**
 * Created on Dec 13, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.mdp.graph;

import java.io.PrintWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.util.List;

import aima.core.probability.decision.MDPSource;
import aima.core.probability.decision.MDPTransition;

import edu.cmu.ita.mdp.Action;
import edu.cmu.ita.mdp.MDPProblem;
import edu.cmu.ita.mdp.State;
import edu.cmu.ita.mdp.TransitionMatrix;
import edu.cmu.ita.mdp.aima.MDPAction;
import edu.cmu.ita.mdp.aima.MDPState;

/**
 * A static class with the method to print an MDPProblem into the 
 * <a href="http://www.graphviz.org/">Graphviz</a> 
 * <a href="http://www.graphviz.org/Documentation.php">Dot format</a>.
 * 
 * @author meneguzzi
 *
 */
public class MDPDotConverter {
	/**
	 * 
	 * @param writer
	 * @param problem
	 * @param printState TODO
	 */
	public static void printMDPDot(Writer writer, MDPProblem problem, boolean printState) {
		PrintWriter out = new PrintWriter(writer);
		DecimalFormat df = new DecimalFormat("0.00");
		
		out.println("digraph {");
		out.println(" size=\"8.5,11\";");
		
		if(printState) {
			for(State s:problem.getStates()) {
				out.println("\""+s.getId()+"\" [label=\""+s.getLabel()+" r:"+s.getReward()+"\"];");
			}
		} else {
			for(State s:problem.getStates()) {
				out.println("\""+s.getId()+"\" [label=\""+s.getIntId()+":"+s.getId()+"\"];");
			}
		}
		
		for(Action a:problem.getActions()) {
			
			TransitionMatrix tm = problem.getTransitionMatrices().get(a);
			int size = tm.getStateCount();
			for(int i=0; i<size;i++) {
				for(int j=0; j<size; j++) {
					double prob = tm.get(i, j);
					if(prob != 0) {
						out.print("\""+problem.getState(i).getId()+"\"");
						out.print(" -> ");
						out.print("\""+problem.getState(j).getId()+"\"");
						if(i!=j) {
							out.print(" [ label=\""+a.getName());
							if(prob != 1) {
								out.print(":"+df.format(prob));
							}
							out.println("\" ];");
						}
					}
				}
			}
			
		}
		out.println("}");
		
		out.flush();
	}
	
	/**
	 * 
	 * @param writer
	 * @param source
	 * @param printState TODO
	 */
	public static void printMDPDot(Writer writer, MDPSource<MDPState, MDPAction> source, boolean printState) {
		PrintWriter out = new PrintWriter(writer);
		DecimalFormat df = new DecimalFormat("0.00");
		
		out.println("digraph {");
		out.println(" size=\"8.5,11\";");
		
		if(printState) {
			for(MDPState s:source.getFinalStates()) {
				out.println("\""+s.getId()+"\" [label=\""+s.getLabel()+" r:"+source.getRewardFunction().getRewardFor(s)+"\"];");
			}
			for(MDPState s:source.getNonFinalStates()) {
				out.println("\""+s.getId()+"\" [label=\""+s.getLabel()+" r:"+source.getRewardFunction().getRewardFor(s)+"\"];");
			}
		}
		
		for(MDPState is:source.getNonFinalStates()) {
			for(MDPAction a:source.getAllActions()) {
				List<MDPTransition<MDPState, MDPAction>> transition = source.getTransitionModel().getTransitionsWithStartingStateAndAction(is, a);
				for(MDPTransition<MDPState, MDPAction> tr:transition) {
					MDPState ds = tr.getDestinationState();
					out.print("\""+is.getId()+"\"");
					out.print(" -> ");
					out.print("\""+ds.getId()+"\"");
					if(is!=ds) {
						out.print(" [ label=\""+a.getName());
						double prob = source.getTransitionModel().getTransitionProbability(is, a, ds);
						if(prob != 1) {
							out.print(":"+df.format(prob));
						}
						out.println("\" ];");
					}
				}
			}
		}
		out.println("}");
		
		out.flush();
	}
}
