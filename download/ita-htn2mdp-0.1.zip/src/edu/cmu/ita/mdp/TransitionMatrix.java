package edu.cmu.ita.mdp;

import java.text.DecimalFormat;
import java.util.List;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.plan.PlanTreeNode;

public class TransitionMatrix {

	protected double A[][];
	
	protected Action action;

	/**
	 * Creates a new Transition Matrix with the specified number of states and
	 * initializes the transition probabilities to zero.
	 * 
	 * @param n
	 *            The number of states in the transition matrix
	 */
	public TransitionMatrix(int n) {
		A = new double[n][n];
	}
	
	/**
	 * Creates a new TransitionMatrix with the specified number of states for 
	 * the specified 
	 * @param n
	 * @param actionName
	 */
	public TransitionMatrix(int n, Action action) {
		this(n);
		this.action = action;
	}
	
	/*
	 * Returns the name of the action for which the probabilities of this 
	 * matrix applies.
	 * @return
	 *
	public String getActionName() {
		return actionName;
	}
*/
	/**
	 * Get a single element.
	 * 
	 * @param i Row index.
	 * @param j Column index.
	 * @return A(i,j)
	 * @exception ArrayIndexOutOfBoundsException
	 */
	public double get(int i, int j) {
		return A[i][j];
	}

	/**
	 * Set a single element.
	 * 
	 * @param i Row index.
	 * @param j Column index.
	 * @param s A(i,j).
	 * @exception ArrayIndexOutOfBoundsException
	 */

	public void set(int i, int j, double s) {
		A[i][j] = s;
	}
	
	/**
	 * Returns the number of states in this transition matrix. This corresponds
	 * to both dimensions of this matrix, as it is square.
	 * @return
	 */
	public int getStateCount() {
		return A.length;
	}
	
	/**
	 * Normalizes the probabilities in each row so they sum up to one, with the
	 * specified probability of an error (and no state transition). The error
	 * probability specifies the chance of an action causing no state 
	 * transition at all. If the matrix already included the possibility of 
	 * remaining in the same state, we ignore the error probability. 
	 * @param errorProbability
	 */
	public void normalizeToOne(double errorProbability) {
		normalizeToOne(errorProbability, 1d);
	}
	
	/**
	 * Normalizes the probabilities in each row so they sum up to one, with the
	 * specified probability of an error (and no state transition). The error
	 * probability specifies the chance of an action causing no state 
	 * transition at all. If the matrix already included the possibility of 
	 * remaining in the same state, we ignore the error probability. 
	 * @param errorProbability
	 * @param defaultValue - The value to assign to a transition if the row sums up to zero.
	 */
	public void normalizeToOne(double errorProbability, double defaultValue) {
		for(int i=0; i< A.length; i++) {
			float divisor = 0;
			for(int j=0; j< A[0].length; j++) {
				divisor += A[i][j];
			}
			//To avoid a divide by zero error
			//TODO check if this is actually the desired behavior
			//If the divisor is one, it means this state always transitions to 
			//itself when this action is executed
			if(divisor == 0) {
				A[i][i] = defaultValue;
				continue;
			}
			//double discountError = errorProbability / divisor;
			for(int j=0; j< A[0].length; j++) {
				//Added the second clause in the test for the error
				//If we expect a transition into the same state (regardless of error)
				//Then we normalize that transition without the error probability
				if(i==j && A[i][j] == 0) {
					A[i][j] = errorProbability;
				} else {
					A[i][j] = (A[i][j] != 0) ? ((A[i][j] - errorProbability)/divisor) : 0;
					//A[i][j] = (A[i][j] != 0) ? A[i][j] - discountError : 0;
				}
			}
		}
	}
	
	/**
	 * Populates the transition matrix with data from a Plan Library
	 * @param library
	 */
	public void populateTransitionMatrix(PlanLibrary library) {
		List<PlanTreeNode> states = library.getObservableNodes();
		//Adjust size if the number of states is larger than matrix order
		if(states.size() != A.length) {
			A = new double[states.size()][states.size()];
		}
		for(int i=1; i<states.size(); i++) {
			PlanTreeNode si = states.get(i);
			//PlanTreeNode sj = (PlanTreeNode) si.getParent();
			if(si.getLabel().equals(action.getName())) {
				List<PlanTreeNode> previous = si.getPreviousObservable();
				for(PlanTreeNode sj:previous) {
					int j = states.indexOf(sj);
					//The matrix is indexed with [j][i] because the table represents 
					//states BEFORE the action into states AFTER the action, thus
					//from sj to si
					A[j][i] = 1;
				}
			}
		}
		
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		DecimalFormat df = new DecimalFormat("0.00");
		sb.append("T: "+this.action.getName()+System.getProperty("line.separator"));
		for(double[] line:A) {
			for(double column:line) {
				sb.append(df.format(column)+" ");
			}
			sb.append(System.getProperty("line.separator"));
		}
		return sb.toString();
	}
}
