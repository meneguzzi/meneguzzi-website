package edu.cmu.ita.mdp;

import java.util.Date;

public abstract class UserObservation {
	
	protected long timeStamp;	
	
	public UserObservation() {
		this.timeStamp = new Date().getTime();
		//System.out.println("UserObservation new@" + this.timestamp);
	}
	
	public UserObservation(long timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * Returns the time stamp of the user observation 
	 * @return
	 */
	public long getTimeStamp() {
		return timeStamp;
	}
}
