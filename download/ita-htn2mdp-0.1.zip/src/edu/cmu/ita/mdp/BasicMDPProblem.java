package edu.cmu.ita.mdp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BasicMDPProblem implements MDPProblem {

	protected List<State> states;

	protected List<Action> actions;

	protected HashMap<Action, TransitionMatrix> transitionMatrices;

	protected double discount;

	BasicMDPProblem(List<State> states, List<Action> actions,
			List<TransitionMatrix> matrices) {
		this.states = states;
		this.actions = actions;
		this.transitionMatrices = new HashMap<Action, TransitionMatrix>(
				matrices.size());
		for (TransitionMatrix matrix : matrices) {
			transitionMatrices.put(matrix.action, matrix);
		}
	}

	public// made this constructor public --jeanoh
	BasicMDPProblem(List<State> states, List<Action> actions,
			List<TransitionMatrix> matrices, double discount) {
		this(states, actions, matrices);
		this.discount = discount;
	}

	@Override
	public double getDiscountFactor() {
		return discount;
	};

	@Override
	public List<Action> getActions() {
		return actions;
	}

	@Override
	public List<State> getStates() {
		return states;
	}

	@Override
	public Map<Action, TransitionMatrix> getTransitionMatrices() {
		return transitionMatrices;
	}

	@Override
	public double getTransitionProbability(int s, Action act, int sp) {
		TransitionMatrix tm = transitionMatrices.get(act);

		return tm.get(s, sp);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		sb.append("discount: " + this.discount
				+ System.getProperty("line.separator"));
		StringBuilder sbStates = new StringBuilder();
		StringBuilder sbRewards = new StringBuilder();
		int i=0;
		for (State state : states) {
			sbStates.append(i+":" + state.id+" ");
			i++;
			sbRewards.append(" " + state.reward);
		}

		sb.append("states:" + sbStates.toString()
				+ System.getProperty("line.separator"));
		sb.append("rewards:" + sbRewards.toString()
				+ System.getProperty("line.separator"));

		sb.append("actions:");
		for (Action action : actions) {
			sb.append(" " + action);
		}
		sb.append(System.getProperty("line.separator"));

		for (TransitionMatrix matrix : transitionMatrices.values()) {
			sb.append(System.getProperty("line.separator") + matrix.toString());
		}

		sb.append(System.getProperty("line.separator"));

		return sb.toString();
	}

	// jeanoh
	public State getState(int index) {
		return (State) states.get(index);
	}

	public double getReward(int s, Action act, int sp) {
		// for now
		return (double) ((State) (states.get(sp))).getReward();
	}

	public void setDiscountFactor(double d) {
		discount = d;
	}

	@Override
	public Action getAction(int index) {
		return actions.get(index);
	}
	
}
