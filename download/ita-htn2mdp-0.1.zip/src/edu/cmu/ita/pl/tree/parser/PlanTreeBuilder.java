package edu.cmu.ita.pl.tree.parser;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.plan.PlanTreeNode;
import edu.cmu.ita.pl.plan.PlanTreeNode.NodeType;

/**
 * A builder class for plan trees 
 * @author meneguzzi
 *
 */
public class PlanTreeBuilder {
	
	private static final Logger logger = Logger.getLogger(PlanTreeBuilder.class.getName());
	
	protected PlanTreeNode root;
	protected HashMap<String, PlanTreeNode> treeNodes;
	protected HashMap<String, List<String>> sequentialEdges;
	protected HashMap<String, List<String>> decompositionEdges;
	
	public PlanTreeBuilder() {
		treeNodes = new HashMap<String, PlanTreeNode>();
		sequentialEdges = new HashMap<String, List<String>>();
		decompositionEdges = new HashMap<String, List<String>>();
	}
	
	/**
	 * 
	 * @param planFile
	 * @return
	 * @throws PlanParseException
	 */
	public PlanLibrary parsePlanTree(File planFile) throws PlanParseException {
		this.wipePlanTreeInfo();
		try {
			SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
			PlanTreeContentHandler contentHandler = new PlanTreeContentHandler(this);
			
			parser.parse(planFile, contentHandler);
			
			return this.buildPlanLibrary();
		} catch (SAXException e) {
			throw new PlanParseException(e);
		} catch (ParserConfigurationException e) {
			throw new PlanParseException(e);
		} catch (IOException e) {
			throw new PlanParseException(e);
		}
	}
	
	/**
	 * Parses a plan tree from an XML file
	 * @param filename
	 * @throws PlanParseException  
	 */
	public PlanLibrary parsePlanTree(String filename) throws PlanParseException {
		File planFile = new File(filename);
		return parsePlanTree(planFile);
	}
	
	/**
	 * Wipes all plan library data in this object for recycling.
	 */
	protected void wipePlanTreeInfo() {
		this.treeNodes.clear();
		this.sequentialEdges.clear();
		this.decompositionEdges.clear();
	}
	
	/**
	 * Sets the root node for the plan tree to bootstrap the tree building process
	 * @param rootNode
	 */
	public void setRootNode(PlanTreeNode rootNode) throws PlanParseException {
		if(rootNode.getType() == NodeType.DECOMPOSITION) {
			this.root = rootNode;
			this.addTreeNode(rootNode);
		} else {
			throw new PlanParseException("Root node must be a decomposition node.");
		}
	}
	
	/**
	 * Adds a new node to the plan tree
	 * @param node
	 * @throws PlanParseException
	 */
	public void addTreeNode(PlanTreeNode node) throws PlanParseException {
		if(treeNodes.containsKey(node.getId()))
			throw new PlanParseException("Node label already exists: '"+node.getId()+"'");
		this.treeNodes.put(node.getId(), node);
	}
	
	/**
	 * Adds a sequential edge between parent and child node
	 * @param parent
	 * @param child
	 * @throws PlanParseException
	 */
	public void addSequentialEdge(String parent, String child) throws PlanParseException {
		if(!treeNodes.containsKey(parent))
			throw new PlanParseException("Parent node does not exist in tree");
		List<String> edges = null;
		if(sequentialEdges.containsKey(parent)) {
			edges = sequentialEdges.get(parent);
		} else {
			edges = new ArrayList<String>();
			sequentialEdges.put(parent, edges);
		}
		
		if(edges.contains(child)) {
			throw new PlanParseException("Redundant link between nodes");
		}
		
		edges.add(child);
	}
	
	public void addDecompositionEdge(String parent, String child) throws PlanParseException {
		if(!treeNodes.containsKey(parent))
			throw new PlanParseException("Parent node does not exist in tree");
		List<String> edges = null;
		if(decompositionEdges.containsKey(parent)) {
			edges = decompositionEdges.get(parent);
		} else {
			edges = new ArrayList<String>();
			decompositionEdges.put(parent, edges);
		}
		
		if(edges.contains(child)) {
			throw new PlanParseException("Redundant link between nodes");
		}
		
		edges.add(child);
	}
	
	public boolean hasRoot() {
		return root!=null;
	}
	
	/**
	 * Builds the plan library from the root node stored in the builder.
	 * @return
	 */
	public PlanLibrary buildPlanLibrary() throws PlanParseException {
		PlanLibrary plan = new PlanLibrary(buildPlanTree());
		
		return plan;
	}
	
	/**
	 * Returns the built plan tree
	 * @return
	 * @throws PlanParseException
	 */
	PlanTreeNode buildPlanTree() throws PlanParseException {
		Collection<PlanTreeNode> disconnectedNodes = new LinkedList<PlanTreeNode>(treeNodes.values());
		connectChildren(root, disconnectedNodes);
		
		if(!disconnectedNodes.isEmpty()) {
			StringBuilder sb = new StringBuilder();
			sb.append("Disconnected nodes in the plan library: ");
			
			for(PlanTreeNode node : disconnectedNodes) {
				sb.append(node.getId()+" ");
			}
			
			logger.warning(sb.toString());
		}
		
		return root;
	}
	
	/**
	 * Connects all children in the tree
	 * @param node
	 * @param disconnectedNodes
	 * @throws PlanParseException
	 */
	private void connectChildren(PlanTreeNode node, Collection<PlanTreeNode> disconnectedNodes) throws PlanParseException {
		List<String> edges = sequentialEdges.get(node.getId());
		if(edges != null) {
			for(String childId : edges) {
				PlanTreeNode childNode = treeNodes.get(childId);
				if(childNode == null) {
					throw new PlanParseException("Trying to connect non-existent node with a sequential edge '"+node.getId()+"' to (non-existent) '"+childId+"'");
				}
				else {
					node.addSequentialChild(childNode);
				}
				connectChildren(childNode, disconnectedNodes);
			}
		}
		edges = decompositionEdges.get(node.getId());
		if(edges != null) {
			for(String childId : edges) {
				PlanTreeNode childNode = treeNodes.get(childId);
				if(childNode == null) {
					throw new PlanParseException("Trying to connect non-existent node with a decomposition edge '"+childId+"'");
				}
				else {
					node.addDecompositionChild(childNode);
				}
				connectChildren(childNode, disconnectedNodes);
			}
		}
		disconnectedNodes.remove(node);
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append("Plan Tree"+System.getProperty("line.separator"));
		for(String node : treeNodes.keySet()) {
			sb.append("\t* "+node+System.getProperty("line.separator"));
			if(sequentialEdges.containsKey(node)) {
				sb.append("\t    Seq"+System.getProperty("line.separator"));
				for(String edge : sequentialEdges.get(node)) {
					sb.append("\t    ->"+edge+System.getProperty("line.separator"));
				}
			}
			if(decompositionEdges.containsKey(node)) {
				sb.append("\t    Dec"+System.getProperty("line.separator"));
				for(String edge : decompositionEdges.get(node)) {
					sb.append("\t    ->"+edge+System.getProperty("line.separator"));
				}
			}
		}
		
		return sb.toString();
	}
}
