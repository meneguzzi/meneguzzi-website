package edu.cmu.ita.pl.tree.parser;


public class PlanParseException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int line;

	PlanParseException() {
		super();
	}
	
	PlanParseException(String msg) {
		super(msg);
	}
	
	PlanParseException(String msg, int line) {
		this(msg);
		this.line = line;
	}
	

	PlanParseException(Exception e) {
		super(e);
	}

	public int getLine() {
		return line;
	}

	public void setLine(int line) {
		this.line = line;
	}
	
	@Override
	public String getMessage() {
		String ret = super.getMessage();
		if(line != 0) {
			ret = "Line "+line+": "+ret;
		}
		return ret;
	}
}
