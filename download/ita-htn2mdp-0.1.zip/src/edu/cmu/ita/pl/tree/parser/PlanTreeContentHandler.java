package edu.cmu.ita.pl.tree.parser;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import edu.cmu.ita.pl.plan.PlanTreeNode;
import edu.cmu.ita.pl.plan.PlanTreeNode.NodeType;

public class PlanTreeContentHandler extends DefaultHandler {
	
	private static final Logger logger = Logger.getLogger(PlanTreeContentHandler.class.getName());
	
	private static final String ACTION = "action";
	private static final String DECOMPOSITION = "decomposition";
	
	private static final String PLAN_LIBRARY_TAG = "plan-library";
	private static final String PLAN_TAG = "plan";
	
	private static final String PLAN_STEP_TAG = "plan-step";
	private static final String TYPE_ATTR = "type";
	private static final String LABEL_ATTR = "label";
	private static final String ID_ATTR = "id";
	
	private static final String SEQ_TAG = "seq";
	private static final String DEC_TAG = "dec";
	private static final String REF_ATTR = "ref";

	public enum Context {
		PLAN_LIB, PLAN, PLAN_STEP, SEQ
	};

	protected Context context;
	protected PlanTreeNode contextNode = null;

	protected List<PlanParseException> errors;

	protected final PlanTreeBuilder builder;

	PlanTreeContentHandler(PlanTreeBuilder builder) {
		this.builder = builder;
		this.errors = new ArrayList<PlanParseException>();
	}

	@Override
	public void startDocument() throws SAXException {
		context = Context.PLAN_LIB;
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		try {
			if (qName.equals(PLAN_LIBRARY_TAG)) {
				context = Context.PLAN_LIB;
				//At this point we create a decomposition node to represent the
				//entire plan library
				contextNode = new PlanTreeNode("root", null, NodeType.DECOMPOSITION);
				builder.setRootNode(contextNode);
				contextNode = null;
			} else if (qName.equals(PLAN_TAG)) {
				if (context != Context.PLAN_LIB) {
					throw new SAXException("Wrong context");
				}
				context = Context.PLAN;
			} else if (qName.equals(PLAN_STEP_TAG)) {
				context = Context.PLAN_STEP;
				PlanTreeNode node = createPlanTreeNode(uri, localName, qName,attributes);
				builder.addTreeNode(node);
				
				//If this is the first node in a plan then we should connect it with the root
				if(contextNode == null) {
					try {
						//After we finish a plan node, we must connect this node to the root
						builder.addDecompositionEdge("root", node.getId());
					} catch (PlanParseException e) {
						// TODO Auto-generated catch block
						throw new SAXException(e);
					}
				}
				
				contextNode = node;
			} else if (qName.equals(SEQ_TAG)) {
				if(contextNode != null) {
					String ref = attributes.getValue(REF_ATTR);
					if(ref != null) {
						builder.addSequentialEdge(contextNode.getId(), ref);
					} else {
						throw new SAXException("ref attribute is null in sequential edge");
					}
				} else {
					throw new SAXException("Trying to add a sequential edge outside of a plan-step.");
				}
			} else if (qName.equals(DEC_TAG)) {
				if(contextNode != null) {
					if(contextNode.getType() == NodeType.DECOMPOSITION) {
						String ref = attributes.getValue(REF_ATTR);
						if(ref != null) {
							builder.addDecompositionEdge(contextNode.getId(), ref);
						} else {
							throw new SAXException("ref attribute is null in decomposition edge");
						}
					} else {
						throw new SAXException("Outgoing decomposition edges can only be added to decomposition nodes");
					}
				} else {
					throw new SAXException("Trying to add a decomposition edge outside of a plan-step.");
				}
			} 
		} catch (PlanParseException e) {
			throw new SAXException(e);
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (qName.equals(PLAN_LIBRARY_TAG)) {
			// do some validation?
		} else if (qName.equals(PLAN_TAG)) {
			context = Context.PLAN_LIB;
			contextNode = null;
		} else if (qName.equals(PLAN_STEP_TAG)) {
			context = Context.PLAN;
		} else if (qName.equals(SEQ_TAG)) {
			context = Context.PLAN_STEP;
		}
	}

	@Override
	public void endDocument() throws SAXException {
		// TODO Auto-generated method stub
		super.endDocument();
	}

	/**
	 * Validades and instantiates a new plan node
	 * 
	 * @param uri
	 * @param localName
	 * @param qName
	 * @param attributes
	 * @return
	 * @throws SAXException
	 */
	protected PlanTreeNode createPlanTreeNode(String uri, String localName,
			String qName, Attributes attributes) throws SAXException {
		String id = attributes.getValue(ID_ATTR);
		String label = attributes.getValue(LABEL_ATTR);
		String typeString = attributes.getValue(TYPE_ATTR);
		String rewardString = attributes.getValue("reward");
		if (id == null) {
			throw new SAXException("Node id attribute is empty");
		}
		if (label == null) {
			//throw new SAXException("node label attribute is empty");
			logger.warning("Node label attribute is empty, defaulting to id");
			label = id;
		}
		if (typeString == null) {
			throw new SAXException("Node type attribute is empty");
		}
		int reward = 0;
		if (rewardString != null) {
			reward = Integer.parseInt(rewardString);
		}
		NodeType type = parseType(typeString);
		PlanTreeNode node = new PlanTreeNode(id, label, type, reward);
		return node;
	}

	/**
	 * Returns the equivalent type from a string representation
	 * 
	 * @param type
	 * @return
	 */
	protected NodeType parseType(String type) {
		if (type.equals(DECOMPOSITION)) {
			return NodeType.DECOMPOSITION;
		} else if (type.equals(ACTION)) {
			return NodeType.ACTION;
		} else {
			return null;
		}
	}
}
