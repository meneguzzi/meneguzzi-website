package edu.cmu.ita.pl.tree;

import java.util.Iterator;

/**
 * The interface to a generic tree, used throughout this code base
 * @author meneguzzi
 *
 */
public interface TreeNode {
	public Iterator<TreeNode> getChildren();

	public TreeNode getChild(int index);

	public void addChild(TreeNode node);

	public int getChildCount();
	
	public TreeNode getParent();
	
	public void setParent(TreeNode parent);
	
	public boolean isLeaf();
}
