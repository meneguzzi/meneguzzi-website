package edu.cmu.ita.pl.plan;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import edu.cmu.ita.pl.plan.PlanTreeNode.NodeType;

/**
 * A container class for an entire plan library
 * @author meneguzzi
 *
 */
public class PlanLibrary {
	
	private static final Logger logger = Logger.getLogger(PlanLibrary.class.getName());
	
	protected PlanTreeNode planTree;
	
	protected HashMap<String, PlanTreeNode> nodeIndex;
	
	protected Set<String> allLabels;
	
	public PlanLibrary() {
		this.nodeIndex = new HashMap<String, PlanTreeNode>();
		this.allLabels = new HashSet<String>();
	}
	
	public PlanLibrary(PlanTreeNode planTree) {
		this();
		this.setPlanTree(planTree);
	}
	
	/**
	 * 
	 * @param planTree
	 */
	public void setPlanTree(PlanTreeNode planTree) {
		this.planTree = planTree;
		indexPlanTree(planTree);
	}
	
	/**
	 * 
	 * @param treeNode
	 */
	void indexPlanTree(PlanTreeNode treeNode) {
		if(!nodeIndex.containsKey(treeNode.id)) {
			nodeIndex.put(treeNode.id, treeNode);
		} else {
			logger.warning("Revisting node '"+treeNode.getId()+"', tree may not be directed.");
		}
		
		if(treeNode.getType() == NodeType.ACTION && !allLabels.contains(treeNode.getLabel())) {
			allLabels.add(treeNode.getLabel());
		}
		
		for(PlanTreeNode child: treeNode.sequentialEdges) {
			indexPlanTree(child);
		}
		
		if(treeNode.getType() == NodeType.DECOMPOSITION) {
			for(PlanTreeNode child: treeNode.decompositionEdges) {
				indexPlanTree(child);
			}
		}
	}
	
	
	/**
	 * Returns all plans in the plan library, each individual child of the root
	 * node (itself a decomposition node) is a complete hierarchical plan.
	 * 
	 * @return
	 */
	public List<PlanTreeNode> getPlans() {
		ArrayList<PlanTreeNode> plans = new ArrayList<PlanTreeNode>(planTree.decompositionEdges);
		
		return plans;
	}
	
	/**
	 * Returns all the labels in this plan library (action names)
	 * @return
	 */
	public List<String> getLabels() {
		return new ArrayList<String>(this.allLabels);
	}
	
	/**
	 * Returns a list of the observable states in this plan library. This list
	 * is padded with an extra "initial state", so s[0] is always the root node.
	 * @return
	 */
	public List<PlanTreeNode> getObservableNodes() {
		ArrayList<PlanTreeNode> states = new ArrayList<PlanTreeNode>();
		states.add(planTree);
		for(PlanTreeNode node : nodeIndex.values()) {
			if(node.getType() == NodeType.ACTION) {
				states.add(node);
			}
		}
		return states;
	}
	
	/**
	 * Returns whether or not the referred node is the root of the plan library
	 * @param node
	 * @return
	 */
	public boolean isRoot(PlanTreeNode node) {
		return node == planTree;
	}
	
	/**
	 * Returns whether or not the specified node is a plan head, plan heads are all
	 * the first children of the Root node.
	 * @param node
	 * @return
	 */
	public boolean isPlanHead(PlanTreeNode node) {
		if(node.getType() == NodeType.DECOMPOSITION) {
			for(PlanTreeNode child: planTree.decompositionEdges) {
				if(node == child) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Returns a collection of all the nodes in the plan library
	 * @return
	 */
	public Collection<PlanTreeNode> getNodes() {
		return nodeIndex.values();
	}
	
	/**
	 * Prints the plan tree
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Plan Library: "+System.getProperty("line.separator"));
		sb.append("Actions: ");
		for(String label: this.allLabels) {
			sb.append(label+" ");
		}
		sb.append(System.getProperty("line.separator"));
		return planTree.toString("");
	}
}
