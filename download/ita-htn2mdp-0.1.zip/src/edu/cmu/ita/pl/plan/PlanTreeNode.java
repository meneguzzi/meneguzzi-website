package edu.cmu.ita.pl.plan;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import edu.cmu.ita.pl.tree.TreeNode;


/**
 * A node in a plan tree
 * @author meneguzzi
 *
 */

public class PlanTreeNode implements TreeNode {
	public enum NodeType {ACTION,DECOMPOSITION};
	protected String id;
	protected String label;
	protected NodeType type;
	protected List<PlanTreeNode> sequentialEdges;
	protected List<PlanTreeNode> decompositionEdges;
	protected PlanTreeNode parent;
	protected int reward;
	
	private PlanTreeNode() {
		this.sequentialEdges = new ArrayList<PlanTreeNode>();
	}
	
	public PlanTreeNode(String id, String label, NodeType type) {
		this();
		this.id = id;
		this.label = label;
		this.type = type;
		if(type == NodeType.DECOMPOSITION) {
			this.decompositionEdges = new ArrayList<PlanTreeNode>();
		}
		reward = 0;
	}
	
	/**
	 * The same as the three parameter constructor with the addition of the 
	 * optional reward value.
	 * 
	 * @param id
	 * @param label
	 * @param type
	 * @param reward
	 */
	public PlanTreeNode(String id, String label, NodeType type, int reward) {
		this(id,label,type);
		this.reward = reward;
	}
	
	/**
	 * Adds a sequential child to this tree
	 * @param node
	 */
	public void addSequentialChild(PlanTreeNode node) {
		this.addChild(node);
	}

	@Override
	public void addChild(TreeNode node) {
		this.sequentialEdges.add((PlanTreeNode) node);
		node.setParent(this);
	}

	/**
	 * Gets the indexed sequential child
	 * @param index
	 * @return
	 */
	public PlanTreeNode getSequentialChild(int index) {
		return this.sequentialEdges.get(index);
	}
	
	@Override
	public TreeNode getChild(int index) {
		return this.sequentialEdges.get(index);
	}
	
	/**
	 * Adds a decomposition child, only works if the node is a decomposition
	 * @param node
	 */
	public void addDecompositionChild(PlanTreeNode node) {
		if(type == NodeType.ACTION) {
			//throw new PlanException?
			//TODO We got to handle the problem here
		} else {
			this.decompositionEdges.add(node);
			node.setParent(this);
		}
	}
	
	/**
	 * Returns the indexed decomposition child node
	 * @param index
	 * @return
	 */
	public PlanTreeNode getDecompositionChild(int index) {
		if(type == NodeType.DECOMPOSITION) {
			return this.decompositionEdges.get(index);
		} else {
			return null;
		}
	}
	
	/**
	 * Returns all sequential children of this node
	 * @return
	 */
	public Iterator<PlanTreeNode> getSequentialChildren() {
		return sequentialEdges.iterator();
	}
	
	/**
	 * Returns all decomposition children, if this node is a decomposition node.
	 * @return
	 */
	public Iterator<PlanTreeNode> getDecompositionChildren() {
		if(type == NodeType.DECOMPOSITION) {
			return decompositionEdges.iterator();
		} else {
			return null;
		}
	}
	
	@Override
	public Iterator<TreeNode> getChildren() {
		ArrayList<TreeNode> list = new ArrayList<TreeNode>();
		list.addAll(this.sequentialEdges);
		list.addAll(this.decompositionEdges);
		return list.iterator();
	}

	@Override
	public int getChildCount() {
		return sequentialEdges.size()+decompositionEdges.size();
	}

	@Override
	public TreeNode getParent() {
		return this.parent;
	}

	@Override
	public void setParent(TreeNode parent) {
		this.parent = (PlanTreeNode) parent;
	}


	/**
	 * Returns a list of the possible previous observable nodes
	 * @return
	 */
	public List<PlanTreeNode> getPreviousObservable() {
		ArrayList<PlanTreeNode> previous = new ArrayList<PlanTreeNode>();
		//But if the parent is not an action, then every possible 
		//child of decomposition is a potential previous state
		collectPrevious(this, previous);
		
		return previous;
	}
	
	protected void collectPrevious(PlanTreeNode node, List<PlanTreeNode> previous) {
		//If the parent is null, we are talking about the root
		if(node.parent == null) {
			//So root should be the antecedent
			previous.add(node);
		} else if(node.parent.getType() == NodeType.ACTION) {
			previous.add(node.parent);
		} else {
			if(node.parent.isSequentialParentOf(node)) {
				//Add all children of parent
				collectPreviousFromDecompositionNode(node.parent, previous);
			} else {
				//If this is the refinement of a decomposition, we go recursively
				collectPrevious(node.parent, previous);
			}
		}
		
	}
	
	/**
	 * Collect all the possible end states out of a decomposition edge
	 * TODO review this for sequences of actions as decompositions
	 * @param node
	 * @param previous
	 */
	protected void collectPreviousFromDecompositionNode(PlanTreeNode node, List<PlanTreeNode> previous) {
		assert(node.type != NodeType.ACTION);
		for(PlanTreeNode child:node.decompositionEdges) {
			if(child.type == NodeType.ACTION) {
				previous.add(child);
			} else {
				collectPrevious(child, previous);
			}
		}
	}
	
	/**
	 * Returns whether or not the supplied node is a child by decomposition.
	 * @param node
	 * @return
	 */
	public boolean isDecompositionParentOf(PlanTreeNode node) {
		return (decompositionEdges.contains(node));
	}
	
	/**
	 * Returns whether or not the supplied node is a child by a sequential edge.
	 * @param node
	 * @return
	 */
	public boolean isSequentialParentOf(PlanTreeNode node) {
		return sequentialEdges.contains(node);
	}

	public String getId() {
		return id;
	}



	public String getLabel() {
		return label;
	}



	public NodeType getType() {
		return type;
	}
	
	@Override
	public boolean isLeaf() {
		return (sequentialEdges.isEmpty() && (decompositionEdges == null || decompositionEdges.isEmpty()));
	}
	
	public int getReward() {
		return reward;
	}
	
	@Override
	/**
	 * Prints the subtree rooted in this node
	 */
	public String toString() {
		return this.id+" '"+label+"' "+type.toString()+" r="+reward;
	}
	
	protected String toString(String prefix) {
		StringBuilder sb = new StringBuilder();
		sb.append(prefix+this.toString()+System.getProperty("line.separator"));
		
		if(!sequentialEdges.isEmpty()) {
			sb.append(prefix+"seq:"+System.getProperty("line.separator"));
		}
		for(PlanTreeNode node : this.sequentialEdges) {
			sb.append(node.toString(prefix+"  ")+System.getProperty("line.separator"));
		}
		
		if(decompositionEdges != null) {
			sb.append(prefix+"dec:"+System.getProperty("line.separator"));
			for(PlanTreeNode node : this.decompositionEdges) {
				sb.append(node.toString(prefix+"  ")+System.getProperty("line.separator"));
			}
		}
		
		return sb.toString();
	}
}
