package edu.cmu.ita.util;


/**
 * 
 * @author jeanoh
 *
 */

public abstract class IndexedObject {
	
	protected int index;
	
	public IndexedObject() {
		setIndex();
	}
	
	protected abstract void setIndex();
	
	public int getIndex() { return index; }

	public boolean equals(IndexedObject a) {
		return this.index == a.index;
	}

	public int hashCode() {
		return index;
	}
}
