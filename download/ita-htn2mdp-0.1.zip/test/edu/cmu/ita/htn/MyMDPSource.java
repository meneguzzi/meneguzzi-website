/**
 * Created on Jan 21, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import java.util.ArrayList;
import java.util.List;

import edu.cmu.ita.mdp.Action;
import edu.cmu.ita.mdp.MDPProblem;
import edu.cmu.ita.mdp.State;
import aima.core.probability.Randomizer;
import aima.core.probability.decision.MDP;
import aima.core.probability.decision.MDPPerception;
import aima.core.probability.decision.MDPRewardFunction;
import aima.core.probability.decision.MDPSource;
import aima.core.probability.decision.MDPTransitionModel;

/**
 * @author meneguzzi
 *
 */
public class MyMDPSource implements MDPSource<State, String> {
	List<String> actions;
	List<State> finalStates;
	List<State> nonFinalStates;
	State initialState;
	
	MDPRewardFunction<State> rewardFunction;
	MDPTransitionModel<State, String> transitionModel;
	
	/**
	 * 
	 */
	public MyMDPSource(MDPProblem mdp) {
		actions = new ArrayList<String>();
		
		for(Action a: mdp.getActions()) {
			actions.add(a.toString());
		}
		
		finalStates = new ArrayList<State>();
		nonFinalStates = new ArrayList<State>();
		for(int i=0; i<mdp.getStates().size(); i++) {
			boolean isFinal = true;
			for(Action a:mdp.getActions()) {
				for(int j=0; j<mdp.getStates().size() && isFinal; j++) {
					if(i!=j && mdp.getTransitionProbability(i, a, j) != 0) {
						isFinal = false;
					}
				}
				if(!isFinal)
					break;
			}
			if(isFinal) {
				finalStates.add(mdp.getState(i));
			} else {
				nonFinalStates.add(mdp.getState(i));
			}
		}
		initialState = mdp.getState(0);
		
		rewardFunction = new MDPRewardFunction<State>();
		
		for(State s:mdp.getStates()) {
			rewardFunction.setReward(s, (double)s.getReward());
		}
		transitionModel = new MDPTransitionModel<State, String>(finalStates);
		
		for(int i=0; i<mdp.getStates().size(); i++) {
			for(Action a:mdp.getActions()) {
				for(int j=0; j<mdp.getStates().size(); j++) {
					double prob = mdp.getTransitionProbability(i, a, j);
					if(prob != 0) {
						transitionModel.setTransitionProbability(mdp.getState(i), a.toString(), mdp.getState(j), prob);
					}
				}
			}
		}
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#asMdp()
	 */
	@Override
	public MDP<State, String> asMdp() {
		return new MDP<State, String>(this);
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#execute(java.lang.Object, java.lang.Object, aima.core.probability.Randomizer)
	 */
	@Override
	public MDPPerception<State> execute(State arg0, String arg1, Randomizer arg2) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getAllActions()
	 */
	@Override
	public List<String> getAllActions() {
		return actions;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getFinalStates()
	 */
	@Override
	public List<State> getFinalStates() {
		return finalStates;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getInitialState()
	 */
	@Override
	public State getInitialState() {
		return initialState;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getNonFinalStates()
	 */
	@Override
	public List<State> getNonFinalStates() {
		return nonFinalStates;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getRewardFunction()
	 */
	@Override
	public MDPRewardFunction<State> getRewardFunction() {
		return rewardFunction;
	}

	/* (non-Javadoc)
	 * @see aima.core.probability.decision.MDPSource#getTransitionModel()
	 */
	@Override
	public MDPTransitionModel<State, String> getTransitionModel() {
		return transitionModel;
	}

}
