/**
 * Created on Dec 29, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn.parser;

import static org.junit.Assert.*;

import java.io.FileInputStream;
import java.io.FileReader;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.htn.HTNDomain;
import edu.cmu.ita.htn.Problem;

/**
 * @author meneguzzi
 *
 */
public class HTNParserTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.parser.HTNParser#parseDomain(java.io.InputStream)}.
	 */
	@Test
	public void testParseDomain1() throws Exception {
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/dummy"));
		assertNotNull(domain);
		assertNotNull(domain.getPrimitiveTasks());
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.parser.HTNParser#parseDomain(java.io.InputStream)}.
	 */
	@Test
	public void testParseDomain2() throws Exception {
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		assertNotNull(domain);
		assertNotNull(domain.getPrimitiveTasks());
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.parser.HTNParser#parseDomain(java.io.InputStream)}.
	 */
	@Test
	public void testParseDomain3() throws Exception {
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-conf-domain"));
		assertNotNull(domain);
		assertNotNull(domain.getPrimitiveTasks());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.parser.HTNParser#parseProblems(java.io.InputStream)}.
	 */
	@Test
	public void testParseProblems() throws Exception {
		HTNParser parser = new HTNParser();
		List<Problem> problems = parser.parseProblems(new FileReader("examples/htn/problem"));
		assertNotNull(problems);
		Problem problem = problems.get(0);
		assertNotNull(problem);
		assertNotNull(problem.getTn());
		assertNotNull(problem.getS0());
		
		problems = parser.parseProblems(new FileReader("examples/htn/ita-problem1"));
		assertNotNull(problems);
		problem = problems.get(0);
		assertNotNull(problem);
		assertNotNull(problem.getTn());
		assertNotNull(problem.getS0());
		
		problems = parser.parseProblems(new FileReader("examples/htn/ita-conf-problem"));
		assertNotNull(problems);
		problem = problems.get(0);
		assertNotNull(problem);
		assertNotNull(problem.getTn());
		assertNotNull(problem.getS0());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.parser.HTNParser#parseProblem(java.io.InputStream)}.
	 */
	@Test
	public void testParseProblem() throws Exception {
		HTNParser parser = new HTNParser();
		Problem problem = parser.parseProblem(new FileReader("examples/htn/problem"));
		assertNotNull(problem);
		assertNotNull(problem.getTn());
		assertNotNull(problem.getS0());
		
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem1"));
		assertNotNull(problem);
		assertNotNull(problem.getTn());
		assertNotNull(problem.getS0());
		
		problem = parser.parseProblem(new FileReader("examples/htn/ita-conf-problem"));
		assertNotNull(problem);
		assertNotNull(problem.getTn());
		assertNotNull(problem.getS0());
	}

}
