/**
 * Created on Jan 6, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import jason.asSemantics.Unifier;

import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author meneguzzi
 *
 */
public class LogicExpressionImplTest {
	
	Proposition p1;
	Proposition q1,q2;
	Proposition notP1;
	State sEmpty, s1,s2, sNeg;
	LogicExpression andExpr1, andExpr2, orExpr1, notExpr1, notExpr2;
	
	LogicExpression complexExpr1;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		p1 = HTNFactory.createProposition("p(a)");
		q1 = HTNFactory.createProposition("q(b)");
		q2 = HTNFactory.createProposition("q(a)");
		notP1 = HTNFactory.createProposition("~p(a)");
		sEmpty = new State();
		s1 = new State(new Proposition[] {p1,q1});
		s2 = new State(new Proposition[] {p1});
		sNeg = new State(new Proposition[] {notP1});
		andExpr1 = HTNFactory.createLogicExpression("(and (p ?x) (q ?y))");
		andExpr2 = HTNFactory.createLogicExpression("(and (p ?x) (q ?y) (q ?x) )");
		orExpr1 = HTNFactory.createLogicExpression("(or (p ?x) (q ?y))");
		notExpr1 = HTNFactory.createLogicExpression("(not (q ?x))");
		notExpr2 = HTNFactory.createLogicExpression("(not (p ?a))");
		complexExpr1 = HTNFactory.createLogicExpression("(and (p ?x) (not (q ?y) ) )");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.LogicExpressionImpl#consequence(edu.cmu.ita.htn.State, jason.asSemantics.Unifier)}.
	 */
	@Test
	public void testConsequence() {
		Unifier un = new Unifier();
		Iterator<Unifier> iu = andExpr1.consequence(s1, un);
		assertNotNull(iu);
		assertTrue(iu.hasNext());
		
		un = new Unifier();
		iu = andExpr1.consequence(s2, un);
		assertNotNull(iu);
		assertFalse(iu.hasNext());
		
		un = new Unifier();
		iu = andExpr1.consequence(sEmpty, un);
		assertNotNull(iu);
		assertFalse(iu.hasNext());
		
		//-----
		
		un = new Unifier();
		iu = andExpr2.consequence(s1, un);
		assertNotNull(iu);
		assertFalse(iu.hasNext());
		
		un = new Unifier();
		iu = andExpr2.consequence(sEmpty, un);
		assertNotNull(iu);
		assertFalse(iu.hasNext());
		
		//-----
		
		un = new Unifier();
		iu = orExpr1.consequence(s1, un);
		assertNotNull(iu);
		assertTrue(iu.hasNext());
		
		un = new Unifier();
		iu = orExpr1.consequence(s2, un);
		assertNotNull(iu);
		assertTrue(iu.hasNext());
		
		//-----
		
		un = new Unifier();
		iu = notExpr1.consequence(s1, un);
		assertNull(iu);
		//assertFalse(iu.hasNext());
		
		un = new Unifier();
		iu = notExpr1.consequence(s2, un);
		assertNotNull(iu);
		assertTrue(iu.hasNext());
		
		un = new Unifier();
		iu = notExpr2.consequence(sEmpty, un);
		assertNotNull(iu);
		assertTrue(iu.hasNext());
		
		un = new Unifier();
		iu = notExpr2.consequence(s2, un);
		assertTrue(iu == null || !iu.hasNext());
//		assertNotNull(iu);
//		assertFalse(iu.hasNext());
		
		// ---
		
		un = new Unifier();
		iu = complexExpr1.consequence(s1, un);
		assertNotNull(iu);
		assertFalse(iu.hasNext());
		
		un = new Unifier();
		iu = complexExpr1.consequence(s2, un);
		assertNotNull(iu);
		assertTrue(iu.hasNext());
	}

}
