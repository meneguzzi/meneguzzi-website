/**
 * Created on Dec 17, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import static org.junit.Assert.*;

import java.util.Iterator;
import java.util.TreeSet;

import jason.asSemantics.Unifier;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author meneguzzi
 *
 */
public class StateTest {
	
	State sSingle;
	State sSingleN;
	State sSingleN2;
	
	State sNotGround;
	State sConsistent;
	State sConsistentFlip;
	State sConsistent2;
	State sConsistent3;
	State sConsistent4;
	
	State sInconsistent;
	State sInconsistent2;
	
	State sLargeState;
	State sLargeState2;
	State sLargeState3;
	
	Operator opGive;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
			sSingle = HTNFactory.createState("has(a)");
			sSingleN = HTNFactory.createState("~has(a)");
			sSingleN2 = new State(sSingleN);
			
			sNotGround = HTNFactory.createState("has(A)");
			
			sConsistent = HTNFactory.createState(new String[]{"has(a)", "~has(b)"});
			sConsistentFlip = HTNFactory.createState(new String[]{"~has(b)", "has(a)"});
			sConsistent2 = HTNFactory.createState(new String[]{"has(a)", "~has(A)"});
			sConsistent3 = HTNFactory.createState(new String[]{"has(a)", "apple(a)"});
			sConsistent4 = HTNFactory.createState(new String[]{"has(A)", "has(B)"});
			sInconsistent = HTNFactory.createState(new String[] {"has(a)", "~has(a)"});
			sInconsistent2 = HTNFactory.createState(new String[]{"has(A)", "~has(A)"});
			
			sLargeState = HTNFactory.createState(new String[] {"has(a)", "apple(a)", "orange(o)", "pineapple(p)"});
			sLargeState2 = HTNFactory.createState(new String[] {"apple(a)", "orange(o)", "pineapple(p)"});
			
			sLargeState3 = HTNFactory.createState(new String[] {"has(a)", "has(b)", "~has(c)", "pineapple(p)"});
			
			opGive = HTNFactory.createOperator("give(A)", HTNFactory.createLogicExpression(new String[]{"has(A)"}), HTNFactory.createState(new String[]{"~has(A)"}));
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#isConsistent()}.
	 */
	@Test
	public void testIsConsistent() {
		assertTrue(sSingle.isConsistent());
		assertTrue(sSingleN.isConsistent());
		assertTrue(sSingleN2.isConsistent());
		
		assertTrue(sNotGround.isConsistent());
		
		assertTrue(sConsistent.isConsistent());
		assertTrue(sConsistent2.isConsistent());
		assertTrue(sConsistent3.isConsistent());
		assertTrue(sConsistent4.isConsistent());
		assertFalse(sInconsistent.isConsistent());
		assertFalse(sInconsistent2.isConsistent());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#isGround()}.
	 */
	@Test
	public void testIsGround() {
		assertTrue(sSingle.isGround());
		assertTrue(sSingleN.isGround());
		assertFalse(sNotGround.isGround());
		
		assertTrue(sConsistent.isGround());
		assertTrue(sConsistent3.isGround());
		assertTrue(sInconsistent.isGround());
		
		assertFalse(sConsistent2.isGround());
		assertFalse(sConsistent4.isGround());
		assertFalse(sInconsistent2.isGround());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#apply(jason.asSemantics.Unifier)}.
	 */
	@Test
	public void testApply() {
		Unifier un = new Unifier();
		TreeSet<Proposition> sSingleTS = new TreeSet<Proposition>(sSingle);
		TreeSet<Proposition> sNotGroundTS = new TreeSet<Proposition>(sNotGround);
		assertTrue(un.unifies(sSingleTS.first(), sNotGroundTS.first()));
		State sNG = new State(sNotGround);
		
		assertEquals(sNotGround,sNG);
		assertTrue(sNG.apply(un));
		assertEquals(sSingle, sNG);
		
		State sInc = new State(sInconsistent2);
		assertFalse(sInconsistent.equals(sInconsistent2));
		assertFalse(sInconsistent.equals(sInc));
		assertTrue(sInc.apply(un));
		assertTrue(sInconsistent.equals(sInc));
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#intersection(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testIntersection() {
		State sInter = sLargeState.intersection(sSingle);
		assertNotNull(sInter);
		assertEquals(sInter, sSingle);
		
		sInter = sLargeState.intersection(sLargeState2);
		assertNotNull(sInter);
		assertEquals(sInter, sLargeState2);
		
		sInter = sLargeState.intersection(sConsistent4);
		assertNotNull(sInter);
		assertFalse(sInter.equals(sConsistent4));
		assertTrue(sInter.isEmpty());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#intersects(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testIntersects() {
		assertTrue(sLargeState.intersects(sSingle));
		assertFalse(sLargeState.intersects(sSingleN));
		
		assertTrue(sLargeState.intersects(sLargeState2));
		assertFalse(sLargeState.intersects(sConsistent4));
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#supports(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testSupports() {
		assertTrue(sLargeState.supports(sLargeState));
		
		assertTrue(sConsistent.supports(sSingle));
		assertFalse(sSingle.equals(sConsistent));
		assertFalse(sSingle.supports(sConsistent));
		
		assertTrue(sLargeState.supports(sLargeState2));
		assertFalse(sLargeState2.supports(sLargeState));
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.State#applyOperator(edu.cmu.ita.htn.Operator, jason.asSemantics.Unifier)}.
	 */
	@Test
	public void testApplyOperator() {
		Proposition p = HTNFactory.createProposition("give(a)");
		Unifier un = new Unifier();
		un.unifies(p, opGive);
		Operator op2 = new Operator(opGive);
		assertTrue(op2.apply(un));
		
		State sResult  = sSingle.applyOperator(opGive, un);
		assertNotNull(sResult);
		assertEquals(sSingleN,sResult);
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.State#compareTo(State)}.
	 */
	@Test
	public void testCompareTo() {
		assertEquals(-1, sSingle.compareTo(sConsistentFlip));
		assertEquals(0, sConsistent.compareTo(sConsistentFlip));
		assertEquals(1, sConsistent.compareTo(sSingle));
		
		assertFalse(0 == sSingle.compareTo(sSingleN));
	}

	/**
	 * Test method for {@link State#getUnifiablePropositions(Proposition, Unifier)}
	 * @throws Exception
	 */
	@Test
	public void testGetUnifiablePropositions() throws Exception {
		Proposition pVar = new Proposition(HTNFactory.createProposition("has(A)"));
		Proposition pGround1 = new Proposition(HTNFactory.createProposition("has(a)"));
		Proposition pGround2 = new Proposition(HTNFactory.createProposition("has(c)"));
		assertFalse(pVar.isGround());
		assertTrue(pGround1.isGround());
		assertTrue(pGround2.isGround());
		
		Unifier un = new Unifier();
		
		Iterator<Proposition> ip = sLargeState3.getUnifiablePropositions(pVar, un);
		assertNotNull(ip);
		assertTrue(ip.hasNext());
		assertEquals(pGround1, ip.next());
		int i=0;
		while(ip.hasNext()) {
			ip.next();
			i++;
		}
		assertEquals(1,i);
		
		ip = sLargeState3.getUnifiablePropositions(pGround1, un);
		assertNotNull(ip);
		assertTrue(ip.hasNext());
		assertEquals(pGround1, ip.next());
		i=0;
		while(ip.hasNext()) {
			ip.next();
			i++;
		}
		assertEquals(0,i);
		
		ip = sLargeState3.getUnifiablePropositions(pGround2, un);
		assertNull(ip);
	}
}
