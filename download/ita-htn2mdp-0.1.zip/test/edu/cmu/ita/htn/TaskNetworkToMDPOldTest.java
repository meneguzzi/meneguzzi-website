/**
 * Created on Sep 28, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import jason.asSemantics.Unifier;
import jason.asSyntax.ASSyntax;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import aima.core.probability.decision.MDP;
import aima.core.probability.decision.MDPPolicy;
import edu.cmu.ita.htn.parser.HTNParser;
import edu.cmu.ita.mdp.Action;
import edu.cmu.ita.mdp.MDPProblem;
import edu.cmu.ita.mdp.MDPSolver;
import edu.cmu.ita.mdp.Policy;
import edu.cmu.ita.mdp.graph.MDPDotConverter;

/**
 * @author meneguzzi
 *
 */
public class TaskNetworkToMDPOldTest {
	
	protected HTNDomain domain1;
	protected TaskNetwork problem1;
	
	private Task moveTo;
	private Task getVehicle;
	
	private Operator opMoveTo;
	private Operator opGetVehicle;
	
	private Task goTo;
	private Task obtainVehicle;
	private Task moveToL;
	
	private Method mGo;
	private Method mOb1;
	private Method mOb2;
	private Method mMo1;
	private Method mMo2;
	private Method mMo3;
	
	private TaskNetwork tnGo;
	private TaskNetwork tnOb1;
	private TaskNetwork tnOb2;
	private TaskNetwork tnMo1;
	private TaskNetwork tnMo2;
	private TaskNetwork tnMo3;
	
	private Task getVehicleC;
	
	@SuppressWarnings("deprecation")
	private final void createProblem1() throws Exception {
		List<Method> methods = new ArrayList<Method>();
		List<Task> actions = new ArrayList<Task>();
		List<Operator> operators = new ArrayList<Operator>();
		
		LogicExpression preconds;
		State effects;
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(V)", "at(L1)"});
		effects = HTNFactory.createState(new String[] {"at(L2)", "~at(L1)"});
		opMoveTo = HTNFactory.createOperator("moveTo(L1,L2,V)",	preconds, effects);
		moveTo = HTNFactory.createPrimitiveTask(opMoveTo);
		
		preconds = HTNFactory.createLogicExpression(new String[]{});
		effects = HTNFactory.createState(new String[] {"has(V)"});
		opGetVehicle = HTNFactory.createOperator("getVehicle(V)", preconds, effects);
		getVehicle = HTNFactory.createPrimitiveTask(opGetVehicle);
		
		operators.add(opMoveTo);
		operators.add(opGetVehicle);
		actions.add(moveTo);
		actions.add(getVehicle);
		
		goTo = HTNFactory.createTask("goTo(L)");
		obtainVehicle = HTNFactory.createTask("obtainVehicle");
		moveToL = HTNFactory.createTask("moveTo(L)");
		
		Unifier un = new Unifier();
		un.unifiesNoUndo(ASSyntax.parseVar("V"), ASSyntax.parseTerm("car"));
		getVehicleC = getVehicle.instantiateTask(un);
		preconds = HTNFactory.createLogicExpression(new String[]{});
		tnGo = new TaskNetwork(new Task[] {getVehicleC, obtainVehicle, moveToL});
		mGo = new Method("mGo", goTo, preconds, tnGo);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"at(home)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(home,airport,car)"), moveTo));
		Task moveToAirportCar = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("getVehicle(airplane)"), getVehicle));
		Task getVehicleAirplane = getVehicle.instantiateTask(un);
		tnOb1 = new TaskNetwork(new Task[] {moveToAirportCar, getVehicleAirplane});
		mOb1 = new Method("mOb1",obtainVehicle, preconds, tnOb1);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"at(home)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(home,harbor,car)"), moveTo));
		Task moveToHarborCar = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("getVehicle(ship)"), getVehicle));
		Task getVehicleShip = getVehicle.instantiateTask(un);
		tnOb2 = new TaskNetwork(new Task[] {moveToHarborCar, getVehicleShip});
		mOb2 = new Method("mOb2",obtainVehicle, preconds, tnOb2);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(airplane)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(airport,nyc,airplane)"), moveTo));
		Task moveToNYCAir = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(nyc,london,airplane)"), moveTo));
		Task moveToLondonAir = moveTo.instantiateTask(un);
		tnMo1 = new TaskNetwork(new Task[] {moveToNYCAir, moveToLondonAir});
		mMo1 = new Method("mMo1",moveToL, preconds, tnMo1);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(ship)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(harbor,soton,ship)"), moveTo));
		Task moveToSotonShip = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(soton,london,ship)"), moveTo));
		Task moveToLondonShip = moveTo.instantiateTask(un);
		tnMo2 = new TaskNetwork(new Task[] {moveToSotonShip, moveToLondonShip});
		mMo2 = new Method("mMo2",moveToL, preconds, tnMo2);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(ship)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(harbor,lpool,ship)"), moveTo));
		Task moveToLivShip = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(lpool,london,ship)"), moveTo));
		Task moveToLondonShip2 = moveTo.instantiateTask(un);
		tnMo3 = new TaskNetwork(new Task[] {moveToLivShip, moveToLondonShip2});
		mMo3 = new Method("mMo3",moveToL, preconds, tnMo3);
		
		methods.add(mGo);
		methods.add(mOb1);
		methods.add(mOb2);
		methods.add(mMo1);
		methods.add(mMo2);
		methods.add(mMo3);
		
		domain1 = new HTNDomain(methods, actions);
		
		un = new Unifier();
		un.unifies(goTo, ASSyntax.parseStructure("goTo(london)"));
		Task goToLondon = goTo.instantiateTask(un);
		problem1 = new TaskNetwork(new Task[] {goToLondon});
	}

	protected HTNDomain domain2;
	protected TaskNetwork problem2;
	
	private Task move1;
	private Task move2;
	private Task move3;
	private Task move4;
	
	private Task move5;
	private Task move6;
	private Task move7;
	private Task move8;
	
	private Task attack1;
	private Task attack2;
	
	private Task di;
	private Task aHu;
	private Task mvHu;
	private Task aAp;
	private Task mvAp;
	
	private TaskNetwork tnDI;
	private TaskNetwork tnAHu;
	private TaskNetwork tnMvHu1;
	private TaskNetwork tnMvHu2;
	private TaskNetwork tnAAp;
	private TaskNetwork tnMvAp1;
	private TaskNetwork tnMvAp2;
	
	
	private final void createProblem2() {
		List<Method> methods = new ArrayList<Method>();
		List<Task> actions = new ArrayList<Task>();
		
		move1 = HTNFactory.createPrimitiveTask("move(humvee,base,tersa,nr1)");
		move2 = HTNFactory.createPrimitiveTask("move(humvee,tersa,haram,nr2)");
		move3 = HTNFactory.createPrimitiveTask("move(humvee,haram,a,sr2)");
		move4 = HTNFactory.createPrimitiveTask("move(humvee,base,haram,hw)");
		attack1 = HTNFactory.createPrimitiveTask("attack(humvee,a)");
		
		move5 = HTNFactory.createPrimitiveTask("move(apc,base,tersa,nr1)");
		move6 = HTNFactory.createPrimitiveTask("move(apc,tersa,haram,nr2)");
		move7 = HTNFactory.createPrimitiveTask("move(apc,haram,a,sr2)");
		move8 = HTNFactory.createPrimitiveTask("move(apc,haram,a,hw)");
		attack2 = HTNFactory.createPrimitiveTask("attack(apc,a)");
		
		actions.add(move1);
		actions.add(move2);
		actions.add(move3);
		actions.add(move4);
		actions.add(move5);
		actions.add(move6);
		actions.add(move7);
		actions.add(move8);
		actions.add(attack1);
		actions.add(attack2);
		
		di = HTNFactory.createTask("defeatInsurgents(a)");
		
		aHu = HTNFactory.createTask("attackHumvee(a)");
		mvHu = HTNFactory.createTask("move(humvee,a)");
		
		aAp = HTNFactory.createTask("attackAPC(a)");
		mvAp = HTNFactory.createTask("move(apc,a)");
		
		
		tnDI = new TaskNetwork(new Task[]{aHu,mvHu,aAp,mvAp}, new Constraint[] {});
		tnDI.addBeforeConstraint(mvHu,mvAp);
		tnDI.addBeforeConstraint(mvAp,aHu);
		tnDI.addBeforeConstraint(aHu,aAp);
		Method mDI = new Method("mDI", di, tnDI);
		methods.add(mDI);
		
		
		tnAHu = new TaskNetwork(new Task[]{attack1}, new Constraint[] {});
		Method mAHu = new Method("mAHu", aHu, tnAHu);
		methods.add(mAHu);
		
		tnMvHu1 = new TaskNetwork(new Task[]{move1,move2,move3}, new Constraint[] {});
		tnMvHu1.addBeforeConstraint(move1, move2);
		tnMvHu1.addBeforeConstraint(move2, move3);
		Method mMvHu = new Method("mMvHu1", mvHu, tnMvHu1);
		methods.add(mMvHu);
		
		tnMvHu2 = new TaskNetwork(new Task[]{move4,move3}, new Constraint[] {});
		tnMvHu2.addBeforeConstraint(move4, move3);
		Method mMvHu2 = new Method("mMvHu2", mvHu, tnMvHu2);
		methods.add(mMvHu2);
		
		
		tnAAp = new TaskNetwork(new Task[]{attack2}, new Constraint[] {});
		Method mAAp = new Method("mAAp", aAp, tnAAp);
		methods.add(mAAp);
		
		tnMvAp1 = new TaskNetwork(new Task[]{move5,move6,move7}, new Constraint[] {});
		tnMvAp1.addBeforeConstraint(move5, move6);
		tnMvAp1.addBeforeConstraint(move6, move7);
		Method mMvAp = new Method("mMvAp1", mvAp, tnMvAp1);
		methods.add(mMvAp);
		
		tnMvAp2 = new TaskNetwork(new Task[]{move8,move7}, new Constraint[] {});
		tnMvAp2.addBeforeConstraint(move8, move7);
		Method mMvAp2 = new Method("mMvAp2", mvAp, tnMvAp2);
		methods.add(mMvAp2);
		
		domain2 = new HTNDomain(methods, actions);
		
		problem2 = new TaskNetwork(new Task[] {di}, new Constraint [] {});
	}
	
	private TaskNetwork problem3;
	private HTNDomain domain3;
	
	private Task getCar;
	private Task getAirplane;
	private Task getShip;
	
	private Task moveToAirport;
	private Task moveToHarbor;
	
	private Task moveToNYCAir;
	private Task moveToLondonAir;
	
	private Task moveToSotonSea;
	private Task moveToLPoolSea;
	private Task moveToLondonSea;
	
	private Task goToNoPre;
	private Task obtainVehicleAir;
	private Task obtainVehicleSea;
	private Task moveTNoPre;
	
	private TaskNetwork tnGoTo1;
	private TaskNetwork tnGoTo2;
	
	private TaskNetwork tnObtainVehicleAir;
	private TaskNetwork tnObtainVehicleSea;
	
	private TaskNetwork tnMoveAir;
	private TaskNetwork tnMoveSea1;
	private TaskNetwork tnMoveSea2;
	
	private final void createProblem3() {
		List<Method> methods = new ArrayList<Method>();
		List<Task> actions = new ArrayList<Task>();
		
		getCar = HTNFactory.createPrimitiveTask("getVehicle(car)");
		getAirplane = HTNFactory.createPrimitiveTask("getVehicle(airplane)");
		getShip = HTNFactory.createPrimitiveTask("getVehicle(ship)");
		
		moveToAirport = HTNFactory.createPrimitiveTask("moveTo(airport,car)");
		moveToHarbor = HTNFactory.createPrimitiveTask("moveTo(harbor,car)");
		
		moveToNYCAir = HTNFactory.createPrimitiveTask("moveTo(nyc,airplane)");
		moveToLondonAir = HTNFactory.createPrimitiveTask("moveTo(london,airplane)");
		
		moveToSotonSea = HTNFactory.createPrimitiveTask("moveTo(soton,ship)");
		moveToLPoolSea = HTNFactory.createPrimitiveTask("moveTo(lpool,ship)");
		moveToLondonSea = HTNFactory.createPrimitiveTask("moveTo(london,ship)");
		
		actions.add(getCar);
		actions.add(getAirplane);
		actions.add(getShip);
		actions.add(moveToAirport);
		actions.add(moveToHarbor);
		actions.add(moveToNYCAir);
		actions.add(moveToLondonAir);
		actions.add(moveToSotonSea);
		actions.add(moveToLPoolSea);
		actions.add(moveToLondonSea);
		
		goToNoPre = HTNFactory.createTask("goTo(london)");
		obtainVehicleAir = HTNFactory.createTask("obtainVehicle(airplane)");
		obtainVehicleSea = HTNFactory.createTask("obtainVehicle(ship)");
		moveTNoPre = HTNFactory.createTask("moveTo(london)");;
		
		tnGoTo1 = new TaskNetwork(new Task[]{obtainVehicleAir,moveTNoPre}, new Constraint[] {});
		tnGoTo1.addBeforeConstraint(obtainVehicleAir,moveTNoPre);
		Method mGoTo1 = new Method("mGoTo1", goToNoPre, tnGoTo1);
		methods.add(mGoTo1);
		
		tnGoTo2 = new TaskNetwork(new Task[]{obtainVehicleSea,moveTNoPre}, new Constraint[] {});
		tnGoTo2.addBeforeConstraint(obtainVehicleSea,moveTNoPre);
		Method mGoTo2 = new Method("mGoTo2", goToNoPre, tnGoTo2);
		methods.add(mGoTo2);
		
		tnObtainVehicleAir = new TaskNetwork(new Task[]{getCar,moveToAirport,getAirplane}, new Constraint[] {});
		tnObtainVehicleAir.addBeforeConstraint(getCar,moveToAirport);
		tnObtainVehicleAir.addBeforeConstraint(moveToAirport,getAirplane);
		Method mObtainVehicleAir = new Method("mObtainVehicleAir", obtainVehicleAir, tnObtainVehicleAir);
		methods.add(mObtainVehicleAir);
		
		tnObtainVehicleSea = new TaskNetwork(new Task[]{getCar,moveToHarbor,getShip}, new Constraint[] {});
		tnObtainVehicleSea.addBeforeConstraint(getCar,moveToHarbor);
		tnObtainVehicleSea.addBeforeConstraint(moveToHarbor,getShip);
		Method mObtainVehicleSea = new Method("mObtainVehicleSea", obtainVehicleSea, tnObtainVehicleSea);
		methods.add(mObtainVehicleSea);
		
		tnMoveAir = new TaskNetwork(new Task[]{moveToNYCAir,moveToLondonAir}, new Constraint[] {});
		tnMoveAir.addBeforeConstraint(moveToNYCAir,moveToLondonAir);
		Method mMoveAir = new Method("mMoveAir", moveTNoPre, tnMoveAir);
		methods.add(mMoveAir);
		
		tnMoveSea1 = new TaskNetwork(new Task[]{moveToSotonSea,moveToLondonSea}, new Constraint[] {});
		tnMoveSea1.addBeforeConstraint(moveToSotonSea,moveToLondonSea);
		Method mMoveSea1 = new Method("mMoveSea1", moveTNoPre, tnMoveSea1);
		methods.add(mMoveSea1);
		
		tnMoveSea2 = new TaskNetwork(new Task[]{moveToLPoolSea,moveToLondonSea}, new Constraint[] {});
		tnMoveSea2.addBeforeConstraint(moveToLPoolSea,moveToLondonSea);
		Method mMoveSea2 = new Method("mMoveSea2", moveTNoPre, tnMoveSea2);
		methods.add(mMoveSea2);
		
		domain3 = new HTNDomain(methods, actions);
		
		problem3 = new TaskNetwork(new Task[] {goToNoPre}, new Constraint [] {});
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		createProblem1();
		createProblem2();
		createProblem3();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetworkToMDPOld#convertTaskNetwork(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.HTNDomain, double)}.
	 * @throws IOException 
	 */
	@Test
	public void testConvertTaskNetwork() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		
		MDPProblem mdp = converter.convertTaskNetwork(HTNFactory.createState("at(home)"), problem1, domain1, 0);
		
		assertNotNull(mdp);
		System.out.println(mdp);
		FileWriter writer = new FileWriter("problem1.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		//Double check this particular result
		MDPSolver solver = new MDPSolver(mdp);
		solver.solve();
		Policy policy = solver.computeDeterministicPolicy();
		List<edu.cmu.ita.mdp.State> states = mdp.getStates();
		List<Action> actions = mdp.getActions();
		for(int i=0; i<states.size(); ++i) {
			edu.cmu.ita.mdp.State s = states.get(i);
			int actIndex = policy.getBestActionForState(i);
			Action act = actions.get(actIndex);
			assertEquals(s.getOptimalAction(), act);
		}
		System.err.println(policy);
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetworkToMDPOld#convertTaskNetwork(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.HTNDomain, double)}.
	 * @throws Exception 
	 */
	//@Test
	@SuppressWarnings("deprecation")
	public void testProblem3() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		MDPProblem problem = converter.convertTaskNetwork(goToNoPre, domain3, 1.0);
		assertNotNull(problem);
		System.out.println(problem);
		FileWriter writer = new FileWriter("problem3.dot");
		MDPDotConverter.printMDPDot(writer, problem, false);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testConvertHTNAndPlan() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		
		Policy policy = converter.convertHTNAndPlan(HTNFactory.createState("at(home)"), problem1, domain1, 1.0);
		
		assertNotNull(policy);
		policy.print();
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testGotoLondonScenario() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/gotolondon/gotolondon"));
		Problem problem = parser.parseProblem(new FileReader("examples/gotolondon/problem"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/gotolondon/gotolondonMDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/gotolondon/gotolondon"));
		problem = parser.parseProblem(new FileReader("examples/gotolondon/problem"));
		HTNExpander expander = new HTNExpander();
		TaskNetwork fullyExpanded = expander.createFullyExpandedHTN(problem.getS0(), problem.getTn(), domain);
		writer = new FileWriter("examples/gotolondon/gotolondonHTN.dot");
		HTNDotConverter.printHTNDot(writer, fullyExpanded);
		
		RunStats stats = new RunStats();
		stats.computeStats(problem, domain, fullyExpanded, mdp);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/gotolondon/gotolondon"));
		problem = parser.parseProblem(new FileReader("examples/gotolondon/problem"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/gotolondon/gotolondon"));
		problem = parser.parseProblem(new FileReader("examples/gotolondon/problem"));
		mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		MDPSolver solver = new MDPSolver(mdp);
		solver.solve();
		Policy policy = solver.computeDeterministicPolicy();
		List<edu.cmu.ita.mdp.State> states = mdp.getStates();
		List<Action> actions = mdp.getActions();
		for(int i=0; i<states.size(); ++i) {
			edu.cmu.ita.mdp.State s = states.get(i);
			int actIndex = policy.getBestActionForState(i);
			Action act = actions.get(actIndex);
			assertEquals(s.getOptimalAction(), act);
			System.out.println(s.getLabel() + " -> "+act.toString());
		}
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testConvertBasicScenario() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/basic/basic"));
		Problem problem = parser.parseProblem(new FileReader("examples/basic/problem"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/basic/basicMDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		RunStats stats = new RunStats();
		HTNExpander expander = new HTNExpander();
		TaskNetwork fullyExpanded = expander.createFullyExpandedHTN(problem.getS0(), problem.getTn(), domain);
		stats.computeStats(problem, domain, fullyExpanded, mdp);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/basic/basic"));
		problem = parser.parseProblem(new FileReader("examples/basic/problem"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testConvertITAScenarioProblem0() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem0"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem0MDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem0"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testConvertITAScenarioProblem1() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem1"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem1MDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem1"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
//	@Test
	public void testConvertITAScenarioProblem2() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem2"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem2MDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem2"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
//	@Test
	public void testConvertITAScenarioProblem3() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem3"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem3MDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem3"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
//	@Test
	public void testConvertITAScenarioProblem4() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem4"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem4MDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, true);
		
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem4"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}

	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testConvertITAScenarioProblem1Simple() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain-simplified"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem1-simple"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem1simpleMDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, false);
		writer.close();
		
		HTNFactory.resetInstances();
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain-simplified"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem1-simple"));
		HTNExpander expander = new HTNExpander();
		TaskNetwork fullyExpanded = expander.createFullyExpandedHTN(problem.getS0(), problem.getTn(), domain);
		writer = new FileWriter("examples/htn/ita-problem1simpleHTN.dot");
		HTNDotConverter.printHTNDot(writer, fullyExpanded);
		writer.close();
		
		HTNFactory.resetInstances();
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain-simplified"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem1-simple"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	/**
	 * Test method for {@link TaskNetworkToMDPOld#convertHTNAndPlan(State, TaskNetwork, HTNDomain, double)}.
	 * @throws Exception
	 */
	@Test
	public void testConvertITAScenarioProblem2Simple() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain-simplified"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem2-simple"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		FileWriter writer = new FileWriter("examples/htn/ita-problem2simpleMDP.dot");
		MDPDotConverter.printMDPDot(writer, mdp, false);
		writer.close();
		
		HTNFactory.resetInstances();
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain-simplified"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem2-simple"));
		HTNExpander expander = new HTNExpander();
		TaskNetwork fullyExpanded = expander.createFullyExpandedHTN(problem.getS0(), problem.getTn(), domain);
		writer = new FileWriter("examples/htn/ita-problem2simpleHTN.dot");
		HTNDotConverter.printHTNDot(writer, fullyExpanded);
		writer.close();
		
		HTNFactory.resetInstances();
		parser = new HTNParser();
		domain = parser.parseDomain(new FileReader("examples/htn/ita-domain-simplified"));
		problem = parser.parseProblem(new FileReader("examples/htn/ita-problem2-simple"));
		Policy pol = converter.convertHTNAndPlan(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(pol);
	}
	
	@Test
	public void testAIMAMDP() throws Exception {
		TaskNetworkToMDPOld converter = new TaskNetworkToMDPOld();
		HTNParser parser = new HTNParser();
		HTNDomain domain = parser.parseDomain(new FileReader("examples/htn/ita-domain"));
		Problem problem = parser.parseProblem(new FileReader("examples/htn/ita-problem3"));
		MDPProblem mdp = converter.convertTaskNetwork(problem.getS0(), problem.getTn(), domain, 1.0);
		assertNotNull(mdp);
		
		MyMDPSource mdpSource = new MyMDPSource(mdp);
		MDP<edu.cmu.ita.mdp.State, String> aimaMDP = mdpSource.asMdp();
		long timeAima = System.currentTimeMillis();
		MDPPolicy<edu.cmu.ita.mdp.State, String> aimaPol = aimaMDP.policyIteration(1.0);
		timeAima = System.currentTimeMillis() - timeAima;
		
		System.out.println("AIMA Policy: "+aimaPol);
		
		MDPSolver solver = new MDPSolver(mdp);
		long timeMine = System.currentTimeMillis();
		solver.solve();
		Policy pol = solver.computeDeterministicPolicy();
		timeMine = System.currentTimeMillis() - timeMine;
		assertNotNull(pol);
		System.out.println("My Policy: "+pol);
		
		System.out.println("AIMA time: "+timeAima);
		System.out.println("My time: "+timeMine);
	}

}
