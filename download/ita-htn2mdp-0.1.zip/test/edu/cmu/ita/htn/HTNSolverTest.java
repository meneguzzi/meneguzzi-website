/**
 * Created on Sep 28, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import static org.junit.Assert.*;

import jason.asSemantics.Unifier;
import jason.asSyntax.ASSyntax;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.htn.parser.ParseException;


/**
 * @author meneguzzi
 *
 */
public class HTNSolverTest {
	
	protected HTNDomain domain1;
	protected TaskNetwork problem1;
	
	private Task moveTo;
	private Task getVehicle;
	
	private Operator opMoveTo;
	private Operator opGetVehicle;
	
	private Task goTo;
	private Task obtainVehicle;
	private Task moveToL;
	
	private Method mGo;
	private Method mOb1;
	private Method mOb2;
	private Method mMo1;
	private Method mMo2;
	private Method mMo3;
	
	private TaskNetwork tnGo;
	private TaskNetwork tnOb1;
	private TaskNetwork tnOb2;
	private TaskNetwork tnMo1;
	private TaskNetwork tnMo2;
	private TaskNetwork tnMo3;
	
	private Task getVehicleC;
	
	@SuppressWarnings("deprecation")
	private final void createProblem1() throws Exception {
		List<Method> methods = new ArrayList<Method>();
		List<Task> actions = new ArrayList<Task>();
		List<Operator> operators = new ArrayList<Operator>();
		
		LogicExpression preconds;
		State effects;
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(V)", "at(L1)"});
		effects = HTNFactory.createState(new String[] {"at(L2)", "~at(L1)"});
		opMoveTo = HTNFactory.createOperator("moveTo(L1,L2,V)",	preconds, effects);
		moveTo = HTNFactory.createPrimitiveTask(opMoveTo);
		
		preconds = HTNFactory.createLogicExpression(new String[]{});
		effects = HTNFactory.createState(new String[] {"has(V)"});
		opGetVehicle = HTNFactory.createOperator("getVehicle(V)", preconds, effects);
		getVehicle = HTNFactory.createPrimitiveTask(opGetVehicle);
		
		operators.add(opMoveTo);
		operators.add(opGetVehicle);
		actions.add(moveTo);
		actions.add(getVehicle);
		
		goTo = HTNFactory.createTask("goTo(L)");
		obtainVehicle = HTNFactory.createTask("obtainVehicle");
		moveToL = HTNFactory.createTask("moveTo(L)");
		
		Unifier un = new Unifier();
		un.unifiesNoUndo(ASSyntax.parseVar("V"), ASSyntax.parseTerm("car"));
		getVehicleC = getVehicle.instantiateTask(un);
		preconds = HTNFactory.createLogicExpression(new String[]{});
		tnGo = new TaskNetwork(new Task[] {getVehicleC, obtainVehicle, moveToL});
		mGo = new Method("mGo", goTo, preconds, tnGo);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"at(home)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(home,airport,car)"), moveTo));
		Task moveToAirportCar = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("getVehicle(airplane)"), getVehicle));
		Task getVehicleAirplane = getVehicle.instantiateTask(un);
		tnOb1 = new TaskNetwork(new Task[] {moveToAirportCar, getVehicleAirplane});
		mOb1 = new Method("mOb1",obtainVehicle, preconds, tnOb1);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"at(home)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(home,harbor,car)"), moveTo));
		Task moveToHarborCar = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("getVehicle(ship)"), getVehicle));
		Task getVehicleShip = getVehicle.instantiateTask(un);
		tnOb2 = new TaskNetwork(new Task[] {moveToHarborCar, getVehicleShip});
		mOb2 = new Method("mOb2",obtainVehicle, preconds, tnOb2);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(airplane)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(airport,nyc,airplane)"), moveTo));
		Task moveToNYCAir = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(nyc,london,airplane)"), moveTo));
		Task moveToLondonAir = moveTo.instantiateTask(un);
		tnMo1 = new TaskNetwork(new Task[] {moveToNYCAir, moveToLondonAir});
		mMo1 = new Method("mMo1",moveToL, preconds, tnMo1);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(ship)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(harbor,soton,ship)"), moveTo));
		Task moveToSotonShip = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(soton,london,ship)"), moveTo));
		Task moveToLondonShip = moveTo.instantiateTask(un);
		tnMo2 = new TaskNetwork(new Task[] {moveToSotonShip, moveToLondonShip});
		mMo2 = new Method("mMo2",moveToL, preconds, tnMo2);
		
		preconds = HTNFactory.createLogicExpression(new String[]{"has(ship)"});
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(harbor,lpool,ship)"), moveTo));
		Task moveToLivShip = moveTo.instantiateTask(un);
		un = new Unifier();
		assertTrue(un.unifies(ASSyntax.parseStructure("moveTo(lpool,london,ship)"), moveTo));
		Task moveToLondonShip2 = moveTo.instantiateTask(un);
		tnMo3 = new TaskNetwork(new Task[] {moveToLivShip, moveToLondonShip2});
		mMo3 = new Method("mMo3",moveToL, preconds, tnMo3);
		
		methods.add(mGo);
		methods.add(mOb1);
		methods.add(mOb2);
		methods.add(mMo1);
		methods.add(mMo2);
		methods.add(mMo3);
		
		domain1 = new HTNDomain(methods, actions);
		
		un = new Unifier();
		un.unifies(goTo, ASSyntax.parseStructure("goTo(london)"));
		Task goToLondon = goTo.instantiateTask(un);
		problem1 = new TaskNetwork(new Task[] {goToLondon});
	}
	
	protected HTNDomain domain2;
	protected TaskNetwork problem2;
	private Task move1;
	private Task move2;
	private Task move3;
	private Task move4;
	
	private Task move5;
	private Task move6;
	private Task move7;
	private Task move8;
	
	private Task attack1;
	private Task attack2;
	
	private Task di;
	private Task aHu;
	private Task mvHu;
	private Task aAp;
	private Task mvAp;
	
	private TaskNetwork tnDI;
	private TaskNetwork tnAHu;
	private TaskNetwork tnMvHu1;
	private TaskNetwork tnMvHu2;
	private TaskNetwork tnAAp;
	private TaskNetwork tnMvAp1;
	private TaskNetwork tnMvAp2;
	
	private final void createProblem2() throws Exception {
		List<Method> methods = new ArrayList<Method>();
		List<Task> actions = new ArrayList<Task>();
		
		move1 = (Task) HTNFactory.createPrimitiveTask("move(humvee,base,tersa,nr1)");
		move2 = (Task) HTNFactory.createPrimitiveTask("move(humvee,tersa,haram,nr2)");
		move3 = (Task) HTNFactory.createPrimitiveTask("move(humvee,haram,a,sr2)");
		move4 = (Task) HTNFactory.createPrimitiveTask("move(humvee,base,haram,hw)");
		attack1 = (Task) HTNFactory.createPrimitiveTask("attack(humvee,a)");
		
		move5 = (Task) HTNFactory.createPrimitiveTask("move(apc,base,tersa,nr1)");
		move6 = (Task) HTNFactory.createPrimitiveTask("move(apc,tersa,haram,nr2)");
		move7 = (Task) HTNFactory.createPrimitiveTask("move(apc,haram,a,sr2)");
		move8 = (Task) HTNFactory.createPrimitiveTask("move(apc,haram,a,hw)");
		attack2 = (Task) HTNFactory.createPrimitiveTask("attack(apc,a)");
		
		actions.add(move1);
		actions.add(move2);
		actions.add(move3);
		actions.add(move4);
		actions.add(move5);
		actions.add(move6);
		actions.add(move7);
		actions.add(move8);
		actions.add(attack1);
		actions.add(attack2);
		
		di = HTNFactory.createTask("defeatInsurgents(a)");
		
		aHu = HTNFactory.createTask("attackHumvee(a)");
		mvHu = HTNFactory.createTask("move(humvee,a)");
		
		aAp = HTNFactory.createTask("attackAPC(a)");
		mvAp = HTNFactory.createTask("move(apc,a)");
		
		
		tnDI = new TaskNetwork(new Task[]{aHu,mvHu,aAp,mvAp}, new Constraint[] {});
		tnDI.addBeforeConstraint(mvHu,mvAp);
		tnDI.addBeforeConstraint(mvAp,aHu);
		tnDI.addBeforeConstraint(aHu,aAp);
		Method mDI = new Method("mDI", di, tnDI);
		methods.add(mDI);
		
		
		tnAHu = new TaskNetwork(new Task[]{attack1}, new Constraint[] {});
		Method mAHu = new Method("mAHu", aHu, tnAHu);
		methods.add(mAHu);
		
		tnMvHu1 = new TaskNetwork(new Task[]{move1,move2,move3}, new Constraint[] {});
		tnMvHu1.addBeforeConstraint(move1, move2);
		tnMvHu1.addBeforeConstraint(move2, move3);
		Method mMvHu = new Method("mMvHu1", mvHu, tnMvHu1);
		methods.add(mMvHu);
		
		tnMvHu2 = new TaskNetwork(new Task[]{move4,move3}, new Constraint[] {});
		tnMvHu2.addBeforeConstraint(move4, move3);
		Method mMvHu2 = new Method("mMvHu2", mvHu, tnMvHu2);
		methods.add(mMvHu2);
		
		
		tnAAp = new TaskNetwork(new Task[]{attack2}, new Constraint[] {});
		Method mAAp = new Method("mAAp", aAp, tnAAp);
		methods.add(mAAp);
		
		tnMvAp1 = new TaskNetwork(new Task[]{move5,move6,move7}, new Constraint[] {});
		tnMvAp1.addBeforeConstraint(move5, move6);
		tnMvAp1.addBeforeConstraint(move6, move7);
		Method mMvAp = new Method("mMvAp1", mvAp, tnMvAp1);
		methods.add(mMvAp);
		
		tnMvAp2 = new TaskNetwork(new Task[]{move8,move7}, new Constraint[] {});
		tnMvAp2.addBeforeConstraint(move8, move7);
		Method mMvAp2 = new Method("mMvAp2", mvAp, tnMvAp2);
		methods.add(mMvAp2);
		
		domain2 = new HTNDomain(methods, actions);
		
		problem2 = new TaskNetwork(new Task[] {di}, new Constraint [] {});
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		createProblem1();
		createProblem2();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveTask(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.HTNDomain, State)}.
	 */
	@Test
	public void testSolveTask1() {
		HTNSolver solver = new HTNSolver();
		TaskNetwork solution = solver.solveHTN(HTNFactory.createState("at(home)"), problem1, domain1);
		assertNotNull(solution);
		assertEquals(getVehicleC, solution.getFirstTask());
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveTask(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.HTNDomain, State)}.
	 */
	@Test
	public void testSolveTask2() {
		HTNSolver solver = new HTNSolver();
		TaskNetwork solution = solver.solveHTN(new State(), problem2, domain2);
		assertNotNull(solution);
		assertEquals(move1, solution.getFirstTask());
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#pfdHTN(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.HTNDomain, State)}.
	 */
	@Test
	public void testPfdHTN() {
		HTNSolver solver = new HTNSolver();
		LinkedList<Operator> solution = solver.pfdHTN(HTNFactory.createState("at(home)"), problem1, domain1);
		assertNotNull(solution);
		assertEquals("getVehicle(car)", solution.get(0).getHead().toString());
		assertEquals("moveTo(home,harbor,car)", solution.get(1).getHead().toString());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#expandWithMethodInPlace(edu.cmu.ita.htn.TaskNetwork, edu.cmu.ita.htn.Task, edu.cmu.ita.htn.Method, HTNDomain)}.
	 */
	@Test
	public void testExpandWithMethod() {
		HTNSolver solver = new HTNSolver();
		Task t1 = problem2.getFirstTask();
		assertEquals(t1,di);
		Unifier un = new Unifier();
		List<MethodOption> methods = domain2.findMethodsFor(t1,un);
		assertEquals(1,methods.size());
		
		solver.expandWithMethodInPlace(problem2, t1, methods.get(0), domain2);
		assertEquals(4,problem2.size());
		
		t1 = problem2.getFirstTask();
		assertEquals(mvHu,t1);
		methods = domain2.findMethodsFor(t1,un);
		assertEquals(2,methods.size());
		
		TaskNetwork problem1Alt = new TaskNetwork(problem2);
		solver.expandWithMethodInPlace(problem2, t1, methods.get(0), domain2);
		assertEquals(6,problem2.size());
		
		solver.expandWithMethodInPlace(problem1Alt, t1, methods.get(1), domain2);
		assertEquals(5,problem1Alt.size());
		
		
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#createFullyExpandedHTN(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.Task, java.util.List)}.
	 */
	@Test
	public void testCreateFullyExpandedHTN1() {
		HTNExpander expander = new HTNExpander();
		HTNSolver solver = new HTNSolver();
		TaskNetwork fullyExpandedNetwork = expander.createFullyExpandedHTN(HTNFactory.createState("at(home)"), problem1, domain1);
		TaskNetwork solution = solver.solveHTN(HTNFactory.createState("at(home)"), problem1, domain1);
		
		assertNotNull(fullyExpandedNetwork);
		
		assertEquals(11,fullyExpandedNetwork.size());
//		assertTrue(fullyExpandedNetwork.getFirstTask().equals(move1) || fullyExpandedNetwork.getFirstTask().equals(move4));
		assertEquals(fullyExpandedNetwork.size(), fullyExpandedNetwork.getOrderedTasks().size());
		assertTrue(fullyExpandedNetwork.getOrderedTasks().size() > solution.getOrderedTasks().size());
//		
//		TaskNetwork solution = solver.solveHTN(null, problem2, domain2);
//		assertNotNull(solution);
//		assertEquals(solution.size(), solution.getOrderedTasks().size());
//		assertTrue(fullyExpandedNetwork.getOrderedTasks().size() > solution.getOrderedTasks().size());
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#createFullyExpandedHTN(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.Task, java.util.List)}.
	 */
	@Test
	public void testCreateFullyExpandedHTN2() {
		HTNExpander expander = new HTNExpander();
		HTNSolver solver = new HTNSolver();
		TaskNetwork fullyExpandedNetwork = expander.createFullyExpandedHTN(problem2, domain2);
		assertNotNull(fullyExpandedNetwork);
		assertEquals(12,fullyExpandedNetwork.size());
		assertTrue(fullyExpandedNetwork.getFirstTask().equals(move1) || fullyExpandedNetwork.getFirstTask().equals(move4));
		assertEquals(fullyExpandedNetwork.size(), fullyExpandedNetwork.getOrderedTasks().size());
		
		TaskNetwork solution = solver.solveHTN(null, problem2, domain2);
		assertNotNull(solution);
		assertEquals(solution.size(), solution.getOrderedTasks().size());
		assertTrue(fullyExpandedNetwork.getOrderedTasks().size() > solution.getOrderedTasks().size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#expandWithAllMethods(edu.cmu.ita.htn.TaskNetwork, edu.cmu.ita.htn.Task, java.util.List, HTNDomain)}.
	 */
	@SuppressWarnings("deprecation")
	@Test
	public void testExpandWithAllMethods() {
		Unifier un = new Unifier();
		Task t1 = attack1.instantiateTask(un);
		Task t2 = attack1.instantiateTask(un);
		assertEquals(t1,t2);
	}
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	@Test
	public void testSolveHTNStringString() throws Exception {
		HTNSolver solver = new HTNSolver();
		List<Operator> plan = solver.solveHTN("examples/htn/ita-domain", "examples/htn/ita-problem1");
		assertNotNull(plan);
		System.err.print(plan);
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	@Test
	public void testSolveHTNForBasic() throws Exception {
		HTNSolver solver = new HTNSolver();
		List<Operator> plan = solver.solveHTN("examples/basic/basic", "examples/basic/problem");
		assertNotNull(plan);
		assertEquals(2,plan.size());
		assertEquals("drop(kiwi)",plan.get(0).getHeadToString());
		assertEquals("pickup(banjo)",plan.get(1).getHeadToString());
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	//@Test
	public void testSolveHTNForRover() throws Exception {
//		HTNSolver solver = new HTNSolver();
//		List<Operator> plan = solver.solveHTN("examples/rover/rover", "examples/rover/problem");
		List<Operator> plan = runHTNSolverWithTimeout("examples/rover/rover", "examples/rover/problem", 2000);
		assertNotNull(plan);
	}
	
	private final List<Operator> runHTNSolverWithTimeout(String domainFile, String problemFile, long timeout) throws Exception {
		HTNRunner htnRunner = new HTNRunner(domainFile,problemFile);
		
		htnRunner.start();
		Thread.sleep(timeout);
		if(htnRunner.plan == null) {
			fail("Timeout resolving HTN");
		} 
		return htnRunner.plan;
	}
	
	private final class HTNRunner extends Thread {
		List<Operator> plan = null;
		String domainFile, problemFile;
		
		/**
		 * 
		 */
		public HTNRunner(String domainFile, String problemFile) {
			this.domainFile = domainFile;
			this.problemFile = problemFile;
			this.setDaemon(true);
		}
		
		public void run() {
			HTNSolver solver = new HTNSolver();
			try {
				plan = solver.solveHTN(domainFile, problemFile);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
