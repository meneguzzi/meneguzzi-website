/**
 * Created on Sep 27, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 * @author meneguzzi
 *
 */
public class TaskNetworkTest {
	
	protected HTNDomain domain;
	protected TaskNetwork problem1;
	
	private Task move1;
	private Task move2;
	private Task move3;
	private Task move4;
	
	private Task move5;
	private Task move6;
	private Task move7;
	private Task move8;
	
	private Task attack1;
	private Task attack2;
	
	private Task di;
	private Task aHu;
	private Task mvHu;
	private Task aAp;
	private Task mvAp;
	
	private TaskNetwork tnDI;
	private TaskNetwork tnAHu;
	private TaskNetwork tnMvHu1;
	private TaskNetwork tnMvHu2;
	private TaskNetwork tnAAp;
	private TaskNetwork tnMvAp1;
	private TaskNetwork tnMvAp2;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		List<Method> methods = new ArrayList<Method>();
		List<Task> actions = new ArrayList<Task>();
		
		move1 = (Task) HTNFactory.createPrimitiveTask("move(humvee,base,tersa,nr1)");
		move2 = (Task) HTNFactory.createPrimitiveTask("move(humvee,tersa,haram,nr2)");
		move3 = (Task) HTNFactory.createPrimitiveTask("move(humvee,haram,a,sr2)");
		move4 = (Task) HTNFactory.createPrimitiveTask("move(humvee,base,haram,hw)");
		attack1 = (Task) HTNFactory.createPrimitiveTask("attack(humvee,a)");
		
		move5 = (Task) HTNFactory.createPrimitiveTask("move(apc,base,tersa,nr1)");
		move6 = (Task) HTNFactory.createPrimitiveTask("move(apc,tersa,haram,nr2)");
		move7 = (Task) HTNFactory.createPrimitiveTask("move(apc,haram,a,sr2)");
		move8 = (Task) HTNFactory.createPrimitiveTask("move(apc,haram,a,hw)");
		attack2 = (Task) HTNFactory.createPrimitiveTask("attack(apc,a)");
		
		actions.add(move1);
		actions.add(move2);
		actions.add(move3);
		actions.add(move4);
		actions.add(move5);
		actions.add(move6);
		actions.add(move7);
		actions.add(move8);
		actions.add(attack1);
		actions.add(attack2);
		
		di = HTNFactory.createTask("defeatInsurgents(a)");
		
		aHu = HTNFactory.createTask("attackHumvee(a)");
		mvHu = HTNFactory.createTask("move(humvee,a)");
		
		aAp = HTNFactory.createTask("attackAPC(a)");
		mvAp = HTNFactory.createTask("move(apc,a)");
		
		
		tnDI = new TaskNetwork(new Task[]{aHu,mvHu,aAp,mvAp}, new Constraint[] {});
		tnDI.addBeforeConstraint(mvHu,mvAp);
		tnDI.addBeforeConstraint(mvAp,aHu);
		tnDI.addBeforeConstraint(aHu,aAp);
		Method mDI = new Method("mDI", di, tnDI);
		methods.add(mDI);
		
		
		tnAHu = new TaskNetwork(new Task[]{attack1}, new Constraint[] {});
		Method mAHu = new Method("mAHu", aHu, tnAHu);
		methods.add(mAHu);
		
		tnMvHu1 = new TaskNetwork(new Task[]{move1,move2,move3}, new Constraint[] {});
		tnMvHu1.addBeforeConstraint(move1, move2);
		tnMvHu1.addBeforeConstraint(move2, move3);
		Method mMvHu = new Method("mMvHu1", mvHu, tnMvHu1);
		methods.add(mMvHu);
		
		tnMvHu2 = new TaskNetwork(new Task[]{move4,move3}, new Constraint[] {});
		tnMvHu2.addBeforeConstraint(move4, move3);
		Method mMvHu2 = new Method("mMvHu2", mvHu, tnMvHu2);
		methods.add(mMvHu2);
		
		
		tnAAp = new TaskNetwork(new Task[]{attack2}, new Constraint[] {});
		Method mAAp = new Method("mAAp", aAp, tnAAp);
		methods.add(mAAp);
		
		tnMvAp1 = new TaskNetwork(new Task[]{move5,move6,move7}, new Constraint[] {});
		tnMvAp1.addBeforeConstraint(move5, move6);
		tnMvAp1.addBeforeConstraint(move6, move7);
		Method mMvAp = new Method("mMvAp1", mvAp, tnMvAp1);
		methods.add(mMvAp);
		
		tnMvAp2 = new TaskNetwork(new Task[]{move8,move7}, new Constraint[] {});
		tnMvAp2.addBeforeConstraint(move8, move7);
		Method mMvAp2 = new Method("mMvAp2", mvAp, tnMvAp2);
		methods.add(mMvAp2);
		
		domain = new HTNDomain(methods, actions);
		
		problem1 = new TaskNetwork(new Task[] {di}, new Constraint [] {});
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#getFirstTask()}.
	 */
	@Test
	public void testGetFirstTask() {
		Task task = problem1.getFirstTask();
		assertEquals(di,task);
		
		task = tnMvHu1.getFirstTask();
		assertEquals(move1, task);
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#getLastTask()}.
	 */
	@Test
	public void testGetLastTask() {
		Task task = problem1.getLastTask();
		assertEquals(di,task);
		
		task = tnMvHu1.getLastTask();
		assertEquals(move3,task);
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#allTasksArePrimitive()}.
	 */
	@Test
	public void testAllTasksArePrimitive() {
		assertTrue(tnMvHu1.allTasksArePrimitive());
		assertFalse(tnDI.allTasksArePrimitive());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#addBeforeConstraint(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.Task)}.
	 */
	@Test
	public void testAddBeforeConstraint() {
		
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#getOrderedTasks()}.
	 */
	@Test
	public void testGetOrderedTasks() {
		Task tasks[] = {move1, move2, move3};
		int i=0;
		assertEquals(3, tnMvHu1.getOrderedTasks().size());
		for(Task task:tnMvHu1.getOrderedTasks()) {
			assertEquals(tasks[i++],task);
		}
		
		TreeSet<Task> ordered = new TreeSet<Task>(tnMvHu1);
		ordered.addAll(tnMvHu1.getTasks());
		assertEquals(ordered.first(), tnMvHu1.getFirstTask());
		assertEquals(ordered.last(), tnMvHu1.getLastTask());
		
		tasks = new Task[]{mvHu,mvAp,aHu,aAp};
		i = 0;
		assertEquals(4, tnDI.getOrderedTasks().size());
		for(Task task:tnDI.getOrderedTasks()) {
			assertEquals(tasks[i++],task);
		}
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#findConstraintsWithTaskBefore(edu.cmu.ita.htn.Task)}.
	 */
	@Test
	public void testFindConstraintsWithTaskBefore() {
		List<Constraint> constraints = tnMvHu1.findConstraintsWithTaskBefore(move1);
		assertEquals(1, constraints.size());
		
		constraints = tnMvHu1.findConstraintsWithTaskBefore(move3);
		assertEquals(0, constraints.size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#findConstraintsWithTaskAfter(edu.cmu.ita.htn.Task)}.
	 */
	@Test
	public void testFindConstraintsWithTaskAfter() {
		List<Constraint> constraints = tnMvHu1.findConstraintsWithTaskAfter(move1);
		assertEquals(0, constraints.size());
		
		constraints = tnMvHu1.findConstraintsWithTaskAfter(move3);
		assertEquals(1, constraints.size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.TaskNetwork#compare(edu.cmu.ita.htn.Task, edu.cmu.ita.htn.Task)}.
	 */
	@Test
	public void testCompare() {
		int tb = tnMvHu1.tasksBefore(move1, move3);
		assertEquals(2,tb);
		tb = tnMvHu1.tasksBefore(move1, move2);
		assertEquals(1,tb);
		tb = tnMvHu1.tasksBefore(move2, move3);
		assertEquals(1,tb);
	}
	
	public void testMinpath() {
		
	}

}
