/**
 * Created on Jan 14, 2011 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;


import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.htn.parser.ParseException;

/**
 * @author meneguzzi
 *
 */
public class HTNSolverITADomains {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	@Test
	public void testSolveITADomainProblem1() throws Exception {
		HTNSolver solver = new HTNSolver();
		List<Operator> plan = solver.solveHTN("examples/htn/ita-domain", "examples/htn/ita-problem1");
		assertNotNull(plan);
		System.err.println(plan);
		for(Operator op:plan) {
			System.err.println(op.getHeadToString());
		}
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	@Test
	public void testSolveITADomainProblem2() throws Exception {
		HTNSolver solver = new HTNSolver();
		List<Operator> plan = solver.solveHTN("examples/htn/ita-domain", "examples/htn/ita-problem2");
		assertNotNull(plan);
		System.err.print(plan);
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	@Test
	public void testSolveITADomainProblem3() throws Exception {
		HTNSolver solver = new HTNSolver();
		List<Operator> plan = solver.solveHTN("examples/htn/ita-domain", "examples/htn/ita-problem3");
		assertNotNull(plan);
		System.err.print(plan);
	}
	
	/**
	 * Test method for {@link edu.cmu.ita.htn.HTNSolver#solveHTN(String, String)}.
	 */
	@Test
	public void testSolveITADomainProblem4() throws Exception {
		HTNSolver solver = new HTNSolver();
		List<Operator> plan = solver.solveHTN("examples/htn/ita-domain", "examples/htn/ita-problem4");
		assertNotNull(plan);
		System.err.print(plan);
	}
	
	/**
	 * Helper method to test a planning domain with a timeout (we start a thread that we kill if the timeout is reached)
	 * @param domainFile
	 * @param problemFile
	 * @param timeout
	 * @return
	 * @throws Exception
	 */
	private final List<Operator> runHTNSolverWithTimeout(String domainFile, String problemFile, long timeout) throws Exception {
		HTNRunner htnRunner = new HTNRunner(domainFile,problemFile);
		
		htnRunner.start();
		Thread.sleep(timeout);
		if(htnRunner.plan == null) {
			fail("Timeout resolving HTN");
		} 
		return htnRunner.plan;
	}
	
	private final class HTNRunner extends Thread {
		List<Operator> plan = null;
		String domainFile, problemFile;
		
		/**
		 * 
		 */
		public HTNRunner(String domainFile, String problemFile) {
			this.domainFile = domainFile;
			this.problemFile = problemFile;
			this.setDaemon(true);
		}
		
		public void run() {
			HTNSolver solver = new HTNSolver();
			try {
				plan = solver.solveHTN(domainFile, problemFile);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
