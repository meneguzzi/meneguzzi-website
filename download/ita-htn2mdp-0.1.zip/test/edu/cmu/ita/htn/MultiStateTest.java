/**
 * Created on Dec 23, 2010 for project ita-htn2mdp by meneguzzi
 */
package edu.cmu.ita.htn;

import static org.junit.Assert.*;
import jason.asSemantics.Unifier;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author meneguzzi
 *
 */
public class MultiStateTest {
	
	State sSingle;
	State sSingleN;
	State sSingleN2;
	
	State sNotGround;
	State sConsistent;
	State sConsistentFlip;
	State sConsistent2;
	State sConsistent3;
	State sConsistent4;
	
	State sInconsistent;
	State sInconsistent2;
	
	State sLargeState;
	State sLargeState2;
	State sLargeState3;
	
	Operator opGive;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		sSingle = HTNFactory.createState("has(a)");
		sSingleN = HTNFactory.createState("~has(a)");
		sSingleN2 = new State(sSingleN);
		
		sNotGround = HTNFactory.createState("has(A)");
		
		sConsistent = HTNFactory.createState(new String[]{"has(a)", "~has(b)"});
		sConsistentFlip = HTNFactory.createState(new String[]{"~has(b)", "has(a)"});
		sConsistent2 = HTNFactory.createState(new String[]{"has(a)", "~has(A)"});
		sConsistent3 = HTNFactory.createState(new String[]{"has(a)", "apple(a)"});
		sConsistent4 = HTNFactory.createState(new String[]{"has(A)", "has(B)"});
		sInconsistent = HTNFactory.createState(new String[] {"has(a)", "~has(a)"});
		sInconsistent2 = HTNFactory.createState(new String[]{"has(A)", "~has(A)"});
		
		sLargeState = HTNFactory.createState(new String[] {"has(a)", "apple(a)", "orange(o)", "pineapple(p)"});
		sLargeState2 = HTNFactory.createState(new String[] {"apple(a)", "orange(o)", "pineapple(p)"});
		sLargeState3 = HTNFactory.createState(new String[] {"~has(a)", "apple(a)", "orange(o)", "pineapple(p)"});
		
		opGive = HTNFactory.createOperator("give(A)", HTNFactory.createLogicExpression(new String[]{"has(A)"}), HTNFactory.createState(new String[]{"~has(A)"}));
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.MultiState#addState(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testAddState() {
		MultiState ms = new MultiState();
		ms.addState(sSingleN);
		ms.addState(sSingleN);
		ms.addState(sSingleN2);
		assertEquals(1, ms.size());
		
		ms.addState(sConsistent);
		assertEquals(2, ms.size());
		
		ms.addState(sConsistentFlip);
		assertEquals(2, ms.size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.MultiState#removeState(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testRemoveState() {
		MultiState ms = new MultiState();
		ms.addState(sSingle);
		ms.addState(sSingleN);
		ms.addState(sConsistent);
		assertEquals(3, ms.size());
		ms.removeState(sSingleN2);
		assertEquals(2, ms.size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.MultiState#supports(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testSupports() {
		MultiState ms = new MultiState();
		ms.addState(sSingle);
		ms.addState(sConsistent);
		ms.addState(sConsistent3);
		
		assertTrue(ms.supports(sSingle));
		assertFalse(ms.supports(sSingleN));
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.MultiState#addAll(edu.cmu.ita.htn.MultiState)}.
	 */
	@Test
	public void testAddAll() {
		MultiState ms = new MultiState();
		ms.addState(sSingle);
		ms.addState(sConsistent);
		ms.addState(sConsistent3);
		assertEquals(3, ms.size());
		
		MultiState ms2 = new MultiState();
		ms2.addState(sSingle);
		ms2.addState(sConsistent);
		ms2.addState(sLargeState);
		assertEquals(3, ms2.size());
		
		MultiState ms3 = new MultiState(ms);
		
		ms3.addAll(ms2);
		assertEquals(4, ms3.size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.MultiState#supportingStates(edu.cmu.ita.htn.State)}.
	 */
	@Test
	public void testSupportingStates() {
		MultiState ms = new MultiState();
		ms.addState(sSingle);
		ms.addState(sConsistent);
		ms.addState(sConsistent3);
		
		assertEquals(3, ms.supportingStates(sSingle).size());
	}

	/**
	 * Test method for {@link edu.cmu.ita.htn.MultiState#applyOperator(edu.cmu.ita.htn.Operator, jason.asSemantics.Unifier)}.
	 */
	@Test
	public void testApplyOperator() {
		MultiState ms = new MultiState();
		ms.addState(sSingle);
		ms.addState(sConsistent);
		ms.addState(sLargeState);
		assertEquals(3, ms.size());
		
		Proposition p = HTNFactory.createProposition("give(a)");
		Unifier un = new Unifier();
		un.unifies(p, opGive);
		Operator op2 = new Operator(opGive);
		assertTrue(op2.apply(un));
		
		MultiState res = ms.applyOperator(opGive, un);
		assertEquals(3, ms.size());
		assertTrue(res.supports(sSingleN));
		assertTrue(res.supports(sLargeState3));
		
		ms.addState(sSingleN);
		assertEquals(4, ms.size());
		res = ms.applyOperator(opGive, un);
		assertEquals(3, res.size());
		assertTrue(res.supports(sSingleN));
		assertTrue(res.supports(sLargeState3));
	}

}
