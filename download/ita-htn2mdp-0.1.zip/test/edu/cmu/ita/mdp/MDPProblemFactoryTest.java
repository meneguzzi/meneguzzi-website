package edu.cmu.ita.mdp;

import static org.junit.Assert.fail;

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.tree.parser.PlanParseException;
import edu.cmu.ita.pl.tree.parser.PlanTreeBuilder;

public class MDPProblemFactoryTest {
	
	private static Logger logger = Logger.getLogger(MDPProblemFactoryTest.class.getName());

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFromPlanLibraryPlanLibraryDouble() {
		try {
			PlanTreeBuilder builder = new PlanTreeBuilder();
			PlanLibrary library = builder.parsePlanTree("examples/test-library.xml");
			
			MDPProblemFactory factory = MDPProblemFactory.getInstance();
			
			MDPProblem problem = factory.fromPlanLibrary(library, 0);
			
			logger.warning(problem.toString());
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.toString());
		}
		
		try {
			PlanTreeBuilder builder = new PlanTreeBuilder();
			PlanLibrary library = builder.parsePlanTree("examples/test-library2.xml");
			
			MDPProblemFactory factory = MDPProblemFactory.getInstance();
			
			MDPProblem problem = factory.fromPlanLibrary(library, 0);
			
			logger.warning(problem.toString());
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test
	public void testFromFile() {
		fail("Not yet implemented");
	}

}
