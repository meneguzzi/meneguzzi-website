package edu.cmu.ita.mdp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.tree.parser.PlanParseException;
import edu.cmu.ita.pl.tree.parser.PlanTreeBuilder;

public class TransitionMatrixTest {
	
	private static Logger logger = Logger.getLogger(TransitionMatrixTest.class.getName());
	
	private TransitionMatrix matrix;

	@Before
	public void setUp() throws Exception {
		matrix = new TransitionMatrix(4, new Action("dummy",1));
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testTransitionMatrix() {
		matrix = new TransitionMatrix(4, new Action("dummy",1));
		
		//Initialize with some predictable value
		for(int i=0; i<4; i++) {
			for(int j=0; j<4; j++) {
				matrix.set(i, j, i+j);
			}
		}
		
		assertEquals(0, matrix.get(0, 0), 0d);
		assertEquals(1, matrix.get(0, 1), 0d);
		assertEquals(1, matrix.get(1, 0), 0d);
		assertEquals(2, matrix.get(1, 1), 0d);
		assertEquals(3, matrix.get(2, 1), 0d);
		assertEquals(4, matrix.get(2, 2), 0d);
		assertEquals(5, matrix.get(3, 2), 0d);
		assertEquals(6, matrix.get(3, 3), 0d);
	}

	@Test
	public void testGet() {
		assertEquals(0, matrix.get(3, 3), 0d);
		try {
			matrix.get(10, 0);
			assertFalse("This should have been an exception", true);
		} catch(ArrayIndexOutOfBoundsException e) {
			
		}
	}

	@Test
	public void testSet() {
		matrix.set(1, 1, (double)Integer.MAX_VALUE);
		try {
			matrix.set(10, 0, 1);
			assertFalse("This should have been an exception", true);
		} catch(ArrayIndexOutOfBoundsException e) {
			
		}
		assertEquals((double)Integer.MAX_VALUE, matrix.get(1, 1),0d);
	}

	@Test
	public void testNormalizeToOne() {
		for(int i=0; i<matrix.getStateCount(); i++) {
			for(int j=0; j<matrix.getStateCount(); j++) {
				matrix.set(i, j, 1);
			}
		}
		matrix.normalizeToOne(0);
		
		for(int j=0; j<matrix.getStateCount(); j++) {
			assertEquals(0.25, matrix.get(0, j), 0.009);
		}
		
		for(int i=0; i<matrix.getStateCount(); i++) {
			for(int j=0; j<matrix.getStateCount(); j++) {
				matrix.set(i, j, 1);
			}
		}
		matrix.normalizeToOne(0.2);
		
		for(int j=0; j<matrix.getStateCount(); j++) {
			assertEquals(0.2, matrix.get(0, j), 0.009);
		}
	}
	
	@Test
	public void testPopulateTransitionMatrix() {
		try {
			PlanTreeBuilder builder = new PlanTreeBuilder();
		
			PlanLibrary library = builder.parsePlanTree("examples/test-library.xml");
			
			Action action = new Action(library.getLabels().get(0), 1);
			matrix = new TransitionMatrix(library.getObservableNodes().size(), action);		
			matrix.populateTransitionMatrix(library);
			logger.warning("Before normalization: \n"+matrix.toString());
			matrix.normalizeToOne(0f);
			logger.warning("After normalization (0 error): \n"+matrix.toString());
			
			action = new Action(library.getLabels().get(1), 2);
			matrix = new TransitionMatrix(library.getObservableNodes().size(), action);		
			matrix.populateTransitionMatrix(library);
			logger.warning("Before normalization: \n"+matrix.toString());
			matrix.normalizeToOne(0.1f);
			logger.warning("After normalization (.1 error): \n"+matrix.toString());
		} catch (PlanParseException e) {
			fail(e.getMessage());
		}

		
	}
	
	@Test
	public void testToString() {
		System.out.print(matrix.toString());
	}

}
