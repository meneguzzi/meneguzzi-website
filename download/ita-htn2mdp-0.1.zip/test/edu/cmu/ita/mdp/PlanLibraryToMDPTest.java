package edu.cmu.ita.mdp;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for the command-line utility
 * @author meneguzzi
 *
 */
public class PlanLibraryToMDPTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testMain() {
		String args[] = {"examples/test-library.xml","-e",".1"};
		PlanLibraryToMDP.main(args);
		
		args = new String[] {"examples/test-library.xml","-d",".1"};
		PlanLibraryToMDP.main(args);
		
		args = new String[] {"examples/test-library.xml","-d",".1","-e",".05"};
		PlanLibraryToMDP.main(args);
		
		args = new String[] {"examples/test-library.xml","-o","examples/output.txt"};
		PlanLibraryToMDP.main(args);
		
		File flOutput = new File("examples/output.txt");
		assertTrue(flOutput.exists());
		assertTrue(flOutput.length() > 0);
		flOutput.delete();
		
		args = new String[] {"examples/test-library.xml","-o","examples/output.txt","-e",".05"};
		PlanLibraryToMDP.main(args);
		
		flOutput = new File("examples/output.txt");
		assertTrue(flOutput.exists());
		assertTrue(flOutput.length() > 0);
		flOutput.delete();
		
		//Now for the error cases
//		try {
//			args = new String[] {"examples/test-library.xml","-d",".1","-e"};
//			PlanLibraryToMDP.main(args);
//			fail("Wrong number of parameters should have resulted in an exception.");
//		} catch(Exception e) {
//			
//		}
	}

}
