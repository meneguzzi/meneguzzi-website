package edu.cmu.ita.pl.plan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Iterator;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.pl.plan.PlanTreeNode.NodeType;

public class PlanTreeNodeTest {
	
	private PlanTreeNode rootNode;
	private PlanTreeNode actionWithDecompositionParent;
	private PlanTreeNode actionWithActionParent;
	private PlanTreeNode decompositionOfActions;
	private PlanTreeNode decompositionOfDecompositions;

	@Before
	public void setUp() throws Exception {
		rootNode = new PlanTreeNode("root","Plan Library",NodeType.DECOMPOSITION);
		
		decompositionOfDecompositions = new PlanTreeNode("decOfDec","DecompositionOfDecompositions", NodeType.DECOMPOSITION);
		rootNode.addDecompositionChild(decompositionOfDecompositions);
		
		decompositionOfActions = new PlanTreeNode("decOfAct","DecompositionOfActions", NodeType.DECOMPOSITION);
		PlanTreeNode action = new PlanTreeNode("act1","Action1",NodeType.ACTION);
		decompositionOfActions.addDecompositionChild(action);
		action = new PlanTreeNode("act2","Action2",NodeType.ACTION);
		decompositionOfActions.addDecompositionChild(action);
		
		decompositionOfDecompositions.addDecompositionChild(decompositionOfActions);
		
		PlanTreeNode decomposition = new PlanTreeNode("dec1", "Decomposition1", NodeType.DECOMPOSITION);
		action = new PlanTreeNode("act3","Action3",NodeType.ACTION);
		decomposition.addDecompositionChild(action);
		action = new PlanTreeNode("act4","Action4",NodeType.ACTION);
		decomposition.addDecompositionChild(action);
		decompositionOfDecompositions.addDecompositionChild(decomposition);
		
		PlanTreeNode decomposition2 = new PlanTreeNode("dec2", "Decomposition2", NodeType.DECOMPOSITION);
		decomposition.addSequentialChild(decomposition2);
		
		action = new PlanTreeNode("act5","Action5",NodeType.ACTION);
		decomposition2.addDecompositionChild(action);
		actionWithDecompositionParent = new PlanTreeNode("actWithDec", "ActionWithDecompositionParent", NodeType.ACTION);
		decomposition2.addDecompositionChild(actionWithDecompositionParent);
		
		actionWithActionParent = new PlanTreeNode("actWithAct", "ActionWithActionParent", NodeType.ACTION);
		actionWithDecompositionParent.addSequentialChild(actionWithActionParent);
		
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddSequentialChild() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddChild() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSequentialChild() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetChild() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddDecompositionChild() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDecompositionChild() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSequentialChildren() {
		Iterator<PlanTreeNode> iterator = actionWithDecompositionParent.getSequentialChildren();
		int count = 0;
		while(iterator.hasNext()) {
			count++;
			iterator.next();
		}
		assertEquals(1,count);
	}

	@Test
	public void testGetDecompositionChildren() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPreviousObservable() {
		List<PlanTreeNode> previous = actionWithActionParent.getPreviousObservable();
		assertEquals(1, previous.size());
		
		previous = actionWithDecompositionParent.getPreviousObservable();
		assertEquals(2, previous.size());
	}

	@Test
	public void testIsDecompositionParentOf() {
		
	}

	@Test
	public void testIsSequentialParentOf() {
		fail("Not yet implemented");
	}

}
