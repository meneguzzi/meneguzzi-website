package edu.cmu.ita.pl.tree.parser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.util.logging.Logger;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import edu.cmu.ita.pl.plan.PlanLibrary;
import edu.cmu.ita.pl.plan.PlanTreeNode;
import edu.cmu.ita.pl.plan.PlanTreeNode.NodeType;

public class PlanTreeBuilderTest {
	
	@SuppressWarnings("unused")
	private static final Logger logger = Logger.getLogger(PlanTreeBuilderTest.class.getName());

	private PlanTreeBuilder builder;

	@Before
	public void setUp() throws Exception {
		builder = new PlanTreeBuilder();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testParsePlanTree() throws Exception {
		SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
		PlanTreeContentHandler contentHandler = new PlanTreeContentHandler(
				builder);
		File planFile = new File("examples/test-library.xml");

		parser.parse(planFile, contentHandler);
		
		//logger.warning(builder.toString());
		
		assertEquals(10, builder.treeNodes.size());

		PlanLibrary p = null;

		p = builder.buildPlanLibrary();

		assertNotNull(p);
	}

	@Test
	public void testSetRootNode() {
		try {
			builder.setRootNode(new PlanTreeNode("root", "Plan Library", NodeType.DECOMPOSITION));
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.getMessage());
		} 
		
		try {
			builder.setRootNode(new PlanTreeNode("root", "Plan Library", NodeType.ACTION));
			fail("We should have had an exception here");
		} catch (PlanParseException e) {
			//this is the expected behavior
		}
	}
	
	@Test
	public void testAddTreeNode() {
		try {
			builder.setRootNode(new PlanTreeNode("root", "Plan Library", NodeType.DECOMPOSITION));
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.getMessage());
		} 
		try {
			builder.addTreeNode(new PlanTreeNode("seq1", "SomeAction", NodeType.ACTION));
		} catch (PlanParseException e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void testAddSequentialEdge() {
		try {
			builder.setRootNode(new PlanTreeNode("root", "Plan Library", NodeType.DECOMPOSITION));
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.getMessage());
		} 
		try {
			builder.addTreeNode(new PlanTreeNode("seq1", "SomeAction", NodeType.ACTION));
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
		try {
			builder.addSequentialEdge("root", "seq1");
		} catch (PlanParseException e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	@Test
	public void testAddDecompositionEdge() {
		try {
			builder.setRootNode(new PlanTreeNode("root", "Plan Library", NodeType.DECOMPOSITION));
		} catch (PlanParseException e) {
			e.printStackTrace();
			assertTrue(e.getMessage(), false);
		} 
		try {
			builder.addTreeNode(new PlanTreeNode("dec1", null, NodeType.DECOMPOSITION));
		} catch (PlanParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testBuildPlanTree() throws Exception {
		SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
		PlanTreeContentHandler contentHandler = new PlanTreeContentHandler(
				builder);
		File planFile = new File("examples/test-library.xml");

		parser.parse(planFile, contentHandler);
		
		PlanLibrary p = null;

		p = builder.buildPlanLibrary();

		assertNotNull(p);
	}

}
