#!/bin/bash

CLASSPATH=../bin
BASEDIR=./htn/
DOMAINNAME=ita-domain
PROBLEM=ita-problem2

for file in ../lib/*.jar
do
	CLASSPATH=${CLASSPATH}:${file}
done

java -Xms1g -Xmx2g -d64 -cp ${CLASSPATH} edu.cmu.ita.htn.TaskNetworkToMDP -d ${BASEDIR}/${DOMAINNAME} -p ${BASEDIR}/${PROBLEM} -o ${BASEDIR}/${PROBLEM}Policy.txt -mg ${BASEDIR}/${PROBLEM}MDP.dot -stats ${BASEDIR}/${PROBLEM}Stats.txt
dot -Tpdf ${BASEDIR}/${PROBLEM}MDP.dot -o ${BASEDIR}/${PROBLEM}MDP.dot.pdf

# for PROBLEM in ${BASEDIR}/ita-problem?
# do
# 	java -cp ${CLASSPATH} edu.cmu.ita.htn.TaskNetworkToMDP -d ${BASEDIR}/${DOMAINNAME} -p ${PROBLEM} -mg ${PROBLEM}MDP.dot -stats ${PROBLEM}Stats.txt
# 	dot -Tpdf ${PROBLEM}MDP.dot -o ${PROBLEM}MDP.dot.pdf
# done