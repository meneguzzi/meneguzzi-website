#!/bin/bash

CLASSPATH=../bin
BASEDIR=./htn/
DOMAINNAME=ita-domain-simplified
PROBLEM=ita-problem1-simple

for file in ../lib/*.jar
do
	CLASSPATH=${CLASSPATH}:${file}
done

java -cp ${CLASSPATH} edu.cmu.ita.htn.TaskNetworkToMDP -d ${BASEDIR}/${DOMAINNAME} -p ${BASEDIR}/${PROBLEM} -mg ${BASEDIR}/${PROBLEM}MDP.dot -stats ${BASEDIR}/${PROBLEM}Stats.txt
dot -Tpdf ${BASEDIR}/${PROBLEM}MDP.dot -o ${BASEDIR}/${PROBLEM}MDP.dot.pdf