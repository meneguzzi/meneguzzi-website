#!/bin/bash

for file in ita-experiment-conversion?.txt
do
	cat ${file} >> ita-experiment-conversion.txt
done

for file in ita-experiment-mdp?.txt
do
	cat ${file} >> ita-experiment-mdp.txt
done