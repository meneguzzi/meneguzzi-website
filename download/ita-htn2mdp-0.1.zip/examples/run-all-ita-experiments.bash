#!/bin/bash

function calc () { 
   awk "BEGIN { print $* ; }" 
}

CLASSPATH=../bin
BASEDIR=./ita-experiments/
DOMAINNAME=ita-domain
# PROBLEM=ita-problem1

for file in ../lib/*.jar
do
	CLASSPATH=${CLASSPATH}:${file}
done

# for PROBLEM in ${BASEDIR}/ita-problem?
for PROBN in 1 2 3 4 5 6 7 8 9
do
	PROBLEM=ita-experiment${PROBN}
	echo "Running experiments for" ${PROBLEM}
	java -Xms2100m -Xmx2100m -d64 -cp ${CLASSPATH} edu.cmu.ita.htn.TaskNetworkToMDP -d ${BASEDIR}/${DOMAINNAME} -p ${BASEDIR}/${PROBLEM} -stats ${BASEDIR}/${PROBLEM}Stats.txt -o ${BASEDIR}/${PROBLEM}Policy.txt #-mg ${BASEDIR}/${PROBLEM}MDP.dot
	# dot -Tpdf ${BASEDIR}/${PROBLEM}MDP.dot -o ${BASEDIR}/${PROBLEM}MDP.dot.pdf
	PN=`calc "${PROBN}+7"`
	grep "HTN to MDP Time    :" ${BASEDIR}/${PROBLEM}Stats.txt | sed /"HTN to MDP Time    :"/s//${PN}/ >> ${BASEDIR}/stats/ita-experiment-conversion${PROBN}.txt
	grep "MDP Solver Time    :" ${BASEDIR}/${PROBLEM}Stats.txt | sed /"MDP Solver Time    :"/s//${PN}/ >> ${BASEDIR}/stats/ita-experiment-mdp${PROBN}.txt
done

