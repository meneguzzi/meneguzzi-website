#!/bin/bash

CLASSPATH=../bin
BASEDIR=./basic
DOMAINNAME=basic
PROBLEM=problem

for file in ../lib/*.jar
do
	CLASSPATH=${CLASSPATH}:${file}
done

java -cp ${CLASSPATH} edu.cmu.ita.htn.TaskNetworkToMDP -d ${BASEDIR}/${DOMAINNAME} -p ${BASEDIR}/${PROBLEM} -mg ${BASEDIR}/${DOMAINNAME}MDP.dot -stats ${BASEDIR}/${DOMAINNAME}Stats.txt
dot -Tpdf ${BASEDIR}/${DOMAINNAME}MDP.dot -o ${BASEDIR}/${DOMAINNAME}MDP.dot.pdf