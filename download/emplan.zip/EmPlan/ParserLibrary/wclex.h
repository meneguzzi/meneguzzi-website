#ifndef WCLEX_H
#define WCLEX_H

/************************************************************
wclex.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yywclex.h>

#endif
