#ifndef LEX_H
#define LEX_H

/************************************************************
lex.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yylex.h>

#endif
