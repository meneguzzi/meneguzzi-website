#ifndef WMLEX_H
#define WMLEX_H

/************************************************************
wmlex.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yywmlex.h>

#endif
