// Plan.h: interface for the Plan class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(PARTIALORDERPLAN_H)
#define PARTIALORDERPLAN_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
using std::map;
using std::less;

#include <string>
using std::string;

#include "Operator.h"
#include "Predicate.h"
#include "Term.h"
#include "CausalLink.h"
#include "OrderLink.h"

#include "UnificationAlgorithm.h"
#include "RobinsonUnify.h"

//typedef map<string, Operator, less<string> > MSymbols;
typedef map<Predicate*, Operator*, less<Predicate*> > OperatorMap;

class PartialOrderPlan
{
protected:
	//The operators that are currently used in the plan
	OperatorVector ovSteps;
	//The "Pseudo-Operator" corresponding to the start state
	Operator *oStart;
	//The "Pseudo-Operator" corresponding to the goal state
	Operator *oGoal;
	//The causal links between plan steps denoting the linking predicates
	CausalLinkVector clvCauses;

	//The order links between plan steps
	OrderLinkVector olvOrder;

	
	//The list containing the precondition-predicates that have not been dealt
	//with by the steps currently in the plan
	//PredicateVector *pvOpen;
	OperatorMap omUnfulfilled;

public:
	OperatorVector getStepSequence();
	PartialOrderPlan(PredicateVector pvStart, PredicateVector pvGoal);
	virtual ~PartialOrderPlan();
	bool isSolution();

	Predicate * selectSubgoal();
	bool chooseOperator(Predicate *pCause, Operator *oCause, OperatorVector ovOps);
	Operator * getOperatorFromGoal(Predicate *p);
	bool resolveThreats();

	string toString();

	static RobinsonUnify unification;
};

#endif // !defined(PARTIALORDERPLAN_H)
