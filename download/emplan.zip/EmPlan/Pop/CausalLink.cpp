// ausalLink.cpp: implementation of the CausalLink class.
//
//////////////////////////////////////////////////////////////////////

#include "CausalLink.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CausalLink::CausalLink(Predicate *pPrecond, Operator *oStep1, Operator *oStep2)
{
	this->pPrecond=pPrecond;
	this->oStep1=oStep1;
	this->oStep2=oStep2;
}

CausalLink::~CausalLink()
{

}

string CausalLink::toString()
{
	string sRes="Causal Link:";
	
	if(this->oStep1!=NULL)
	{
		sRes+="\nStep: "+oStep1->toString();
	}

	if(this->pPrecond!=NULL)
	{
		sRes+="\nCauses predicate: "+pPrecond->toString();
	}

	if(this->oStep2!=NULL)
	{
		sRes+="\nCauses Step: "+oStep2->toString();
	}

	return sRes;
}

//Return if this predicate was caused by some other predicate
bool CausalLink::caused(Predicate *p)
{
	return (p==this->pPrecond);
}

Operator * CausalLink::getStep1()
{
	return this->oStep1;
}

Operator * CausalLink::getStep2()
{
	return this->oStep2;
}
