// PopPlanner.h: interface for the PopPlanner class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POPPLANNER_H__8CAF91C0_B5F7_4893_AB2C_CB8CD9726099__INCLUDED_)
#define AFX_POPPLANNER_H__8CAF91C0_B5F7_4893_AB2C_CB8CD9726099__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Planner.h"

class PopPlanner : public Planner  
{
protected:
	RobinsonUnify unification;
	PartialOrderPlan *pPlan;
public:
	PopPlanner(PredicateVector pvStart, PredicateVector pvGoal, OperatorVector ovOpers);
	virtual ~PopPlanner();
	
	virtual PartialOrderPlan *getPlan();
	virtual bool plan();

};

#endif // !defined(AFX_POPPLANNER_H__8CAF91C0_B5F7_4893_AB2C_CB8CD9726099__INCLUDED_)
