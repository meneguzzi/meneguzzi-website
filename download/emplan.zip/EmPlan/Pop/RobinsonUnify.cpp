// RobinsonUnify.cpp: implementation of the RobinsonUnify class.
//
//////////////////////////////////////////////////////////////////////

#include "RobinsonUnify.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

RobinsonUnify::RobinsonUnify()
{
	this->dn1=NULL;
	this->dn2=NULL;
	this->dnmVariables=NULL;
}

RobinsonUnify::~RobinsonUnify()
{
	delete this->dn1;
	delete this->dn2;
	delete this->dnmVariables;
}

bool RobinsonUnify::unifyPredicates(Predicate *p1, Predicate *p2)
{
	bool bRes=false;

	this->dnmVariables=new TermMap();

	//if(this->mergeVariables(p1->getVariables(), p2->getVariables()))
	//{
		dn1=p1->getTerm();
		dn2=p2->getTerm();
	//}else
	//{
	//	dn1=new Term(p1->getTerm(), dnmVariables);
	//	dn2=new Term(p2->getTerm(), dnmVariables);
	//}
	

	//PRINTL("Unifying: " << dn1->toString() << " --> " << dn2->toString())

	bRes=this->unify(dn1, dn2);

	if(!bRes)
	{
		//dn1->unBindVariables();
		//dn2->unBindVariables();
	}else
	{
		PRINTL("Unified: " << dn1->toString() << " --> " << dn2->toString())
	}

	return bRes;
}


//Extracted from The Handbook of Logic in Artificial Intelligence and Logic Programming
bool RobinsonUnify::unify(Term *k1, Term *k2)
{
	if(k1==k2)//If the nodes are physically identical, then no unification is necessary
	{
		return true;
	}else
	{
		Term *u;
		Term *v;
		//if(k2->isFunction()) // If one of the nodes is a variable node then assign the variable to *u
		if(!k2->isVariable())
		{
			u=k1;
			v=k2;
		}else
		{
			u=k2;
			v=k1;
		}
		
		if(u->isVariable())
		{
			if(v->occur(u))
				return false;// Occur check failure
			else
			{
				u->bind(v); // Replace variable u by the term corresponding to v
				return true;
			}
		}else // *u and *v are both function nodes
		{
			if((u->getName() != v->getName()) || (u->getArity() != v->getArity())) //Verify if the symbols are the same
				return false;//Clash failure
			else//If there's no clash failure, try to unify each term in *u and *v
			{
				bool bRes=true;
				int iArity=u->getArity();

				TermVector dnvTermsV=v->getTerms();
				TermVector dnvTermsU=u->getTerms();

				for(int i=0; (i<iArity && bRes); i++)
				{
					Term *dnV=dnvTermsV.at(i);
					Term *dnU=dnvTermsU.at(i);

					if(dnV->isVariable())//Added for variable trick (not in original algorithm)
						dnV=dnV->getBinding();
					if(dnU->isVariable())//Added for variable trick (not in original algorithm)
						dnU=dnU->getBinding();
					
					bRes &= unify(dnU, dnV);
				}

				return bRes;
			}
		}

	}
	return false;
}


Term *RobinsonUnify::getUnifiedNode()
{
	return this->dn1;
}

Term *RobinsonUnify::getUnifiedNode2()
{
	return this->dn2;
}

bool RobinsonUnify::mergeVariables(TermMap *dnm1, TermMap *dnm2)
{
	if(dnm1==NULL || dnm2==NULL)
		return false;

	for(TermMap::iterator i=dnm1->begin(); i!=dnm1->end(); i++)
	{
		string sName=i->first;
		Term *dnVar;
		if(dnmVariables->find(sName) != dnmVariables->end())
		{
			dnVar=(*dnmVariables)[sName];
		}else
		{
			dnVar=new Term(sName, true);
			(*dnmVariables)[sName]=dnVar;
		}
		i->second->bind(dnVar);
	}

	for(TermMap::iterator i2=dnm2->begin(); i2!=dnm2->end(); i2++)
	{
		string sName=i2->first;
		Term *dnVar;
		if(dnmVariables->find(sName) != dnmVariables->end())
		{
			dnVar=(*dnmVariables)[sName];
		}else
		{
			dnVar=new Term(sName, true);
			(*dnmVariables)[sName]=dnVar;
		}
		i2->second->bind(dnVar);
	}

	return true;
}
