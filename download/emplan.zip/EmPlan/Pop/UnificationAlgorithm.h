// UnificationAlgorithm.h: interface for the UnificationAlgorithm class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(UNIFICATIONALGORITHM_H)
#define UNIFICATIONALGORITHM_H

#include "Predicate.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class UnificationAlgorithm  
{
public:
	virtual bool unifyPredicates(Predicate *p1, Predicate *p2)=0;
	UnificationAlgorithm();
	virtual ~UnificationAlgorithm();

};

#endif // !defined(UNIFICATIONALGORITHM_H)
