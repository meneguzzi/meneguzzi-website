#include <sicstus/sicstus.h>

#include <string>
using std::string;

#include <fstream>
using std::ifstream;
using std::ofstream;

#include <iostream>
using std::cout;
using std::endl;

#include "Starter.h"
#include "CommandLineOptions.h"
#include "TimeTracker.h"

extern "C" void plan(char *sInputFile, char *sOutputFile);

//void plan();