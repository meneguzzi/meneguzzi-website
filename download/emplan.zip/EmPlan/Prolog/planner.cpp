#include "planner.h"

/*extern "C" void plan(char *sInputFile, char *sOutputFile)
{
	cout << "Planner Library 0.1\n";
	
	cout << "Infile=" << sInputFile << endl;
	cout << "Outfile=" << sOutputFile << endl;

	CommandLineOptions options;

	options.bWritePlan=true;
	options.sOutputFile=sOutputFile;
	options.sInputFile=sInputFile;
	options.bScreenPlan=false;

	Starter s(options);

	int iRes=s.start();


	if(iRes==1)
		SP_fail();

	//do something with the response so that prolog can know if
	//planning succeeded or not.
}*/

extern "C" void plan_c(char *sInputFile, char *sOutputFile, char *sPlanner, char *sStats, char *sGrounds)
{
	cout << "Planner Library 0.1\n";
	
	cout << "Infile=" << sInputFile << endl;
	cout << "Outfile=" << sOutputFile << endl;

	CommandLineOptions options;

	options.bWritePlan=true;
	options.sOutputFile=sOutputFile;
	options.sInputFile=sInputFile;
	options.bScreenPlan=false;

	string sPar=sPlanner;

	if(sPar!="")
	{
		options.iPlanner=options.selectPlanner(sPar);
	}

	sPar=sStats;
	if(sPar!="")
	{
		options.bWriteStats=true;
		options.sStatistics=sPar;
	}

	sPar=sGrounds;
	if(sPar!="")
	{
		options.bWriteGrounds=true;
		options.sGrounds=sPar;
	}

	Starter s(options);

	int iRes=s.start();


	if(iRes==1)
		SP_fail();

	//do something with the response so that prolog can know if
	//planning succeeded or not.
}