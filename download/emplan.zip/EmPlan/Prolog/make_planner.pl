:- use_module(library(flinkage)).

%:- foreign_resource(planner,[plan]).

%:- foreign(plan, plan(+string, +string)).

:- prepare_resource_table([planner],'planner_table.c').

:- prepare_foreign_resource(planner,'planner.pl','planner_glue.c').