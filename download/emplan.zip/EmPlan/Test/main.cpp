
#include "../EmPlan/Debug.h"
#include "../EmPlan/OperatorParserProxy.h"

#include "TestUnification.h"

void main(int argc, char *argv[])
{
	OperatorParserProxy parser;

	assert(argc>=2);

	string sInput=argv[1];

	parser.parse(sInput);

	TestUnification::testUnification(parser.getStart());
}