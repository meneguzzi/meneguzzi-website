// TestUnification.h: interface for the TestUnification class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TESTUNIFICATION_H__EDDF3973_11DC_4A5F_B8D0_B77B9A5F5C37__INCLUDED_)
#define AFX_TESTUNIFICATION_H__EDDF3973_11DC_4A5F_B8D0_B77B9A5F5C37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../EmPlan/Debug.h"

#include "../EmPlan/UnificationAlgorithm.h"
#include "../EmPlan/RobinsonUnify.h"

class TestUnification  
{
public:
	TestUnification();
	virtual ~TestUnification();

	static bool testUnification(PredicateVector &pvPredicates);
};

#endif // !defined(AFX_TESTUNIFICATION_H__EDDF3973_11DC_4A5F_B8D0_B77B9A5F5C37__INCLUDED_)
