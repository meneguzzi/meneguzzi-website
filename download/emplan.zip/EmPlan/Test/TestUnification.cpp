// TestUnification.cpp: implementation of the TestUnification class.
//
//////////////////////////////////////////////////////////////////////

#include "TestUnification.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TestUnification::TestUnification()
{

}

TestUnification::~TestUnification()
{

}

bool TestUnification::testUnification(PredicateVector &pvPredicates)
{
	UnificationAlgorithm *unification;

	if(pvPredicates.size() < 2)
		return false;

	unification = new RobinsonUnify();

	Predicate *p1=pvPredicates[0];
	Predicate *p2=pvPredicates[1];

	assert(p1 != NULL && p2 != NULL);

	PRINTL("Predicates being unified: " << p1->toString() << " and " << p2->toString())

	bool bRes = unification->unifyPredicates(p1, p2);

	if(bRes)
	{
		PRINTL("Unification sucessfull.")
	}else
	{
		PRINTL("Unification failed.")
	}
	PRINTL("Predicates after unification are: " << p1->toString() << " and " << p2->toString())

	return bRes;
}