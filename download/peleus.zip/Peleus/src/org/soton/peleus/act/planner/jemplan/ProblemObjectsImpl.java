package org.soton.peleus.act.planner.jemplan;

import org.soton.peleus.act.planner.ProblemObjects;

public class ProblemObjectsImpl extends ProblemObjects {

	@Override
	public String toPlannerString() {
		return "";
	}

}
