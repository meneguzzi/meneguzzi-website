package org.kcl.kastor.agent;

import jason.JasonException;
import jason.asSemantics.TransitionSystem;

import org.kcl.nestor.agent.ModularAgent;

public class KastorAgent extends ModularAgent {
	
	@Override
	public void initAg(String asSrc) throws JasonException {
		super.initAg(asSrc);
	}
}
