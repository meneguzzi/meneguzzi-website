package org.kcl.jason.env;

import jason.asSyntax.Structure;

public interface EnvironmentActions {
	
	public boolean executeAction(String agName, Structure act);
}
