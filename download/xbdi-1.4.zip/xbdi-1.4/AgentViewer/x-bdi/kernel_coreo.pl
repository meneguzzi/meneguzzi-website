coreo(Arq) :- 	nl, write('==> Kernel: Starting Choreography ...'),
			nl,nl,
			get_intentions(ListInt),
			start_exhibit_intentions(ListInt),
			open(Arq, read, Handler),
			read_coreo([Handler]).

read_coreo([]) :- !.
read_coreo([Handler|ResHandler]) :-
		read(Handler, List),
		process_coreo(List,[Handler|ResHandler],NewHandlerLis),!,
		read_coreo(NewHandlerLis).

process_coreo(end_of_file, [Handler|ResHandler], ResHandler) :- !,
		close(Handler).
process_coreo(List,HandlerLis,HandlerLis):-
		start_exhibit_sense(List),
		to_kernel(List),
		process_int_rev,
		get_intentions(ListInt),
		start_exhibit_intentions(ListInt).

process_coreo(List,HandlerLis,HandlerLis) :- 
		start_exhibit_intentions([]).
		

list_intentions([]):- !.
list_intentions([Int|R]) :-	!,nl,write(Int),
					list_intentions(R).
		
start_exhibit_sense(List):-	nl,
					write('==> Choreo: Sending to Kernel ...'),nl,nl,
					exhibit_list(List),
					nl, write('==> Choreo: Press ENTER...'),nl,
					get0(_).

start_exhibit_intentions(List) :- nl,nl,write('==> Choreo: Receiving from Kernel ...'),nl,
		exhibit_list(List),
		nl,nl,write('==> Choreo: Received! Press ENTER to continue'),nl,
		get0(_).


exhibit_list([]).
exhibit_list([sense(P,T)|Tail]) :-	!, nl,write(P),
						exhibit_list(Tail).
exhibit_list([Int|Tail]) :-	!, nl, write(Int),
					exhibit_list(Tail).

to_kernel([]).
to_kernel([current_time(T)|Tail]) :-
		!,
		retract(rule(current_time(_),_)),
		call_process_term(current_time(T)),
		to_kernel(Tail).
to_kernel([H|P]) :-	!, call_process_term(H),
				to_kernel(P).

get_intentions(IntList) :-	
		get_int_that(IntThat),
		get_int_to(IntTo),
		append(IntThat, IntTo, IntList).

get_int_that(IntThat) :-
			demo(current_time(Now)),
			findall(P,
				(rule(holds_at(P,Now), _),
				 nonvar(P), 
				 P = int_that(_, _, _, _, _)),
				IntThat).
get_int_that([]).

get_int_to(IntTo) :-
			demo(current_time(Now)),
			findall(P,
				(rule(holds_at(P,Now), _),
				 nonvar(P), 
				 P = int_to(_, _, _)),
				IntTo).
get_int_to([]).


