go :- use_module(library(system)),
      working_directory(_, './versao2.4/v24_paulo'),
      reconsult('boot'),
      working_directory(_, '../..'),
      reconsult('kernel_parser'),
      reconsult('kernel_coreo'),
      reconsult('kernel_revise').

/* :- initXBDI. */


initXBDI :- 	clean_environment,
			clean_rules,
			clean_triggers,
			clean_seeds,
			read_file('eventc.plx'),
			call_process_term(current_time(1)),  /*** deve estar no init file ***/
			parse('teste.bdi'),
			revise_intentions,
			coreo('teste.sen').

