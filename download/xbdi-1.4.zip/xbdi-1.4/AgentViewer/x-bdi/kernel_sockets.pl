kernel :-	init_socket(Socket, SocketStream),
		get_intentions(ListInt),
		send_intentions(SocketStream, ListInt),
		wait_and_process(Socket, SocketStream).

init_socket(Socket, SocketStream) :- 
	xbdiport(Port),
	xbdihost(Host),
	socket('AF_INET',Socket), 
	socket_bind(Socket, 'AF_INET'(Host,Port)),
	write('Wating for clients to connect...'), nl,
	socket_listen(Socket, 1),
	socket_accept(Socket, Client, SocketStream),
	write('Client '), write(Client), write('connected'), nl.

wait_and_process(Socket, SocketStream) :-
	repeat,
	read(SocketStream, Input),
	write('I received '), write(Input),nl,
	continue_if_not_eof(Input, Socket, SocketStream).

continue_if_not_eof(end_of_file, Socket, SocketStream) :- 
		socket_close(Socket).
continue_if_not_eof([halt], Socket, SocketStream) :- 
		socket_close(Socket).
continue_if_not_eof(Input, Socket, SocketStream) :-
		write('Sending '), write(Input), write(' to kernel'),nl,
		to_kernel(Input),
		process_int_rev,
		get_intentions(ListInt),
		send_intentions(SocketStream, ListInt),
		!, fail.
		
send_intentions(SocketStream, []) :-
		write('Im sending an empty list'), nl,
		write(SocketStream, '[do_nothing]'),
		nl(SocketStream),
		flush_output(SocketStream).

send_intentions(SocketStream, ListInt) :-
		write('Im sending '),write(ListInt),nl,
		write(SocketStream, ListInt),
		nl(SocketStream),
		flush_output(SocketStream).