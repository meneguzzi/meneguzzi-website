:- op(-,fx,1000).

holds_at(Prop,T)  :-  	initially(Prop),
				persists(0,Prop,T).

holds_at(Prop,T)  :-  	/*act(TEvt,Action), */
 				initiates(TEvt, Action ,Prop), 
				myless(TEvt, T),
				persists(TEvt,Prop,T).
holds_at(Prop,T) 	:-	sense(Prop,TP),
				myless(TP, T),
				persists(TP,Prop,T).

/***********************/
/* Reflexive Rule - test prevents loop */
holds_at(bel(Ag,P),T) :- 	holds_at(identity(Ag),T),
					prolog(P \= bel(A,B)),
					holds_at(P,T). 
/****************************/

persists(TEvt,Prop,T)  :- 	 not (clipped(TEvt,Prop,T)).

clipped(TEvt,Prop,T)  :-  	act(TIntEvt,Action),
 			 		terminates(TIntEvt, Action ,Prop), 
				 	not (out(TIntEvt,TEvt,T)).
clipped(TP,Prop,T)  :-	sense(-Prop,TIntP),
				not (out(TIntP,TP,T)).

clipped(Tp, bel(Ag, Prop), T) :- 	holds_at(identity(Ag),T),
						prolog(Prop \= bel(A,B)),
						clipped(Tp, Prop, T).
 
out(TIntEvt,TEvt,T) :-  mylesseq(T, TIntEvt).
/***out(TIntEvt,TEvt,T) :-  myless(TIntEvt, TEvt). ***/
out(TIntEvt,TEvt,T) :- mygeq(TEvt, TIntEvt).

				

/*****************
* Defines a "less" and a "lesseq" predicate to compare if
*    variables (time, in this case) are
*    all instatiated. Otherwise, it instantiantes
*    then and compare with an abducible predicate.
*******************/

myless(X,Y) :-	prolog(number(X)),
			prolog(number(Y)),
			prolog(X < Y).
myless(X,Y) :-	prolog(number(X)),
			prolog(var(Y)),
			prolog(instantiate_time(Y)),
			menor(X,Y).
myless(X,Y) :-	prolog(var(X)),
			prolog(number(Y)),
			prolog(instantiate_time(X)),
			menor(X,Y).
myless(X,Y) :-	prolog(var(X)),
			prolog(var(Y)),
			prolog(instantiate_time(X)),
			prolog(instantiate_time(Y)),
			menor(X,Y).
myless(X,Y) :-	prolog(nonvar(X)),
			prolog(nonvar(Y)),
			menor(X,Y).
myless(X,Y) :-	prolog(nonvar(X)),
			prolog(var(Y)),
			prolog(instantiate_time(Y)),
			menor(X,Y).
myless(X,Y) :-	prolog(var(X)),
			prolog(nonvar(Y)),
			prolog(instantiate_time(X)),
			menor(X,Y).
myless(X,Y) :-	menor(X,Y).

mylesseq(X,Y) :-	prolog(number(X)),
			prolog(number(Y)),
			prolog(X =< Y).

mygeq(X,Y) :-	prolog(number(X)),
			prolog(number(Y)),
			prolog(X >= Y).

/****
mylesseq(X,Y) :-	prolog(number(X)),
			prolog(var(Y)),
			prolog(instantiate_time(Y)),
			menoreq(X,Y).
mylesseq(X,Y) :-	prolog(var(X)),
			prolog(number(Y)),
			prolog(instantiate_time(X)),
			menoreq(X,Y).
mylesseq(X,Y) :-	prolog(var(X)),
			prolog(var(Y)),
			prolog(instantiate_time(X)),
			prolog(instantiate_time(Y)),
			menoreq(X,Y).
mylesseq(X,Y) :-	prolog(nonvar(X)),
			prolog(nonvar(Y)),
			prolog(X =< Y).
mylesseq(X,Y) :-	prolog(nonvar(X)),
			prolog(var(Y)),
			prolog(instantiate_time(Y)),
			menoreq(X,Y).
mylesseq(X,Y) :-	prolog(var(X)),
			prolog(nonvar(Y)),
			prolog(instantiate_time(X)),
			menoreq(X,Y).
mylesseq(X,Y) :-	menoreq(X,Y).

***/

holds_at(bel(d, existe(Id), T) :- holds_at(bel(d, aluno(Aluno, Id)), T).

initiates(T, a1, prop1) :- act(T, a1).
initiates(T, a2, prop2) :- act(T, a2).



:- not (holds_at(prop1, t_inf)), not (unsel(1)).
:- not (holds_at(prop2, t_inf)), not (unsel(2)).
:- act(T, A), act(T, B), prolog(A \= B).

:- revisable(unsel(X)).
:- revisable(act(T, A)).
:- revisable(menor(Y,Z)).

***/