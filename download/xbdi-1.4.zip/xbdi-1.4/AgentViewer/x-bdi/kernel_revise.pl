:- dynamic time_seed/1.
:- dynamic event_seed/1.
:- dynamic trigger/2.

/***********
* Verifica se � necess�rio revisar inten��es.
*   Se for, dispara o processo.
*   Se n�o for, falha.
***********/

process_int_rev :-
	no_triggers,
	revise_intentions.
process_int_rev :-
	\+ all_triggers_quiet,
	clean_triggers,
	revise_intentions.
process_int_rev.

revise_intentions :-
	clean_environment,
	get_eligible_desires(EDesires),
	set_revisables(EDesires),
	get_candidates_and_plan(Intentions),
	register_intentions_and_triggers(Intentions, EDesires).

/*************
* Coloca na base de regras as inten��es.
*   Os EDesires tornam-se int_that, 
*   os happens e acts viram int_to
* Para cada int_that e cada int_to estabelece
*   os triggers correspondentes.
*************/
register_intentions_and_triggers([], _).
register_intentions_and_triggers(Intentions, EDesires) :-
	demo(current_time(Now)),
	demo(holds_at(identity(Ag), Now)),
	extract_all_unsel(Intentions, UnselList, IntentionsNoUnsel),
	register_int_that(EDesires, UnselList, Now, t_inf, LowestTd, [0], BiggestAtr),
	register_triggers_from_desires_not_selected(BiggestAtr, Now),
	register_triggers_from_desires_became_intentions(Ag, Now),
	register_trigger_for_failact(Now),
      go_register_int_to(IntentionsNoUnsel, Now, Ag, LowestTd).

go_register_int_to([], _,_,_).
go_register_int_to(IntentionsNoUnsel, Now, Ag, LowestTd) :-
		planner(internal), !, 
		register_int_to(IntentionsNoUnsel, Now, Ag, LowestTd).
go_register_int_to(_, Now, Ag, LowestTd) :-
		planner(external), !, 
		call_external_planner(Now, Ag, LowestTd).

call_external_planner(Now, Ag, LowestTd) :-
		generate_int_file,
		plan('planin.txt', 'planout.txt'),
		get_int_from_file(Intentions),
		register_int_to(Intentions, Now, Ag, LowestTd).
call_external_planner(_, _, _) :- nl, write('Call to external planner failed!'), nl.

register_int_that([], _, _, CurrentLowestTd, CurrentLowestTd, CurrentBiggestAtr, CurrentBiggestAtr).
register_int_that([des(Nro, Ag, Prop, Td, Atr)|TEDesires], UnselList, Now, CurrentLowestTd, NewLowestTd, CurrentBiggestAtr, NewBiggestAtr) :-
		\+ member(unsel(Nro), UnselList),
		call_process_term(holds_at(int_that(Nro, Ag, Prop, Td, Atr), Now)),
		register_triggers_from_desires(des(Nro, Ag, Prop, Td, Atr)),
		lowest(CurrentLowestTd, Td, NewCurrentLowestTd),
		biggest(CurrentBiggestAtr, Atr, NewCurrentBiggestAtr),
		register_int_that(TEDesires, UnselList, Now, NewCurrentLowestTd, NewLowestTd, NewCurrentBiggestAtr, NewBiggestAtr).
register_int_that([HEDesires|TEDesires], UnselList, Now, CurrentLowestTd, NewLowestTd, CurrentBiggestAtr, NewBiggestAtr) :-
		register_int_that(TEDesires, UnselList, Now, CurrentLowestTd, NewLowestTd, CurrentBiggestAtr, NewBiggestAtr).

register_triggers_from_desires_became_intentions(Ag, Now) :-
		findall(bel(Ag, Prop),
			  (rule(holds_at(P, Now), Body),
			   nonvar(P),
			   P = int_that(_, _, Prop, _, _)),
			  AllInt),
		build_trigger_all_int(T, AllInt, Trigger),
		set_triggers_from_desires_became_intentions(T, Trigger).

set_triggers_from_desires_became_intentions(_, []) :- !.
set_triggers_from_desires_became_intentions(T, Trigger) :- 		
		assert(trigger(Trigger, T)).

build_trigger_all_int(T, [], []).
build_trigger_all_int(T, [HTrigger|[]], holds_at(HTrigger, T)).
build_trigger_all_int(T, [HTrigger|TTrigger],(holds_at(HTrigger, T),RestTrigger)) :-
		build_trigger_all_int(T, TTrigger, RestTrigger).

register_triggers_from_desires_not_selected([BiggestAtr], Now) :-
		findall(trigger(Body,T), 
			(rule(holds_at(P,T), Body),
			 nonvar(P),
			 P = des(_, _, _, _, [Atr]),
			 Atr > BiggestAtr),
			AllBodies),
		set_all_bodies(AllBodies).
register_triggers_from_desires_not_selected(_, _).

set_all_bodies([HBody|TBody]) :-
		assert(HBody),
		set_all_bodies(TBody).
set_all_bodies([]).

register_triggers_from_desires(des(_, _, _, t_inf, _)) :- !.
register_triggers_from_desires(des(_, Ag, Prop, Td, _)) :-
		assert(trigger( (prolog(CT > Td), not holds_at(bel(Ag, Prop), CT)), CT)).

register_int_to([], _, _, _).
register_int_to([act(TEvt, Action)|Int], Now, Ag, LowestTd) :-
		call_process_term(holds_at(int_to(Ag, Action, TEvt), Now)),
/***		register_triggers_from_action(LowestTd, Action, TEvt),   ***/
		register_int_to(Int, Now, Ag, LowestTd).  /*** Aqui o Int era NewInt ***/
register_int_to([HInt|TInt], Now, Ag, LowestTd) :-
		call_process_term(holds_at(int_to(Ag, HInt, _), Now)),
		register_int_to(TInt, Now, Ag, LowestTd).

/***register_triggers_from_actions(_, t_inf, _).
register_triggers_from_actions(Action, LowestTd, TEvt) :-
		assert(trigger( (prolog(CT > LowestTd), not holds_at(act(TEvt, Action), CT)), CT)). ****/
				/*** Lembrete: trigger/2 instancia o segundo argumento com o tempo corrente ***/

register_trigger_for_failact(TInt_To) :- 		
		assert(trigger( (holds_at(failact(TEvt, Action), T), prolog(T > TInt_To)), T)). 

bigger_atr_than_unsel(_, []).
bigger_atr_than_unsel([Atr], [unsel(Nro)|TUnsel]) :-
		rule(holds_at(P,_),_),
		nonvar(P),
		P = des(Nro, _, _, _, [AtrN]),
		Atr > AtrN,
		bigger_atr_than_unsel([Atr], TUnsel).

extract_all_unsel([], [], []).
extract_all_unsel([unsel(X)|Int],[unsel(X)|Unsel], IntNoUnsel) :-
		extract_all_unsel(Int, Unsel, IntNoUnsel).
extract_all_unsel([HInt|TInt], Unsel, [HInt|IntNoUnsel]) :-
		extract_all_unsel(TInt, Unsel, IntNoUnsel).

get_act(Evt, [act(X,Action)|TInt], TInt, Action) :-
		Evt == X.
get_act(Evt, [HInt|TInt], [HInt|ResInt], Action) :-
		get_act(Evt, TInt, ResInt, Action).
	
get_happens(Evt, [happens(X,TEvt)|TInt], TInt, TEvt) :-
		Evt == X.
get_happens(Evt, [HInt|TInt], [HInt|ResInt], TEvt) :-
		get_happens(Evt, TInt, ResInt, TEvt).

lowest(t_inf, Time, Time) :- !.
lowest(Time, t_inf, Time) :- !.
lowest(Time1, Time2, Time1) :- nonvar(Time1), 
					 nonvar(Time2), 
					 !, Time1 < Time2.
lowest(Time1, Time2, Time2) :- !.	

biggest([Atr1], [Atr2], [Atr1]) :- 	nonvar(Atr1),
						var(Atr2), !.
biggest([Atr1], [Atr2], [Atr2]) :- 	nonvar(Atr2),
						var(Atr1), !.
biggest([Atr1], [Atr2], [Atr1]) :-  Atr1 > Atr2, !.
biggest([Atr1], [Atr2], [Atr2]) :- !.


/**********
* Monta o conjunto de desejos eleg�veis
***********/
get_eligible_desires(EliDesires) :-	
		demo(current_time(Now)),
		demo(holds_at(identity(Id), Now)),
		findall(des(Nro, Id, Prop, T, Atr), 
			(demo(holds_at(des(Nro, Id, Prop, T, Atr), Now)),
			 check_time(T, Now),
			 demo(not holds_at(bel(Id, Prop), Now))),
			EliDesires).
get_eligible_desires([]).

check_time(t_inf, Now) :- 	!.
check_time(T, Now) :-	Now < T, !.
/*************
* Define os revisables para obter os 
*    Candidate Desires
**************/
set_revisables([]).
set_revisables(EliDesires) :- 
/***		call_process_term((:- revisable(happens(E,T)))), ***/
		call_process_term((:- revisable(act(T,A)))),
		call_process_term((:- revisable(menor(T,Y)))),
/***		call_process_term((:- revisable(menoreq(T,Z)))), ***/
		set_unsel_revisables(EliDesires).

set_unsel_revisables([EDHead|EDTail])  :-
		rule(holds_at(Prop,T), Body),
		nonvar(Prop),
 		Prop = EDHead,
		des(Nro, Ag, Pd, Td, Atr) = EDHead,
		call_process_term((:- revisable(unsel(Nro)))),
		set_conditions_inconsis(EDHead), 
		set_unsel_revisables(EDTail).
set_unsel_revisables([]) :- call_process_term((<- act(T, A), act(T, B), prolog(A \= B))).

get_unsel_in_body((not unsel(Nro)), (not unsel(Nro))).
get_unsel_in_body(((not unsel(Nro)),B), (not unsel(Nro))).
get_unsel_in_body((A,B), C) :- get_unsel_in_body(B, C).

/***********************
* Set conditions for inconsistency in order
*   to abduce unsel, happens and acts
***********************/
set_conditions_inconsis(des(Nro, Ag, Pd, Td, Atr)) :-
			call_process_term((<- (not holds_at(bel(Ag, Pd),Td)),(not unsel(Nro)))).
		
/**********************
* Instantiate time for myless and mylesseq
* Intantiate event.
***********************/
time_seed(0).
instantiate_time(X) :-	nonvar(X), !.
instantiate_time(X) :-	retract(time_seed(N)),
				N1 is N + 1,
				assert(time_seed(N1)),
				name(N1, CharN1),
				name(t, CharT),
				append(CharT, CharN1, CharX),
				name(X, CharX), !.

event_seed(0).
instantiate_event(X) :-	nonvar(X), !.
instantiate_event(X) :-	retract(event_seed(N)),
				N1 is N + 1,
				assert(event_seed(N1)),
				name(N1, CharN1),
				name(e, CharT),
				append(CharT, CharN1, CharX),
				name(X, CharX), !.


/***********
* Verifica se algum gatilho foi disparado
*    ou se n�o existem triggers.
************/
no_triggers :-
		trigger(_,_),
		!, fail.
no_triggers.

all_triggers_quiet :-
		trigger(Trigger, T),
		trigger_fired(Trigger, T),
		!, fail.
all_triggers_quiet.

trigger_fired(Trigger, T) :-
		demo(current_time(T)),
		demo(Trigger).
/***************
* Pega as solu��es, e seleciona
*   a preferida
***************/
get_candidates_and_plan(Intentions) :-
		findall(S, solution([S,_]), AllInt),
		select_prefered(AllInt, Intentions).

select_prefered([], []).
select_prefered([CurrentPrefInt|TInt], PrefInt) :-
		count_unsel_and_instantiate(CurrentPrefInt, PrefCurrent),
		select_prefered(TInt, CurrentPrefInt, PrefInt, PrefCurrent).

select_prefered([], CurrentPrefered, CurrentPrefered, _).
select_prefered([HAllInt|TAllInt], CurrentPrefered, Prefered, PrefCurrent) :- 
		count_unsel_and_instantiate(HAllInt, PrefH),
		get_prefered([CurrentPrefered, PrefCurrent], [HAllInt, PrefH], [NewPrefered, PrefNew]),
		select_prefered(TAllInt, NewPrefered, Prefered, PrefNew).

get_prefered([Int1, pref(Nro1, [])], [_, pref(Nro2, [])], [Int1, pref(Nro1, [])]) :-
		Nro1 =< Nro2, !.
get_prefered([_, pref(Nro1, [])], [Int2, pref(Nro2, [])], [Int2, pref(Nro2, [])]) :-
		Nro2 < Nro1, !.
get_prefered([Int1, pref(Nro1, [])], [_, pref(Nro2, _)], [Int1, pref(Nro1, [])]) :-
		Nro1 =< Nro2, !.
get_prefered([_, pref(Nro1, [])], [Int2, pref(Nro2, Atr2)], [Int2, pref(Nro2, Atr2)]) :-
		Nro2 < Nro1, !.
get_prefered([Int1, pref(Nro1, Atr1)], [_, pref(Nro2, [])], [Int1, pref(Nro1, Atr1)]) :-
		Nro1 =< Nro2, !.
get_prefered([_, pref(Nro1, _)], [Int2, pref(Nro2, [])], [Int2, pref(Nro2, [])]) :-
		Nro2 < Nro1, !.
get_prefered([Int1, pref(Nro, [Atr1|TAtr1])], [_, pref(_, [Atr2|_])], [Int1, pref(Nro, [Atr1|TAtr1])]) :-
		Atr1 < Atr2, !.
get_prefered([_, pref(_, [Atr1|_])], [Int2, pref(Nro, [Atr2|TAtr2])], [Int2, pref(Nro, [Atr2|TAtr2])]) :-
		Atr2 < Atr1, !.
get_prefered([Int1, pref(Nro1, [Atr1|TAtr1])], [Int2, pref(Nro2, [Atr2|TAtr2])], [Int3, pref(Nro3, [Atr1|TAtr3])]) :-
		Atr1 == Atr2, !,
		get_prefered([Int1, pref(Nro1, TAtr1)], [Int2, pref(Nro2, TAtr2)], [Int3, pref(Nro3, TAtr3)]).

/*************
* Recebe uma lista com act e unsel
*  e retorna uma estrutura pref(NroUnsel, ListAtr)
*  onde NroUnsel � o total de unsel�s e ListaAtr � uma lista
*  ordenada, em ordem decrescente, das prioridades (sem
*  repeti��es.
**************/
count_unsel_and_instantiate(Revision, Pref) :- count_unsel_and_instantiate(Revision, pref(0, []), Pref).
count_unsel_and_instantiate([], CurrentPref, CurrentPref) :- !.
count_unsel_and_instantiate([unsel(Nro)|TRevision], pref(PartialTotal, PartialAtrList), Pref) :-
		NewPartialTotal is PartialTotal + 1, 
		add_atr_list(Nro, PartialAtrList, NewPartialAtrList), !,
		count_unsel_and_instantiate(TRevision, pref(NewPartialTotal, NewPartialAtrList), Pref).
count_unsel_and_instantiate([act(TEvt, Action)|TRevision], pref(PartialTotal, PartialAtrList), Pref) :- !,
		check_time(TEvt),
		count_unsel_and_instantiate(TRevision, pref(PartialTotal, PartialAtrList), Pref).
count_unsel_and_instantiate([menor(T1, T2)|TRevision], pref(PartialTotal, PartialAtrList), Pref) :- !,
		check_time(T1),
		check_time(T2),
		count_unsel_and_instantiate(TRevision, pref(PartialTotal, PartialAtrList), Pref).
count_unsel_and_instantiate([menoreq(T1, T2)|TRevision], pref(PartialTotal, PartialAtrList), Pref) :- !,
		check_time(T1),
		check_time(T2),
		count_unsel_and_instantiate(TRevision, pref(PartialTotal, PartialAtrList), Pref).
count_unsel_and_instantiate([_|TRevision], PartialPref, Pref) :- !,
		count_unsel_and_instantiate(TRevision, PartialPref, Pref).
		
add_atr_list(Nro, AtrList, NewAtrList) :-	
		rule(holds_at(P, _), _),
		nonvar(P),
		P = des(Nro, _, _, _, [ValAtr]),
		insert_sort_cres_no_rep(ValAtr, AtrList, NewAtrList).

insert_sort_cres_no_rep(Value, [], [Value]).
insert_sort_cres_no_rep(Value, [HValue|TValue], [HValue|NewTValue]) :-
			Value < HValue, !,
			insert_sort_cres_no_rep(Value, TValue, NewTValue).
insert_sort_cres_no_rep(Value, [HValue|TValue], [HValue|TValue]) :- 
			Value == HValue, !.
insert_sort_cres_no_rep(Value, [HValue|TValue], [Value, HValue|TValue]).

check_time(Time) :- 
		var(Time),
		instantiate_time(Time).
check_time(_).

check_event(Event) :- 
		var(Event),
		instantiate_event(Event).
check_event(_).

/***************
* Procedimentos para external planner
****************/

generate_int_file :-
	tell('planin.txt'),
	get_start_situation(StartList),
	write('start('),
	write_start_list(StartList),
	write(')'), 
	nl,
	write('goal('),
	demo(current_time(Now)),
	rule(holds_at(P,Now), _),
	nonvar(P),
	P = int_that(_, Ag, Prop, Ti, _),
	get_int_that_leaf(Prop, GoalList),
	write_goal_list(GoalList),
	fail.
generate_int_file :- 
	write(')'),
	nl,
	generate_actions,
	told.

get_start_situation(StartList) :-
	findall(P,
		  (demo(current_time(Now)), demo(holds_at(P, Now)), 
		   P \= int_that(_,_,_,_,_), P \= int_to(_,_,_), P \= des(_,_,_,_,_)), /***coloca aqui o que n�o interessa**/
		  StartList), !.									     /***   no start do planin.txt **/

get_int_that_leaf((holds_at(P,_), B), List) :- !,
	get_int_that_leaf(P, List1),
	get_int_that_leaf(B, List2),
	append(List1, List2, List).
get_int_that_leaf((bel(_, Prop), B), List) :- !,	
	get_int_that_leaf(Prop, List1),
	get_int_that_leaf(B, List2),
	append(List1, List2, List).
get_int_that_leaf((act(_,_), B), List) :-	!,
	get_int_that_leaf(B, List).
get_int_that_leaf((true, B), List) :-	!,
	get_int_that_leaf(B, List).

get_int_that_leaf(holds_at(P, _), List) :- !,
	get_int_that_leaf(P, List).
get_int_that_leaf(act(_,_), []) :-	!.
get_int_that_leaf(true, []) :-	!.
get_int_that_leaf(bel(Ag, Prop), [Prop|[]]) :-
	rule(initiates(_, _, bel(Ag, Prop)), _), !.
get_int_that_leaf(bel(_, Prop), ListProp) :-
	rule(holds_at(P,T), Body),
	nonvar(P),
	P = bel(_, P1),
	nonvar(P1), 
      Prop = P1, !,
	get_int_that_leaf(Body, ListProp).
get_int_that_leaf(Prop, [Prop|[]]) :- !.
	

write_goal_list([]).
write_goal_list([HGoal|[]]) :- !,
	write(HGoal).
write_goal_list([HGoal|TGoal]) :- !,
	write(Goal),write(','),
	write_goal_list(TGoal).

write_start_list([]).
write_start_list([bel(Ag, P)|[]]) :- !,
	write(P).
write_start_list([int_that(_,_,_,_,_)|[]]) :- !.
write_start_list([int_to(_,_,_)|[]]) :- !.
write_start_list([HStart|[]]) :- !,
	write(HStart).
write_start_list([bel(Ag, P)|TStart]) :- !,
	write(P), write(','),
	write_start_list(TStart).
write_start_list([int_that(_,_,_,_,_)|TStart]) :- !,
	write_start_list(TStart).
write_start_list([int_to(_,_,_)|TStart]) :- !,
	write_start_list(TStart).
write_start_list([HStart|TStart]) :- !,
	write(HStart), write(','),
	write_start_list(TStart).

get_int_from_file(Intentions) :-
	see('planout.txt'),
	read(Action),
	demo(current_time(Now)),
	demo(holds_at(identity(Ag), Now)),
	read_int_from_file(Action, Ag, Intentions),
	seen.
	
read_int_from_file(end_of_file, _, []).
read_int_from_file(Action, Ag, [act(Time, act(Ag, Action))|TInt]) :-
	check_time(Time),
	read(NewAction),
	read_int_from_file(NewAction, Ag, TInt).

generate_actions :-
	findall(actStruct(Action, Effects, Preconds),
		rule(initiates(_, act(_, Action), Effects), Preconds),
		ActStructList),
	merge_actions_list(ActStructList, ActMergeList),
	record_actions(ActMergeList).

% Commented out by MIchael
%generate_actions :-
%	findall(actStruct(Action, Effects, Preconds),
%		rule(initiates(_, act(_, Action), Effects), Preconds),
%		ActStructList),
%	remove_Bel_Functors(ActStructList, ActStructList2),
%	merge_actions_list(ActStructList2, ActMergeList),
%	record_actions(ActMergeList).

%
%remove_Bel_Functors(ActStructList, ActStructListOut).
%
remove_Bel_Functors([], []).

remove_Bel_Functors([actStruct(Action, EffectsIn, PrecondsIn) | TIn], [actStruct(Action, EffectsOut, PrecondsOut) | TOut]) :-
	remove_Bel_Functors(TIn, TOut),
	remove_Bel(EffectsIn, EffectsOut),
	remove_Bel(PrecondsIn, PrecondsOut).

%
%remove_Bel(BelListIn, BelListOut).
%

remove_Bel([],[]).
remove_Bel([bel(_, P) | TIn],[P | TOut]) :- remove_Bel(TIn, TOut).
remove_Bel([P | TIn],[P | TOut]) :- remove_Bel(TIn, TOut).

remove_Bel(bel(_, P), P).
remove_Bel(P, P).

merge_actions_list([], []).
merge_actions_list([ActStruct|TActStruct], [ActMerge|TActMerge]) :-
	unify_action(ActStruct, TActStruct, ActMerge, NewActStructList),
	merge_actions_list(NewActStructList, TActMerge).

/**********************
* unify_action(actStruct(ActStruct, Eff, PreCond), ActStructList,
*		 actMerge(ActMerge, EffList, PreCond), NewActStructList)
***********************/
unify_action(actStruct(ActStruct, Eff, PreCond), [],
		 actMerge(ActStruct, [Eff], PreCond), []).
unify_action(actStruct(ActStruct, Eff1, PreCond), [actStruct(ActStruct, Eff2, _)|ActStructList],
		 actMerge(ActStruct, [Eff2|EffList], PreCondRes), NewActStructList) :-
	unify_action(actStruct(ActStruct, Eff1, PreCond), ActStructList, 
			 actMerge(ActStruct, EffList, PreCondRes), NewActStructList).
unify_action(actStruct(ActStruct, Eff1, PreCond), [Action|ActStructList],
		 actMerge(ActStruct, EffList, PreCondRes), [Action|NewActStructList]) :-
	unify_action(actStruct(ActStruct, Eff1, PreCond), ActStructList, 
			 actMerge(ActStruct, EffList, PreCondRes), NewActStructList).
 
record_actions([]) :- !.
record_actions([actMerge(Action, EffList, PreCond)|TActionList]) :- !,
	get_int_that_leaf(PreCond, PreCondList),
	record_action_to_file(Action, EffList, PreCondList),
	record_actions(TActionList).

record_action_to_file(HAction, EffList, []) :- !,
	write('operator '), 
	write(HAction), nl,
	write('effects('),
	write_list(EffList),
	write(')'), nl.
record_action_to_file(HAction, EffList, PreCondList) :- !,
	write('operator '), 
	write(HAction), nl,
	write('preconds('),
	write_list(PreCondList),
	write(')'), nl,
	write('effects('),
	write_list(EffList),
	write(')'), nl.

%Commented out by Felipe
%write_list([]).
%write_list([Obj|[]]) :- !,
%	write(Obj).
%write_list([HObj|TObj]) :- !,
%	write(HObj), 
%	write(','), 
%	write_list(TObj).

%Added by Felipe, removes the bel() functor from actions
write_list([]).
write_list([Obj|[]]) :- !,
	write_obj(Obj).
write_list([HObj|TObj]) :- !,
	write_obj(HObj), 
	write(','), 
	write_list(TObj).
write_obj(bel(_,P)) :-
	write(P).
write_obj(Obj):-
	write(Obj).
