:- op(1111,xfy,causes).
:- op(1111,xfy,if).
:- op(1111,xfy,after).
:- op(1111,fy,  <=).
:- op(1111,xfy, <=).
:- dynamic initial_number/1.

parse(NomeArq) :- 	nl, write('==> Kernel: Parsing BDI File ...'),
				nl,nl,
				open(NomeArq, read, Handler),
				read_aclauses([Handler]).

read_aclauses([]) :- !.
read_aclauses([Handler|ResHandler]) :-
		read(Handler, ATerm),
		process_aterm(ATerm,[Handler|ResHandler],NewHandlerLis),!,
		read_aclauses(NewHandlerLis).

process_aterm(end_of_file, [Handler|ResHandler], ResHandler) :- !,
		close(Handler).

process_aterm((<= P), HLis, HLis) :- !,
		process_aterm((false <= P), HLis, HLis).
process_aterm((false <= P), HLis, HLis) :- !, 
		mount_PTerm(P, T, PTerm), 	/* term with all holds_at for all P's */
		assert(inconsis_rule((<- PTerm))),
		call_process_term((false <- PTerm)).
process_aterm((A causes F if P) , HLis, HLis) :- !,
		mount_PTerm(P,T,PTerm),		/* term with all holds_at for all P's */
/*****		mount_Ena(A,PTerm,T,EnaTerm),
		call_process_term(EnaTerm), *****/
		mount_IniTer(A,F,PTerm,T,IniTerTerm),
		call_process_term(IniTerTerm).
process_aterm((A causes F), HLis, HLis) :- !,
/*****		mount_Ena(A, true, T, EnaTerm),
		call_process_term(EnaTerm),******/
		mount_IniTer(A,F,true,T,IniTerTerm),
		call_process_term(IniTerTerm).
process_aterm((F if P) , HLis, HLis) :- !,
		mount_PTerm(P,T,PTerm),		/* term with all holds_at for all P's */
		mount_Hol(A,F,PTerm,T,HolTerm),
		call_process_term(HolTerm).
process_aterm(-(bel(Ag, -(F))), HLis, HLis) :- !,
		call_process_term(initially(bel(Ag, F))).
process_aterm(-(bel(Ag, F)), HLis, HLis) :- !,
		call_process_term(-initially(bel(Ag, F))).
process_aterm(bel(Ag, -(F)), HLis, HLis) :- !,
		call_process_term(-initially(bel(Ag, F))).
process_aterm(bel(Ag, F), HLis, HLis) :- !,
		call_process_term(initially(bel(Ag, F))).




process_aterm(F, HLis, HLis) :- !,
		numerate_desire(F, FPrime),
		call_process_term(initially(FPrime)).

mount_PTerm((P,Q),T,(PTerm,QTerm)) :- 
		mount_PTerm(P,T,PTerm),
		mount_PTerm(Q,T,QTerm).
mount_PTerm((A is B),T,prolog(A is B)) :- !.
mount_PTerm((A < B),T,prolog(A < B)) :- !.
mount_PTerm((A > B),T,prolog(A > B)) :- !.
mount_PTerm((A =< B),T,prolog(A =< B)) :- !.
mount_PTerm((A >= B),T,prolog(A >= B)) :- !.
mount_PTerm((A \= B),T,prolog(A \= B)) :- !.
mount_PTerm((A == B),T,prolog(A == B)) :- !.
mount_PTerm(before(P),T,Holds) :- !,
		numerate_desire(P,PPrime),
		mount_PTerm(PPrime, T_Ant, PPrimeHold), 
		Holds = (PPrimeHold,
			   myless(T_Ant, T)).
mount_PTerm(next(P), T, Holds) :- !,
		numerate_desire(P,PPrime),
		mount_PTerm(PPrime, T_Nxt, PPrimeHold), 
		Holds = (T_Nxt is T + 1,
			   PPrimeHold).
mount_PTerm(-(bel(Ag, -(P))), T, holds_at(bel(Ag, P),T)) :-	!.
mount_PTerm(-(bel(Ag, P)), T, (not holds_at(bel(Ag, P),T))) :-	!.
mount_PTerm(bel(Ag, -(P)), T, (not holds_at(bel(Ag, P),T))) :-	!.
mount_PTerm(bel(Ag, P), T, holds_at(bel(Ag, P),T)) :-	!.
mount_PTerm(-(P), T, (not holds_at(PPrime,T))) :-
		numerate_desire(P,PPrime),
		!.
mount_PTerm(P,T,(holds_at(PPrime,T))) :- 
		numerate_desire(P,PPrime),
		!.

mount_Ena(A,PTerm,T,EnaTerm) :-
		EnaTerm = (enabled(TEvt, A) <-
					act(TEvt, A),
					PTerm).

mount_Hol(A,(-bel(Ag, -(F))),PTerm,T,HolTerm):-
		HolTerm = (holds_at(bel(Ag, F), T) <- PTerm).
mount_Hol(A,(-bel(Ag, F)),PTerm,T,HolTerm):-
		HolTerm = (-(holds_at(bel(Ag, F), T)) <- PTerm).
mount_Hol(A,bel(Ag, -(F)),PTerm,T,HolTerm):-
		HolTerm = (-(holds_at(bel(Ag, F), T)) <- PTerm).
mount_Hol(A,bel(Ag, F),PTerm,T,HolTerm):-
		HolTerm = (holds_at(bel(Ag, F), T) <- PTerm).
mount_Hol(A,F,PTerm,T,HolTerm) :-
		numerate_desire(F,FPrime),
		set_unsel_to_desires(FPrime, PTerm, PPrimeTerm),
		HolTerm = (holds_at(FPrime,T) <-
					PPrimeTerm).

mount_IniTer(_,nothing,_,_,nothing):-	!.
mount_IniTer(A,F,PTerm,TEvt,IniTerTerm) :- !,
		numerate_desire(F,FPrime),
		ini_or_ter(FPrime, TEvt, A, IT),
		IniTerTerm = (IT <- act(TEvt,A), PTerm).

ini_or_ter(-(bel(Ag, -(F))), TEvt, A, initiates(TEvt, A, bel(Ag, F))):- !.
ini_or_ter(-(bel(Ag, F)), TEvt, A, terminates(TEvt, A, bel(Ag, F))):- !.
ini_or_ter(bel(Ag, -(F)), TEvt, A, terminates(TEvt, A, bel(Ag, F))):- !.
ini_or_ter(bel(Ag, F), TEvt, A, initiates(TEvt, A, bel(Ag, F))):- !.
ini_or_ter(-(F), TEvt, A, terminates(TEvt, A, F)):- !.
ini_or_ter(F, TEvt, A, initiates(TEvt, A, F)):- !.
		
numerate_desire(des(Ag, P, T, Atr), des(Nro, Ag, P, Td, Atr)) :-
				next_number(Nro),
				set_desire_time(T, Td).
numerate_desire(X,X).

initial_number(0).
next_number(Nro) :- 
			retract(initial_number(NroOld)),
			Nro is NroOld + 1,
			assert(initial_number(Nro)).

set_desire_time(T,t_inf) :-	var(T).
set_desire_time(T,T).

call_process_term(nothing) :- !.
/******
*** Retirada quando utilizando vers�o 
***  v2.4 alterada pelo PQ
***
***   call_process_term(Term) :- process_term(Term,[0],_).
***
********/
call_process_term(Term) :- 	!, 
					process_term(Term, _).
/********
* Coloca unsel no final de cada desejo
*    - para ser usado ap�s ter selecionado
*      os Eligible Desires, na defini��o dos
*      Candidate Desires
*********/
set_unsel_to_desires(des(Nro, _, _, _, _), PTerm, (PTerm, (not unsel(Nro)))).
set_unsel_to_desires(FTerm, PTerm, PTerm).	
