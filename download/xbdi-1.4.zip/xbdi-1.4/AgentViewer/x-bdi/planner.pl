foreign_resource(planner,[plan_c]).

%foreign(plan, plan(+string, +string)).
foreign(plan_c, plan_c(+string, +string, +string, +string, +string)).

:-load_foreign_resource(planner).
:- dynamic c_planner/1.
:- dynamic c_stats/1.
:- dynamic c_grounds/1.
:- write('Embedded Planner module loaded.'),nl,nl.

plan(Input,Output) :- !, plan_c(Input,Output, '', '', '').

plan(Input, Output, Options) :- processOptions(Options),
			c_planner(Planner),
			c_stats(Stats),
			c_grounds(Grounds),!,
			plan_c(Input, Output, Planner, Stats, Grounds).

/***********************************************************************
 *
 * Here we process the options that can be given to the algorithm
 *
 ***********************************************************************/

processOptions([]).

processOptions([Option | OptionTail]) :-
	processOption(Option),
	processOptions(OptionTail).

processOption((planner, graphplan)) :- retractall(c_planner(_)),
			assert(c_planner(graphplan)).

processOption((planner, pop)) :- retractall(c_planner(_)),
			assert(c_planner(pop)).

processOption((stats, File)) :- retractall(c_stats(_)),
			assert(c_stats(File)).

processOption((grounds, File)) :- retractall(c_grounds(_)),
			assert(c_grounds(File)).

processOption(_).

% The default options go here

c_planner('').
c_stats('').
c_grounds('').

/***********************************************************************/