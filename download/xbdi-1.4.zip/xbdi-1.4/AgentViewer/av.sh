#!/bin/bash
CLASSPATH=C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/lib/jasper.jar
CLASSPATH=$CLASSPATH:C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/lib/yl.jar
CLASSPATH=$CLASSPATH:C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/lib/jlfgr-1_0.jar
CLASSPATH=$CLASSPATH:C:\Documents and Settings\dfcfacin\MyDoc\x-bdi-v1.2\AgentViewer/bin/agentviewer.jar
PATH=$PATH:$SICSTUS_PATH:.
echo $CLASSPATH
java -cp $CLASSPATH -Djava.library.path="$SICSTUS_PATH/bin" -Dsicstus.path="$SICSTUS_PATH" agentviewer.app.Starter &
