b(a).
b(c).
b(d).
b(e).
b(f).
