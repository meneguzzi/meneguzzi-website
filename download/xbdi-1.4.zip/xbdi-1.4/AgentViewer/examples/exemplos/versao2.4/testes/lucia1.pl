%%-holds_at(Prop,T) :-	not(holds_at(Prop,T)).
holds_at(Prop,T)  :-  	initially(Prop),
			persists(0,Prop,T).

holds_at(Prop,T)  :-  	happens(Evt,TEvt),
 			initiates(Evt,Prop), 
			TEvt < T,
			persists(TEvt,Prop,T). 

persists(TEvt,Prop,T)  :- 	 \+ clipped(TEvt,Prop,T).

clipped(TEvt,Prop,T)  :-  happens(IntEvt,TIntEvt),
			 	\+ out(TIntEvt,TEvt,T),
 		 		terminates(IntEvt,Prop).
 
out(TIntEvt,TEvt,T) :-  T =< TIntEvt.
out(TIntEvt,TEvt,T) :-  TIntEvt < TEvt. 

initially(bel(a,pode_aj(eco))).
initially(bel(a,pode_co(pol))).
initially(bel(a,coop(t))).
initially(-bel(a,escol(a,fer))).
initially(bel(a,poluter(dredge))).
initially(bel(a,poluter(rainwater))).
initially(bel(a,poluter(industrial))).
initially(bel(a,poluter(domestic))).
initially(bel(a,tools(nature,accdecomp))).
initially(bel(a,tools(nature,addmoreplants))).
initially(bel(a,tools(nature,changebottom))).
initially(bel(a,tools(nature,increaselight))).
initially(bel(a,tools(mayor,phohibition))).
initially(bel(a,tools(mayor,dustbins))).
initially(bel(a,tools(mayor,closefactor))).
initially(bel(a,tools(mayor,ordertreat))).
initially(bel(a,charact(a,nature))).
initially(bel(a,energy(fish,100))).
initially(bel(a,energy(water,100))).
initially(bel(a,energy(plants,100))).
initially(bel(a,energy(micro,100))).
initially(bel(a,energy(bottom,100))).

initially(bel(b,pode_aj(eco))).
initially(bel(b,pode_co(pol))).
initially(bel(b,coop(t))).
initially(bel(b,escol(b,fer))).
initially(bel(b,poluter(dredge))).
initially(bel(b,poluter(rainwater))).
initially(bel(b,poluter(industrial))).
initially(bel(b,poluter(domestic))).
initially(bel(b,tools(nature,accdecomp))).
initially(bel(b,tools(nature,addmoreplants))).
initially(bel(b,tools(nature,changebottom))).
initially(bel(b,tools(nature,increaselight))).
initially(bel(b,tools(mayor,phohibition))).
initially(bel(b,tools(mayor,dustbins))).
initially(bel(b,tools(mayor,closefactor))).
initially(bel(b,tools(mayor,ordertreat))).
initially(bel(b,charact(b,mayor))).
initially(bel(b,energy(fish,100))).
initially(bel(b,energy(water,100))).
initially(bel(b,energy(plants,100))).
initially(bel(b,energy(micro,100))).
initially(bel(b,energy(bottom,100))).

initially(bel(t,segue(a,t))).
initially(bel(t,segue(b,t))).
initially(bel(t,escol(a,fer))).
initially(bel(t,escol(b,fer))).
initially(bel(t,poluter(dredge))).
initially(bel(t,poluter(rainwater))).
initially(bel(t,poluter(industrial))).
initially(bel(t,poluter(domestic))).
initially(bel(t,charact(a,nature))).
initially(bel(t,charact(b,mayor))).
initially(bel(t,tools(nature,accdecomp))).
initially(bel(t,tools(nature,addmoreplants))).
initially(bel(t,tools(nature,changebottom))).
initially(bel(t,tools(nature,increaselight))).
initially(bel(t,tools(mayor,phohibition))).
initially(bel(t,tools(mayor,dustbins))).
initially(bel(t,tools(mayor,closefactor))).
initially(bel(t,tools(mayor,ordertreat))).
initially(bel(t,energy(fish,100))).
initially(bel(t,energy(water,100))).
initially(bel(t,energy(plants,100))).
initially(bel(t,energy(micro,100))).
initially(bel(t,energy(bottom,100))).

agent(a).
agent(b).
agent(t).

%%%%%%%%%%%%%%%%%%%%%%%%%
%%Ini/Ter expect. that A performs increaselight
%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,exp(t,do(A,increaselight))) :- act(E,dredge),
								happens(E,T),
								agent(A),
								holds_at(bel(A,charact(nature)),T).
terminates(E,exp(A,do(A,increaselight))) :- act(E,A),
								happens(E,T),
								agent(A),
								holds_at(exp(A,do(a,increaselight)),T).

%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that t bel bottom energy decreases with dredge
%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(t,energy(bottom,Y))) :- act(E,dredge),
							happens(E,T),
							Tant is T - 1,
							holds_at(bel(t,energy(bottom,X)),Tant),
							Y is (X * 0.9).
terminates(E,bel(t,energy(bottom,Y))) :- act(E,dredge),
							happens(E,T).
%%							holds_at(bel(t,energy(bottom,Y)),T).
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that t bel fish energy decreases with dredge
%%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(t,energy(fish,Y))) :- act(E,dredge),
							happens(E,T),
							Tant is T -1,
							holds_at(bel(t,energy(fish,X)),Tant),
							Y is (X * 0.95).
terminates(E,bel(t,energy(fish,Y))) :- act(E,dredge),
							happens(E,T).
%%							holds_at(bel(t,energy(fish,Y)),T).
%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that A bel bottom energy decreases with dredge
%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(A,energy(bottom,Y))) :- act(E,dredge),
							happens(E,T),
							agent(A),
							Tant is T - 1,
							holds_at(bel(A,energy(bottom,X)),Tant),
							Y is (X * 0.9).
terminates(E,bel(A,energy(bottom,Y))) :- act(E,dredge),
							happens(E,T).
%%							holds_at(bel(A,energy(bottom,Y)),T).
%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that A bel fish energy decreases with dredge
%%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(A,energy(fish,Y))) :- act(E,dredge),
							happens(E,T),
							agent(A),
							Tant is T -1,
							holds_at(bel(A,energy(fish,X)),Tant),
							Y is (X * 0.95).
terminates(E,bel(A,energy(fish,Y))) :- act(E,dredge),
							happens(E,T).
%%							holds_at(bel(A,energy(fish,Y)),T).

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that A bel bottom energy increases with increaselight
%%%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(A,energy(bottom,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A),
							Tant is T - 1,
							holds_at(bel(A,energy(bottom,X)),Tant),
							Y is (X * 1.2).
terminates(E,bel(A,energy(bottom,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A).
%%							holds_at(bel(A,energy(bottom,Y)),T).
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that t bel bottom energy increases with increaselight
%%%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(t,energy(bottom,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A),
							Tant is T - 1,
							holds_at(bel(t,energy(bottom,X)),Tant),
							Y is (X * 1.2).
terminates(E,bel(t,energy(bottom,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A).
%%							holds_at(bel(t,energy(bottom,Y)),T).
%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ini/Ter that t bel fish energy increases with increaselight
%%%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(t,energy(fish,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A),
							Tant is T-1,
							holds_at(bel(t,energy(fish,X)),Tant),
							Y is (X * 1.2).
terminates(E,bel(t,energy(fish,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A).
%%							holds_at(bel(t,energy(fish,Y)),T).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Ini/Ter that A bel fish energy increases with increaselight
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initiates(E,bel(A,energy(fish,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A),
							Tant is T - 1,
							holds_at(bel(A,energy(fish,X)),Tant),
							Y is (X * 1.2).

terminates(E,bel(A,energy(fish,Y))) :- act(E,increaselight),
							happens(E,T,A),
							agent(A).
%%							holds_at(bel(A,energy(fish,Y)),T).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

happens(e1,2).
act(e1,dredge).
