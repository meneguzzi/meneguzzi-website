/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.app;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import agentviewer.parser.Parser;
import agentviewer.parser.xbdi.XBDIAgent;
import agentviewer.parser.xbdi.XBDIStripsFactory;
import agentviewer.parser.xbdi.visitor.XBDIAgentWriter;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Converter
{

	public static void main(String[] args)
	{
		String sFileIn = "agent.txt";
		String sFileOut = "agent.bdi";
		String sIdentity;

		if (args.length > 0)
		{
			sFileIn = args[0];
		}

		int index = sFileIn.lastIndexOf('.');
		if (index > 0)
			sIdentity = sFileIn.substring(0, index);
		else
			sIdentity = sFileIn;

		if (args.length > 1)
		{
			sFileOut = args[1];
		} else
		{
			sFileOut = sIdentity + ".bdi";
		}

		Parser p = new Parser();

		try
		{
			boolean bParse = p.parse(new File(sFileIn));
			if (bParse)
			{
				XBDIStripsFactory xFactory = new XBDIStripsFactory();
				XBDIAgent xAgent=xFactory.createAgent(sIdentity, p.getStart(), p.getGoal(), p.getOperators());
				XBDIAgentWriter xWriter=new XBDIAgentWriter(sFileOut);
				xWriter.processAgent(xAgent);
			}
		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
