package agentviewer.app;
import java.io.IOException;

import se.sics.jasper.SPException;
import agentviewer.ui.AgentViewerMainWindow;

/*
 * Created on 29/04/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */

/**
 * @author felipe
 */
public class Starter
{

	/**
	 * 
	 */
	public Starter()
	{
		super();
	}

	public static void main(String[] args)
	{
		try
		{
			//SICStus sp=new SICStus();
			
			AgentViewerMainWindow main=new AgentViewerMainWindow();
			
			System.out.println("Interface Started");
/*			JapserXBDIStarter agentviewer.xbdi = new JapserXBDIStarter();
					
			XBDIDummyServer server = new XBDIDummyServer(50000);
			
			XBDISocket client = new XBDISocket("localhost", 50000);
			
			String sCommand="bel(agent, test)";
			
			System.out.println("Sending command: "+sCommand);
			client.sendSensorInput(new String[]{sCommand}, 2, 3);
			
			String sRes=client.getActuatorOutput();
			
			System.out.println("Received: "+sRes);
			
			agentviewer.xbdi.agentviewer.xbdi("bdi.a", "coreografia.a"); */
			
		} catch (IOException e)
		{
			e.printStackTrace();
		} catch (SPException e)
		{
			e.printStackTrace();
		} catch(Exception e)
		{
			e.printStackTrace();
		}

	}
}
