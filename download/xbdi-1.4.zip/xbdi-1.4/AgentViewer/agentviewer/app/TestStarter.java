package agentviewer.app;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Vector;

import agentviewer.parser.Parser;
import agentviewer.parser.elements.Action;
import agentviewer.parser.elements.ConcretePredicate;
import agentviewer.parser.elements.ConcreteTerm;
import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;
import agentviewer.parser.elements.VariableTerm;
import agentviewer.parser.elements.factory.ActionFactory;
import agentviewer.parser.elements.factory.ConcreteActionFactory;
import agentviewer.sicstus.SICStusRuntime;

/*
 * Created on 31/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class TestStarter
{
	public boolean testSICStus()
	{
		try
		{
			//SICStusRuntime sr=new SICStusRuntime();
			//SICStusRuntime sr=new SICStusRuntime("kernel_boot", System.getProperty("user.dir"));
			SICStusRuntime sr = new SICStusRuntime("kernel_boot");

			String sCommand = "";

			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			do
			{
				sCommand = br.readLine();
				if (sCommand.equals("halt."))
					sr.halt();
				else
					sr.executeQuery(sCommand);
			} while (!sCommand.equals("halt."));

		} catch (IOException e)
		{
			e.printStackTrace();
			return false;
		} catch (InterruptedException e)
		{
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean testParserFile(String sFile)
	{
		Parser parser = new Parser();
		boolean bRes = false;
		try
		{
			bRes = parser.parse(new File(sFile));
			Vector vStart = parser.getStart();
			Vector vGoal = parser.getGoal();
			Vector vOperators = parser.getOperators();

			for (Iterator i = vStart.iterator(); i.hasNext();)
			{
				Predicate p = (Predicate)i.next();
				System.out.println(p);
			}

			for (Iterator i = vGoal.iterator(); i.hasNext();)
			{
				Predicate p = (Predicate)i.next();
				System.out.println(p);
			}

			for (Iterator i = vOperators.iterator(); i.hasNext();)
			{
				Operator o = (Operator)i.next();
				if (o.getArity() > 0)
				{
					Vector v = o.getTerms();
					VariableTerm vt = (VariableTerm)v.elementAt(0);
					vt.bind((Term)vStart.get(0));
				}
				System.out.println(o);
			}

		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}

		System.out.println(parser);

		return bRes;
	}

	public boolean testActionFactory(String sFile)
	{
		Parser parser = new Parser();
		ActionFactory aFactory=new ConcreteActionFactory();
		boolean bRes = false;
		try
		{
			bRes = parser.parse(new File(sFile));
			Vector vOperators = parser.getOperators();

			for (Iterator i = vOperators.iterator(); i.hasNext();)
			{
				Operator o = (Operator)i.next();
				System.out.println("Operator = "+o);
				
				Vector vParams=new Vector(o.getArity());
				for(int iParam=0; iParam<o.getArity(); iParam++)
				{
					Term t=new ConcreteTerm("a"+iParam);
					//vParams.setElementAt(t, iParam);
					vParams.add(iParam, t);
				}
				
				Predicate pAction=new ConcretePredicate(o.getName(),vParams);
				Action action=aFactory.createAction(pAction, o);
				System.out.println("Action = "+action);
			}

		} catch (FileNotFoundException e)
		{
			e.printStackTrace();
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return bRes;
	}

	public boolean testParserStream(String s)
	{
		Parser parser = new Parser();
		boolean bRes = false;

		ByteArrayInputStream is = new ByteArrayInputStream(s.getBytes());
		bRes = parser.parsePredicates(is);

		Vector v = parser.getPredicates();

		for (Iterator i = v.iterator(); i.hasNext();)
		{
			Predicate p = (Predicate)i.next();
			System.out.println(p);
		}
		return bRes;
	}

	public static void main(String[] args)
	{
		TestStarter ts = new TestStarter();
		//ts.testSICStus();
		//ts.testParserFile(args[0]);
		//ts.testParserStream("int_that(1,teste,ord(pacote),t_inf,[0.5]),\n int_to(teste,act(teste,pensa),t27), \n int_to(teste,act(teste,envia(pacote)),t28)");
		ts.testActionFactory(args[0]);
	}
}
