/*
 * Created on 19/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Vector;

import agentviewer.parser.elements.factory.ElementFactory;
import agentviewer.parser.elements.factory.ScopedElementFactory;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Parser
{	
	AgentViewerLexer lexer=null;
	AgentViewerParser parser=null;
	ElementFactory eFactory=null;
	
	public Parser()
	{
		eFactory=new ScopedElementFactory();
	}
	
	public boolean parse(File f) throws FileNotFoundException
	{
		return this.parse(new FileInputStream(f), AgentViewerParser.STRIPS_MODE);
	}
	
	public boolean parsePredicates(String s)
	{
		return this.parsePredicates(new ByteArrayInputStream(s.getBytes()));
	}
	
	public boolean parsePredicates(InputStream is)
	{
		return this.parse(is, AgentViewerParser.PREDICATE_MODE);
	}
	
	public boolean parseTerms(String s)
	{
		return this.parseTerms(new ByteArrayInputStream(s.getBytes()));
	}
	
	public boolean parseTerms(InputStream is)
	{
		return this.parse(is, AgentViewerParser.TERM_MODE);
	}
	
	public boolean parse(InputStream is, int iMode)
	{
		int n = 1;
		lexer = new AgentViewerLexer();
		parser = new AgentViewerParser();
		
		//lexer.setDebug(true);
		//parser.setDebug(true);
		
		lexer.yyin=new InputStreamReader(is);
		parser.setFactory(eFactory);
		parser.setMode(iMode);
		
		if (parser.yycreate(lexer))
		{
			if (lexer.yycreate(parser))
			{
				n = parser.yyparse();
			}
		}
		
		if(n==AgentViewerParser.YYEXIT_SUCCESS)
			return true;
		else
			return false;
	}
	
	public Vector getStart()
	{
		if(parser!=null)
			return parser.getStart();
		else
			return null;
	}

	public Vector getGoal()
	{
		if(parser!=null)
			return parser.getGoal();
		else
			return null;
	}

	public Vector getOperators()
	{
		if(parser!=null)
			return parser.getOperators();
		else
			return null;
	}

	public Vector getPredicates()
	{
		if(parser!=null)
			return parser.getPredicates();
		else
			return null;
	}

	public Vector getTerms()
	{
		if(parser!=null)
			return parser.getTerms();
		else
			return null;
	}
	
	public String toString()
	{
		return "Parser\n"+this.eFactory.toString();
	}
}
