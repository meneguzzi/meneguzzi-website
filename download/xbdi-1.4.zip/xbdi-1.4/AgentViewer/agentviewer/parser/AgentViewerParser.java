/****************************************************************************
*                         A C A D E M I C   C O P Y
* 
* This file was produced by an ACADEMIC COPY of Parser Generator. It is for
* use in non-commercial software only. An ACADEMIC COPY of Parser Generator
* can only be used by a student, or a member of an academic community. If
* however you want to use Parser Generator for commercial purposes then you
* will need to purchase a license. For more information see the online help or
* go to the Bumble-Bee Software homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* AgentViewerParser.java
* Java source file generated from AgentViewerParser.y.
* 
* Date: 09/28/03
* Time: 22:24:03
* 
* AYACC Version: 2.05
****************************************************************************/

// line 1 ".\\AgentViewerParser.y"

/****************************************************************************
AgentViewerParser.y
ParserWizard generated YACC file.

Date: sexta-feira, 19 de setembro de 2003
****************************************************************************/
package agentviewer.parser;

import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;
import java.util.Vector;
import agentviewer.parser.elements.factory.ElementFactory;

// line 43 "AgentViewerParser.java"
import yl.*;

/////////////////////////////////////////////////////////////////////////////
// AgentViewerParser

public class AgentViewerParser extends yyfparser {
// line 24 ".\\AgentViewerParser.y"

	// place any extra class members here
	
	/** Constant for STRIPS mode*/
	public static final int STRIPS_MODE=0;
	/** Constant for Predicate mode*/
	public static final int PREDICATE_MODE=1;
	/** Constant for Term mode*/
	public static final int TERM_MODE=2;
	
	private boolean bDebug=false;
	protected Vector vOperators;
	protected Vector vPredicates;
	protected Vector vTerms;
	
	protected Vector vStart;
	protected Vector vGoal;
	
	private int iMode=STRIPS_MODE;
	
	private ElementFactory eFactory;

// line 73 "AgentViewerParser.java"
	public AgentViewerParser() {
		yytables();
// line 48 ".\\AgentViewerParser.y"

		// place any extra initialisation code here

// line 80 "AgentViewerParser.java"
	}

	public class YYSTYPE extends yyattribute {
// line 53 ".\\AgentViewerParser.y"

		public int iFlag;
		public boolean bFlag;
		public String symbol;
		public Vector vector;
		public Predicate predicate;
		public Term term;
		public Operator oper;

		public void yycopy(yyattribute source, boolean move) {
			YYSTYPE yy = (YYSTYPE)source;
			this.iFlag = yy.iFlag;
			this.bFlag = yy.bFlag;
			this.symbol = yy.symbol;
			this.vector = yy.vector;
			this.predicate = yy.predicate;
			this.term = yy.term;
			this.oper = yy.oper;
		}

// line 105 "AgentViewerParser.java"
	}

	public static final int OPERATOR = 65537;
	public static final int PRECONDS = 65538;
	public static final int EFFECTS = 65539;
	public static final int START = 65540;
	public static final int GOAL = 65541;
	public static final int STRING = 65542;
	public static final int NUMBER = 65543;
	public static final int IDENTIFIER = 65544;
	public static final int NOT = 65545;
	protected final YYSTYPE yyattribute(int index) {
		YYSTYPE attribute = (YYSTYPE)yyattributestackref[yytop + index];
		return attribute;
	}

	protected final yyattribute yynewattribute() {
		return new YYSTYPE();
	}

	protected final YYSTYPE[] yyinitdebug(int count) {
		YYSTYPE a[] = new YYSTYPE[count];
		for (int i = 0; i < count; i++) {
			a[i] = (YYSTYPE)yyattributestackref[yytop + i - (count - 1)];
		}
		return a;
	}

	protected static yyftables yytables = null;

	public final void yyaction(int action) {
		switch (action) {
		case 0:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 103 ".\\AgentViewerParser.y"
REDUCE("Grammar 1");
														if(this.iMode!=STRIPS_MODE)
														{
															yyerror("This is not valid STRIPS!");
															yysyntaxerror();
														}
// line 151 "AgentViewerParser.java"
			}
			break;
		case 1:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 109 ".\\AgentViewerParser.y"
REDUCE("Grammar 2");
														if(this.iMode!=PREDICATE_MODE)
														{
															yyerror("These are not valid Predicates!");
															yysyntaxerror();
														}
														vPredicates=yyattribute(1 - 1).vector;
// line 168 "AgentViewerParser.java"
			}
			break;
		case 2:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 116 ".\\AgentViewerParser.y"
REDUCE("Grammar 3");
														if(this.iMode!=TERM_MODE)
														{
															yyerror("These are not valid Terms!");
															yysyntaxerror();
														}
														vTerms=yyattribute(1 - 1).vector;
// line 185 "AgentViewerParser.java"
			}
			break;
		case 3:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 126 ".\\AgentViewerParser.y"
REDUCE("Strips 1");
// line 196 "AgentViewerParser.java"
			}
			break;
		case 4:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 127 ".\\AgentViewerParser.y"
vOperators=yyattribute(1 - 1).vector;
														REDUCE("Strips 2");
// line 208 "AgentViewerParser.java"
			}
			break;
		case 5:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 129 ".\\AgentViewerParser.y"
vOperators=yyattribute(2 - 2).vector;
														REDUCE("Strips 3");
// line 220 "AgentViewerParser.java"
			}
			break;
		case 6:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 134 ".\\AgentViewerParser.y"
REDUCE("Facts 1");
// line 231 "AgentViewerParser.java"
			}
			break;
		case 7:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 138 ".\\AgentViewerParser.y"
this.vStart=yyattribute(3 - 4).vector;
														 if(!eFactory.isFullyInstantiated(yyattribute(3 - 4).vector))
														 {
															yyerror("Start and Goal must be fully instantiated.");
															yysyntaxerror();
														 }
														 REDUCE("Start 1");
// line 248 "AgentViewerParser.java"
			}
			break;
		case 8:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 148 ".\\AgentViewerParser.y"
this.vGoal=yyattribute(3 - 4).vector;
														 if(!eFactory.isFullyInstantiated(yyattribute(3 - 4).vector))
														 {
															yyerror("Start and Goal must be fully instantiated.");
															yysyntaxerror();
														 }
														 REDUCE("Goal 1");
// line 265 "AgentViewerParser.java"
			}
			break;
		case 9:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 155 ".\\AgentViewerParser.y"
this.vGoal=new Vector();
														 REDUCE("Goal 2");
// line 277 "AgentViewerParser.java"
			}
			break;
		case 10:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 160 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=yyattribute(1 - 2).vector;
														 ((YYSTYPE)yyvalref).vector.add(yyattribute(2 - 2).oper);
														 REDUCE("Operator_List 1");
// line 290 "AgentViewerParser.java"
			}
			break;
		case 11:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 163 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=new Vector();
														 ((YYSTYPE)yyvalref).vector.add(yyattribute(1 - 1).oper);
														 REDUCE("Operator_List 2");
// line 303 "AgentViewerParser.java"
			}
			break;
		case 12:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(8);
				}
// line 171 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).oper= eFactory.createOperator(yyattribute(2 - 7).symbol, yyattribute(4 - 7).vector, yyattribute(6 - 7).vector, yyattribute(7 - 7).vector);
														 if(!eFactory.checkOperator(((YYSTYPE)yyvalref).oper))
														 {
															yyerror("Variables in operator "+yyattribute(2 - 7).symbol+" do not match");
															yysyntaxerror();
														 }
														 REDUCE("Operator 1");
// line 320 "AgentViewerParser.java"
			}
			break;
		case 13:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 180 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).oper= eFactory.createOperator(yyattribute(2 - 4).symbol, null, yyattribute(3 - 4).vector, yyattribute(4 - 4).vector);
														 if(!eFactory.checkOperator(((YYSTYPE)yyvalref).oper))
														 {
															yyerror("Variables in operator "+yyattribute(2 - 4).symbol+" do not match");
															yysyntaxerror();
														 }
														 REDUCE("Operator 2");
// line 337 "AgentViewerParser.java"
			}
			break;
		case 14:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 190 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=yyattribute(3 - 4).vector;
														REDUCE("Preconditions 1");
// line 349 "AgentViewerParser.java"
			}
			break;
		case 15:
			{
// line 192 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=null;
														REDUCE("Preconditions 2");
// line 357 "AgentViewerParser.java"
			}
			break;
		case 16:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 197 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=yyattribute(3 - 4).vector;
														REDUCE("Effects 1");
// line 369 "AgentViewerParser.java"
			}
			break;
		case 17:
			{
// line 199 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=null;
														REDUCE("Effects 2");
// line 377 "AgentViewerParser.java"
			}
			break;
		case 18:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 204 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=yyattribute(1 - 3).vector;
														 ((YYSTYPE)yyvalref).vector.add(yyattribute(3 - 3).predicate);
														 REDUCE("Predicate_List 1");
// line 390 "AgentViewerParser.java"
			}
			break;
		case 19:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 207 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=new Vector();
														 ((YYSTYPE)yyvalref).vector.add(yyattribute(1 - 1).predicate);
														 REDUCE("Predicate_List 2");
// line 403 "AgentViewerParser.java"
			}
			break;
		case 20:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 213 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).predicate=eFactory.createPredicate(yyattribute(1 - 4).symbol, yyattribute(3 - 4).vector, true);
														 REDUCE("Predicate 1");
// line 415 "AgentViewerParser.java"
			}
			break;
		case 21:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 215 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).predicate=eFactory.createPredicate(yyattribute(1 - 1).symbol, null, true);
														 REDUCE("Predicate 2");
// line 427 "AgentViewerParser.java"
			}
			break;
		case 22:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(6);
				}
// line 217 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).predicate=eFactory.createPredicate(yyattribute(2 - 5).symbol, yyattribute(4 - 5).vector, false);
														 REDUCE("Predicate 3");
// line 439 "AgentViewerParser.java"
			}
			break;
		case 23:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 219 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).predicate=eFactory.createPredicate(yyattribute(2 - 2).symbol, null, false);
														 REDUCE("Predicate 4");
// line 451 "AgentViewerParser.java"
			}
			break;
		case 24:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(8);
				}
// line 221 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).predicate=eFactory.createPredicate(yyattribute(3 - 7).symbol, yyattribute(5 - 7).vector, false);
														 REDUCE("Predicate 3");
// line 463 "AgentViewerParser.java"
			}
			break;
		case 25:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 223 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).predicate=eFactory.createPredicate(yyattribute(3 - 4).symbol, null, false);
														 REDUCE("Predicate 4");
// line 475 "AgentViewerParser.java"
			}
			break;
		case 26:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 228 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).bFlag=true;
														 REDUCE("Not 1");
// line 487 "AgentViewerParser.java"
			}
			break;
		case 27:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 230 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).bFlag=true;
														 REDUCE("Not 2");
// line 499 "AgentViewerParser.java"
			}
			break;
		case 28:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 235 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=yyattribute(1 - 3).vector;
														 ((YYSTYPE)yyvalref).vector.add(yyattribute(3 - 3).term);
														 REDUCE("Term_List 1");
// line 512 "AgentViewerParser.java"
			}
			break;
		case 29:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 238 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=new Vector();
														 ((YYSTYPE)yyvalref).vector.add(yyattribute(1 - 1).term);
														 REDUCE("Term_List 2");
// line 525 "AgentViewerParser.java"
			}
			break;
		case 30:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 244 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).term=eFactory.createTerm(yyattribute(1 - 1).symbol, null);
														 REDUCE("Term 2");
// line 537 "AgentViewerParser.java"
			}
			break;
		case 31:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 246 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).term=eFactory.createTerm(yyattribute(1 - 1).symbol, null);
														 REDUCE("Term 3");
// line 549 "AgentViewerParser.java"
			}
			break;
		case 32:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 248 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).term=eFactory.createTerm(yyattribute(1 - 1).symbol, null);
														 REDUCE("Term 4");
// line 561 "AgentViewerParser.java"
			}
			break;
		case 33:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 250 ".\\AgentViewerParser.y"
if(this.iMode==STRIPS_MODE)
														 {
															yyerror("Function terms not allowed in STRIPS!");
															yysyntaxerror();
														 }
														 ((YYSTYPE)yyvalref).term=eFactory.createTerm(yyattribute(1 - 4).symbol, yyattribute(3 - 4).vector);
														 REDUCE("Term 5");
// line 578 "AgentViewerParser.java"
			}
			break;
		case 34:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 257 ".\\AgentViewerParser.y"
if(this.iMode==STRIPS_MODE)
														 {
															yyerror("Prolog Lists not allowed in STRIPS!");
															yysyntaxerror();
														 }
														 ((YYSTYPE)yyvalref).term=eFactory.createTerm(null, yyattribute(1 - 1).vector);
														 REDUCE(" Term 6");
// line 595 "AgentViewerParser.java"
			}
			break;
		case 35:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 267 ".\\AgentViewerParser.y"
((YYSTYPE)yyvalref).vector=yyattribute(2 - 3).vector;
														 REDUCE(" Prolog List 1");
// line 607 "AgentViewerParser.java"
			}
			break;
		default:
			break;
		}
	}

	protected final void yytables() {
		yysstack_size = 100;
		yystack_max = 0;

		yycreatetables();
		yysymbol = yytables.yysymbol;
		yyrule = yytables.yyrule;
		yyreduction = yytables.yyreduction;
		yytokenaction = yytables.yytokenaction;
		yystateaction = yytables.yystateaction;
		yynontermgoto = yytables.yynontermgoto;
		yystategoto = yytables.yystategoto;
		yydestructorref = yytables.yydestructorref;
		yytokendestref = yytables.yytokendestref;
		yytokendestbaseref = yytables.yytokendestbaseref;
	}

	public static synchronized final void yycreatetables() {
		if (yytables == null) {
			yytables = new yyftables();

			if (YYDEBUG) {
				final yysymbol symbol[] = {
					new yysymbol("$end", 0),
					new yysymbol("\'(\'", 40),
					new yysymbol("\')\'", 41),
					new yysymbol("\',\'", 44),
					new yysymbol("\'-\'", 45),
					new yysymbol("\'[\'", 91),
					new yysymbol("\']\'", 93),
					new yysymbol("error", 65536),
					new yysymbol("OPERATOR", 65537),
					new yysymbol("PRECONDS", 65538),
					new yysymbol("EFFECTS", 65539),
					new yysymbol("START", 65540),
					new yysymbol("GOAL", 65541),
					new yysymbol("STRING", 65542),
					new yysymbol("NUMBER", 65543),
					new yysymbol("IDENTIFIER", 65544),
					new yysymbol("NOT", 65545),
					new yysymbol(null, 0)
				};
				yytables.yysymbol = symbol;

				final String rule[] = {
					"$accept: Grammar",
					"Grammar: StripsMode",
					"Grammar: Predicate_List",
					"Grammar: Term_List",
					"StripsMode: Facts",
					"StripsMode: Operator_List",
					"StripsMode: Facts Operator_List",
					"Facts: Start Goal",
					"Start: START \'(\' Predicate_List \')\'",
					"Goal: GOAL \'(\' Predicate_List \')\'",
					"Goal: GOAL \'(\' \')\'",
					"Operator_List: Operator_List Operator",
					"Operator_List: Operator",
					"Operator: OPERATOR IDENTIFIER \'(\' Term_List \')\' Preconditions Effects",
					"Operator: OPERATOR IDENTIFIER Preconditions Effects",
					"Preconditions: PRECONDS \'(\' Predicate_List \')\'",
					"Preconditions:",
					"Effects: EFFECTS \'(\' Predicate_List \')\'",
					"Effects:",
					"Predicate_List: Predicate_List \',\' Predicate",
					"Predicate_List: Predicate",
					"Predicate: IDENTIFIER \'(\' Term_List \')\'",
					"Predicate: IDENTIFIER",
					"Predicate: Not IDENTIFIER \'(\' Term_List \')\'",
					"Predicate: Not IDENTIFIER",
					"Predicate: Not \'(\' IDENTIFIER \'(\' Term_List \')\' \')\'",
					"Predicate: Not \'(\' IDENTIFIER \')\'",
					"Not: NOT",
					"Not: \'-\'",
					"Term_List: Term_List \',\' Term",
					"Term_List: Term",
					"Term: IDENTIFIER",
					"Term: STRING",
					"Term: NUMBER",
					"Term: IDENTIFIER \'(\' Term_List \')\'",
					"Term: Prolog_List",
					"Prolog_List: \'[\' Term_List \']\'"
				};
				yytables.yyrule = rule;
			}

			final yyreduction reduction[] = {
				new yyreduction(0, 1, -1),
				new yyreduction(1, 1, 0),
				new yyreduction(1, 1, 1),
				new yyreduction(1, 1, 2),
				new yyreduction(2, 1, 3),
				new yyreduction(2, 1, 4),
				new yyreduction(2, 2, 5),
				new yyreduction(3, 2, 6),
				new yyreduction(4, 4, 7),
				new yyreduction(5, 4, 8),
				new yyreduction(5, 3, 9),
				new yyreduction(6, 2, 10),
				new yyreduction(6, 1, 11),
				new yyreduction(7, 7, 12),
				new yyreduction(7, 4, 13),
				new yyreduction(8, 4, 14),
				new yyreduction(8, 0, 15),
				new yyreduction(9, 4, 16),
				new yyreduction(9, 0, 17),
				new yyreduction(10, 3, 18),
				new yyreduction(10, 1, 19),
				new yyreduction(11, 4, 20),
				new yyreduction(11, 1, 21),
				new yyreduction(11, 5, 22),
				new yyreduction(11, 2, 23),
				new yyreduction(11, 7, 24),
				new yyreduction(11, 4, 25),
				new yyreduction(12, 1, 26),
				new yyreduction(12, 1, 27),
				new yyreduction(13, 3, 28),
				new yyreduction(13, 1, 29),
				new yyreduction(14, 1, 30),
				new yyreduction(14, 1, 31),
				new yyreduction(14, 1, 32),
				new yyreduction(14, 4, 33),
				new yyreduction(14, 1, 34),
				new yyreduction(15, 3, 35)
			};
			yytables.yyreduction = reduction;

			final yytokenaction tokenaction[] = {
				new yytokenaction(22, YYAT_SHIFT, 30),
				new yytokenaction(76, YYAT_SHIFT, 3),
				new yytokenaction(80, YYAT_SHIFT, 39),
				new yytokenaction(80, YYAT_SHIFT, 8),
				new yytokenaction(76, YYAT_SHIFT, 4),
				new yytokenaction(79, YYAT_SHIFT, 5),
				new yytokenaction(79, YYAT_SHIFT, 6),
				new yytokenaction(79, YYAT_SHIFT, 21),
				new yytokenaction(76, YYAT_SHIFT, 7),
				new yytokenaction(76, YYAT_SHIFT, 8),
				new yytokenaction(70, YYAT_SHIFT, 74),
				new yytokenaction(66, YYAT_SHIFT, 72),
				new yytokenaction(78, YYAT_SHIFT, 37),
				new yytokenaction(70, YYAT_SHIFT, 28),
				new yytokenaction(66, YYAT_SHIFT, 30),
				new yytokenaction(45, YYAT_SHIFT, 57),
				new yytokenaction(45, YYAT_SHIFT, 58),
				new yytokenaction(77, YYAT_SHIFT, 32),
				new yytokenaction(72, YYAT_SHIFT, 75),
				new yytokenaction(68, YYAT_SHIFT, 50),
				new yytokenaction(64, YYAT_SHIFT, 71),
				new yytokenaction(63, YYAT_SHIFT, 1),
				new yytokenaction(62, YYAT_SHIFT, 69),
				new yytokenaction(61, YYAT_SHIFT, 37),
				new yytokenaction(59, YYAT_SHIFT, 67),
				new yytokenaction(57, YYAT_SHIFT, 2),
				new yytokenaction(56, YYAT_SHIFT, 65),
				new yytokenaction(50, YYAT_SHIFT, 63),
				new yytokenaction(48, YYAT_SHIFT, 61),
				new yytokenaction(47, YYAT_SHIFT, 60),
				new yytokenaction(42, YYAT_SHIFT, 55),
				new yytokenaction(41, YYAT_SHIFT, 54),
				new yytokenaction(40, YYAT_SHIFT, 53),
				new yytokenaction(39, YYAT_SHIFT, 52),
				new yytokenaction(38, YYAT_SHIFT, 50),
				new yytokenaction(37, YYAT_SHIFT, 49),
				new yytokenaction(33, YYAT_SHIFT, 3),
				new yytokenaction(32, YYAT_SHIFT, 46),
				new yytokenaction(31, YYAT_SHIFT, 45),
				new yytokenaction(26, YYAT_SHIFT, 42),
				new yytokenaction(23, YYAT_SHIFT, 36),
				new yytokenaction(21, YYAT_SHIFT, 34),
				new yytokenaction(20, YYAT_SHIFT, 3),
				new yytokenaction(18, YYAT_ACCEPT, 0),
				new yytokenaction(17, YYAT_SHIFT, 31),
				new yytokenaction(14, YYAT_SHIFT, 30),
				new yytokenaction(11, YYAT_SHIFT, 3),
				new yytokenaction(10, YYAT_SHIFT, 28),
				new yytokenaction(9, YYAT_SHIFT, 26),
				new yytokenaction(22, YYAT_SHIFT, 35),
				new yytokenaction(7, YYAT_SHIFT, 25),
				new yytokenaction(4, YYAT_SHIFT, 24),
				new yytokenaction(3, YYAT_SHIFT, 23),
				new yytokenaction(0, YYAT_SHIFT, 1)
			};
			yytables.yytokenaction = tokenaction;

			final yystateaction stateaction[] = {
				new yystateaction(8, true, YYAT_DEFAULT, 76),
				new yystateaction(0, false, YYAT_REDUCE, 28),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(-65492, true, YYAT_ERROR, 0),
				new yystateaction(11, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 32),
				new yystateaction(0, false, YYAT_REDUCE, 33),
				new yystateaction(10, true, YYAT_REDUCE, 22),
				new yystateaction(0, false, YYAT_REDUCE, 27),
				new yystateaction(-65493, true, YYAT_ERROR, 0),
				new yystateaction(3, true, YYAT_REDUCE, 2),
				new yystateaction(-65491, true, YYAT_REDUCE, 5),
				new yystateaction(0, false, YYAT_REDUCE, 20),
				new yystateaction(0, false, YYAT_REDUCE, 12),
				new yystateaction(1, true, YYAT_REDUCE, 3),
				new yystateaction(0, false, YYAT_REDUCE, 35),
				new yystateaction(0, false, YYAT_REDUCE, 30),
				new yystateaction(4, true, YYAT_DEFAULT, 77),
				new yystateaction(43, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 1),
				new yystateaction(-65495, true, YYAT_REDUCE, 4),
				new yystateaction(1, true, YYAT_REDUCE, 31),
				new yystateaction(-44, true, YYAT_ERROR, 0),
				new yystateaction(0, true, YYAT_DEFAULT, 78),
				new yystateaction(0, false, YYAT_DEFAULT, 63),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(-1, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 7),
				new yystateaction(0, false, YYAT_DEFAULT, 63),
				new yystateaction(0, false, YYAT_REDUCE, 11),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(-65506, true, YYAT_ERROR, 0),
				new yystateaction(-3, true, YYAT_REDUCE, 24),
				new yystateaction(-65501, true, YYAT_REDUCE, 6),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(0, false, YYAT_REDUCE, 36),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(-5, true, YYAT_ERROR, 0),
				new yystateaction(-65505, true, YYAT_REDUCE, 18),
				new yystateaction(-7, true, YYAT_REDUCE, 22),
				new yystateaction(-9, true, YYAT_DEFAULT, 70),
				new yystateaction(-10, true, YYAT_DEFAULT, 66),
				new yystateaction(-11, true, YYAT_DEFAULT, 63),
				new yystateaction(0, false, YYAT_REDUCE, 19),
				new yystateaction(0, false, YYAT_REDUCE, 29),
				new yystateaction(-25, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(-12, true, YYAT_DEFAULT, 66),
				new yystateaction(-13, true, YYAT_DEFAULT, 66),
				new yystateaction(0, false, YYAT_DEFAULT, 63),
				new yystateaction(-13, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 14),
				new yystateaction(0, false, YYAT_DEFAULT, 57),
				new yystateaction(0, false, YYAT_REDUCE, 8),
				new yystateaction(0, false, YYAT_REDUCE, 21),
				new yystateaction(0, false, YYAT_REDUCE, 10),
				new yystateaction(-15, true, YYAT_DEFAULT, 70),
				new yystateaction(-66, true, YYAT_DEFAULT, 79),
				new yystateaction(0, false, YYAT_REDUCE, 26),
				new yystateaction(-17, true, YYAT_DEFAULT, 66),
				new yystateaction(0, false, YYAT_REDUCE, 34),
				new yystateaction(-65515, true, YYAT_REDUCE, 16),
				new yystateaction(-19, true, YYAT_DEFAULT, 70),
				new yystateaction(-24, true, YYAT_DEFAULT, 80),
				new yystateaction(-21, true, YYAT_DEFAULT, 66),
				new yystateaction(0, false, YYAT_REDUCE, 9),
				new yystateaction(-30, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 23),
				new yystateaction(-65520, true, YYAT_REDUCE, 18),
				new yystateaction(0, false, YYAT_REDUCE, 15),
				new yystateaction(-31, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 21),
				new yystateaction(-23, true, YYAT_ERROR, 0),
				new yystateaction(0, false, YYAT_REDUCE, 13),
				new yystateaction(0, false, YYAT_REDUCE, 17),
				new yystateaction(0, false, YYAT_REDUCE, 25),
				new yystateaction(-65536, true, YYAT_DEFAULT, 57),
				new yystateaction(-65527, true, YYAT_ERROR, 0),
				new yystateaction(-65526, true, YYAT_REDUCE, 16),
				new yystateaction(-65537, true, YYAT_ERROR, 0),
				new yystateaction(-65542, true, YYAT_ERROR, 0)
			};
			yytables.yystateaction = stateaction;

			final yynontermgoto nontermgoto[] = {
				new yynontermgoto(0, 18),
				new yynontermgoto(0, 19),
				new yynontermgoto(0, 20),
				new yynontermgoto(0, 9),
				new yynontermgoto(68, 73),
				new yynontermgoto(0, 11),
				new yynontermgoto(0, 13),
				new yynontermgoto(63, 70),
				new yynontermgoto(63, 12),
				new yynontermgoto(0, 10),
				new yynontermgoto(57, 66),
				new yynontermgoto(57, 16),
				new yynontermgoto(0, 14),
				new yynontermgoto(0, 16),
				new yynontermgoto(0, 15),
				new yynontermgoto(30, 44),
				new yynontermgoto(30, 15),
				new yynontermgoto(28, 43),
				new yynontermgoto(28, 17),
				new yynontermgoto(20, 33),
				new yynontermgoto(20, 13),
				new yynontermgoto(61, 68),
				new yynontermgoto(52, 64),
				new yynontermgoto(49, 62),
				new yynontermgoto(46, 59),
				new yynontermgoto(42, 56),
				new yynontermgoto(38, 51),
				new yynontermgoto(36, 48),
				new yynontermgoto(34, 47),
				new yynontermgoto(33, 29),
				new yynontermgoto(25, 41),
				new yynontermgoto(24, 40),
				new yynontermgoto(23, 38),
				new yynontermgoto(9, 27),
				new yynontermgoto(2, 22)
			};
			yytables.yynontermgoto = nontermgoto;

			final yystategoto stategoto[] = {
				new yystategoto(-1, 63),
				new yystategoto(0, -1),
				new yystategoto(21, 57),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(28, -1),
				new yystategoto(0, -1),
				new yystategoto(0, 33),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(13, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(24, -1),
				new yystategoto(21, 63),
				new yystategoto(17, 57),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(6, -1),
				new yystategoto(0, -1),
				new yystategoto(1, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(22, -1),
				new yystategoto(15, 57),
				new yystategoto(0, -1),
				new yystategoto(14, 57),
				new yystategoto(0, -1),
				new yystategoto(17, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(15, 63),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(11, 57),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(13, 63),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(9, 57),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(-3, 30),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(13, -1),
				new yystategoto(0, -1),
				new yystategoto(-3, 28),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(-5, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1),
				new yystategoto(0, -1)
			};
			yytables.yystategoto = stategoto;

			yytables.yydestructorref = null;

			yytables.yytokendestref = null;

			yytables.yytokendestbaseref = null;
		}
	}
// line 273 ".\\AgentViewerParser.y"


/////////////////////////////////////////////////////////////////////////////
// programs section

public void yysyntaxerror( )
{
	StringBuffer sb=new StringBuffer();
	
	sb.append("Line ");
	sb.append(yylexerref.yylineno);
	sb.append(": error: syntax error near \"");
	sb.append(yylexerref.yytext,0,yylexerref.yyleng);
	sb.append("\"\n");

	yyerror(sb.toString());
	//yyerror(sErr);
	yyabort();
}

public void setMode(int iMode)
{
	this.iMode=iMode;
}

public void setDebug(boolean bDebug)
{
	this.bDebug=bDebug;
}

public void setFactory(ElementFactory eFactory)
{
	this.eFactory=eFactory;
}

public ElementFactory getFactory()
{
	return eFactory;
}

/**
	Prints the rule that has just been reduced
*/
private void REDUCE(String s)
{
	if(bDebug)
	{
		System.out.println(s);
	}
}

/**
	Returns the start state of a STRIPS problem.
*/
public Vector getStart()
{
	return this.vStart;
}

/**
	Returns the goal state of a STRIPS problem.
*/
public Vector getGoal()
{
	return this.vGoal;
}

/**
	Returns the operators of a STRIPS problem.
*/
public Vector getOperators()
{
	return this.vOperators;
}

/**
	Returns a list of parsed predicates
*/
public Vector getPredicates()
{
	return this.vPredicates;
}

/**
	Returns a list of parsed terms
*/
public Vector getTerms()
{
	return this.vTerms;
}

}


