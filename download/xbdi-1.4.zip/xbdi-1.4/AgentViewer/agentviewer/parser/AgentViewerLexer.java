/****************************************************************************
*                         A C A D E M I C   C O P Y
* 
* This file was produced by an ACADEMIC COPY of Parser Generator. It is for
* use in non-commercial software only. An ACADEMIC COPY of Parser Generator
* can only be used by a student, or a member of an academic community. If
* however you want to use Parser Generator for commercial purposes then you
* will need to purchase a license. For more information see the online help or
* go to the Bumble-Bee Software homepage at:
* 
* http://www.bumblebeesoftware.com
* 
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* AgentViewerLexer.java
* Java source file generated from AgentViewerLexer.l.
* 
* Date: 09/28/03
* Time: 22:24:03
* 
* ALex Version: 2.05
****************************************************************************/

// line 1 ".\\AgentViewerLexer.l"

/****************************************************************************
AgentViewerLexer.l
ParserWizard generated Lex file.

Date: sexta-feira, 19 de setembro de 2003
****************************************************************************/
package agentviewer.parser;

// line 37 "AgentViewerLexer.java"
import yl.*;

/////////////////////////////////////////////////////////////////////////////
// AgentViewerLexer

public class AgentViewerLexer extends yyflexer {
// line 18 ".\\AgentViewerLexer.l"

		// place any extra class members here
	private boolean bDebug=false;

// line 49 "AgentViewerLexer.java"
	public AgentViewerLexer() {
		yytables();
// line 24 ".\\AgentViewerLexer.l"

		// place any extra initialisation code here

// line 56 "AgentViewerLexer.java"
	}

	public static final int COMMENT = 2;
	public static final int LINECOMMENT = 4;
	public static final int INITIAL = 0;

	protected static yyftables yytables = null;

	public final int yyaction(int action) {
// line 44 ".\\AgentViewerLexer.l"

		// extract yylval for use later on in actions
		AgentViewerParser.YYSTYPE yylval = (AgentViewerParser.YYSTYPE)yyparserref.yylvalref;

// line 71 "AgentViewerLexer.java"
		yyreturnflg = true;
		switch (action) {
		case 1:
			{
// line 51 ".\\AgentViewerLexer.l"
PRINT(" TK_OPERATOR ");
					 ((AgentViewerParser)this.yyparserref).getFactory().newScope();
					 return AgentViewerParser.OPERATOR;
// line 80 "AgentViewerLexer.java"
			}
			break;
		case 2:
			{
// line 54 ".\\AgentViewerLexer.l"
PRINT(" TK_PRECONDS "); return AgentViewerParser.PRECONDS;
// line 87 "AgentViewerLexer.java"
			}
			break;
		case 3:
			{
// line 55 ".\\AgentViewerLexer.l"
PRINT(" TK_EFFECTS "); return AgentViewerParser.EFFECTS;
// line 94 "AgentViewerLexer.java"
			}
			break;
		case 4:
			{
// line 56 ".\\AgentViewerLexer.l"
PRINT(" TK_START "); return AgentViewerParser.START;
// line 101 "AgentViewerLexer.java"
			}
			break;
		case 5:
			{
// line 57 ".\\AgentViewerLexer.l"
PRINT(" TK_GOAL "); return AgentViewerParser.GOAL;
// line 108 "AgentViewerLexer.java"
			}
			break;
		case 6:
			{
// line 58 ".\\AgentViewerLexer.l"
PRINT(" TK_NOT "); return AgentViewerParser.NOT;
// line 115 "AgentViewerLexer.java"
			}
			break;
		case 7:
			{
// line 60 ".\\AgentViewerLexer.l"
PRINT(" TK_IDENTIFIER ") ;
												yylval.symbol=new String(yytext,0,yyleng);
												return AgentViewerParser.IDENTIFIER;
// line 124 "AgentViewerLexer.java"
			}
			break;
		case 8:
			{
// line 64 ".\\AgentViewerLexer.l"
PRINT(" TK_NUMBER ");
												yylval.symbol=new String(yytext,0,yyleng);
												return AgentViewerParser.NUMBER;
// line 133 "AgentViewerLexer.java"
			}
			break;
		case 9:
			{
// line 67 ".\\AgentViewerLexer.l"
PRINT(" TK_STRING");
												yylval.symbol=new String(yytext,0,yyleng);
												return AgentViewerParser.STRING;
// line 142 "AgentViewerLexer.java"
			}
			break;
		case 10:
			{
// line 70 ".\\AgentViewerLexer.l"
PRINT(" TK_NUMBER ");
												yylval.symbol=new String(yytext,0,yyleng);
												return AgentViewerParser.NUMBER;
// line 151 "AgentViewerLexer.java"
			}
			break;
		case 11:
			{
// line 73 ".\\AgentViewerLexer.l"
PRINT(" TK_NUMBER ");
												yylval.symbol=new String(yytext,0,yyleng);
												return AgentViewerParser.NUMBER;
// line 160 "AgentViewerLexer.java"
			}
			break;
		case 12:
			{
// line 77 ".\\AgentViewerLexer.l"
;
// line 167 "AgentViewerLexer.java"
			}
			break;
		case 13:
			{
// line 79 ".\\AgentViewerLexer.l"
yybegin(COMMENT);
// line 174 "AgentViewerLexer.java"
			}
			break;
		case 14:
			{
// line 80 ".\\AgentViewerLexer.l"
yybegin(0);
// line 181 "AgentViewerLexer.java"
			}
			break;
		case 15:
			{
// line 81 ".\\AgentViewerLexer.l"
;
// line 188 "AgentViewerLexer.java"
			}
			break;
		case 16:
			{
// line 82 ".\\AgentViewerLexer.l"
;
// line 195 "AgentViewerLexer.java"
			}
			break;
		case 17:
			{
// line 83 ".\\AgentViewerLexer.l"
;
// line 202 "AgentViewerLexer.java"
			}
			break;
		case 18:
			{
// line 84 ".\\AgentViewerLexer.l"
;
// line 209 "AgentViewerLexer.java"
			}
			break;
		case 19:
			{
// line 85 ".\\AgentViewerLexer.l"
;
// line 216 "AgentViewerLexer.java"
			}
			break;
		case 20:
			{
// line 89 ".\\AgentViewerLexer.l"
yybegin(LINECOMMENT);
// line 223 "AgentViewerLexer.java"
			}
			break;
		case 21:
			{
// line 90 ".\\AgentViewerLexer.l"
yybegin(0);
// line 230 "AgentViewerLexer.java"
			}
			break;
		case 22:
			{
// line 91 ".\\AgentViewerLexer.l"
yybegin(0);
// line 237 "AgentViewerLexer.java"
			}
			break;
		case 23:
			{
// line 92 ".\\AgentViewerLexer.l"
yybegin(0);
// line 244 "AgentViewerLexer.java"
			}
			break;
		case 24:
			{
// line 95 ".\\AgentViewerLexer.l"
;
// line 251 "AgentViewerLexer.java"
			}
			break;
		case 25:
			{
// line 97 ".\\AgentViewerLexer.l"
PRINT(yytext[0]); return yytext[0];
// line 258 "AgentViewerLexer.java"
			}
			break;
		default:
			break;
		}
		yyreturnflg = false;
		return 0;
	}

	protected final void yytables() {
		yystext_size = 100;
		yysunput_size = 100;
		yytext_max = 0;
		yyunput_max = 0;

		yycreatetables();
		yymatch = yytables.yymatch;
		yytransition = yytables.yytransition;
		yystate = yytables.yystate;
		yybackup = yytables.yybackup;
	}

	public static synchronized final void yycreatetables() {
		if (yytables == null) {
			yytables = new yyftables();

			final short match[] = {
				0
			};
			yytables.yymatch = match;

			final yytransition transition[] = {
				new yytransition(0, 0),
				new yytransition(8, 1),
				new yytransition(8, 1),
				new yytransition(0, 45),
				new yytransition(0, 10),
				new yytransition(8, 1),
				new yytransition(8, 8),
				new yytransition(8, 8),
				new yytransition(25, 11),
				new yytransition(76, 5),
				new yytransition(8, 8),
				new yytransition(32, 18),
				new yytransition(77, 5),
				new yytransition(26, 11),
				new yytransition(48, 38),
				new yytransition(47, 37),
				new yytransition(48, 38),
				new yytransition(47, 37),
				new yytransition(69, 3),
				new yytransition(0, 68),
				new yytransition(0, 72),
				new yytransition(70, 3),
				new yytransition(72, 68),
				new yytransition(33, 19),
				new yytransition(8, 1),
				new yytransition(34, 20),
				new yytransition(9, 1),
				new yytransition(22, 45),
				new yytransition(21, 14),
				new yytransition(8, 8),
				new yytransition(49, 39),
				new yytransition(50, 40),
				new yytransition(51, 42),
				new yytransition(52, 43),
				new yytransition(53, 44),
				new yytransition(29, 15),
				new yytransition(0, 10),
				new yytransition(30, 16),
				new yytransition(10, 1),
				new yytransition(11, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(12, 1),
				new yytransition(71, 3),
				new yytransition(0, 68),
				new yytransition(0, 72),
				new yytransition(56, 49),
				new yytransition(57, 51),
				new yytransition(58, 52),
				new yytransition(59, 53),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(14, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(31, 17),
				new yytransition(39, 29),
				new yytransition(23, 45),
				new yytransition(60, 56),
				new yytransition(13, 1),
				new yytransition(61, 57),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(15, 1),
				new yytransition(13, 1),
				new yytransition(16, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(17, 1),
				new yytransition(18, 1),
				new yytransition(19, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(20, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(13, 1),
				new yytransition(0, 46),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(24, 24),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(54, 54),
				new yytransition(62, 58),
				new yytransition(37, 24),
				new yytransition(63, 60),
				new yytransition(22, 46),
				new yytransition(64, 61),
				new yytransition(65, 62),
				new yytransition(66, 64),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(27, 27),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(21, 23),
				new yytransition(38, 27),
				new yytransition(67, 65),
				new yytransition(40, 30),
				new yytransition(28, 28),
				new yytransition(21, 23),
				new yytransition(37, 24),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(28, 28),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(35, 23),
				new yytransition(41, 31),
				new yytransition(42, 32),
				new yytransition(73, 70),
				new yytransition(74, 71),
				new yytransition(43, 33),
				new yytransition(44, 34),
				new yytransition(78, 77),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(38, 27),
				new yytransition(23, 46),
				new yytransition(0, 0),
				new yytransition(28, 28),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(46, 46),
				new yytransition(28, 28),
				new yytransition(27, 12),
				new yytransition(0, 0),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(12, 12),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(21, 23),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(21, 23),
				new yytransition(0, 0),
				new yytransition(36, 23),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(13, 67),
				new yytransition(0, 0),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(13, 67),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(55, 55),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(45, 35),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(0, 0),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36),
				new yytransition(46, 36)
			};
			yytables.yytransition = transition;

			final yystate state[] = {
				new yystate(0, 0, 0),
				new yystate(-7, -8, 0),
				new yystate(1, 0, 0),
				new yystate(-68, 8, 0),
				new yystate(3, 0, 0),
				new yystate(-75, -1, 0),
				new yystate(5, 0, 0),
				new yystate(0, 0, 25),
				new yystate(0, -3, 12),
				new yystate(45, 0, 25),
				new yystate(24, -65, 25),
				new yystate(0, -34, 25),
				new yystate(28, 163, 8),
				new yystate(67, 0, 7),
				new yystate(67, -6, 7),
				new yystate(67, -67, 7),
				new yystate(67, -74, 7),
				new yystate(67, -28, 7),
				new yystate(67, -101, 7),
				new yystate(67, -91, 7),
				new yystate(67, -91, 7),
				new yystate(45, 0, 0),
				new yystate(0, 0, 9),
				new yystate(0, 129, 0),
				new yystate(0, 68, 11),
				new yystate(0, 0, 13),
				new yystate(0, 0, 20),
				new yystate(0, 95, 10),
				new yystate(0, 91, 8),
				new yystate(67, -18, 7),
				new yystate(67, 69, 7),
				new yystate(67, 69, 7),
				new yystate(67, 85, 7),
				new yystate(67, 88, 7),
				new yystate(67, 93, 7),
				new yystate(45, 310, 0),
				new yystate(0, 277, 0),
				new yystate(0, -28, 0),
				new yystate(0, -29, 0),
				new yystate(67, -71, 7),
				new yystate(67, -77, 7),
				new yystate(67, 0, 6),
				new yystate(67, -82, 7),
				new yystate(67, -66, 7),
				new yystate(67, -80, 7),
				new yystate(-21, -7, 0),
				new yystate(-21, 105, 0),
				new yystate(54, 0, 0),
				new yystate(55, 0, 0),
				new yystate(67, -46, 7),
				new yystate(67, 0, 5),
				new yystate(67, -43, 7),
				new yystate(67, -56, 7),
				new yystate(67, -60, 7),
				new yystate(0, 78, 11),
				new yystate(0, 300, 10),
				new yystate(67, -30, 7),
				new yystate(67, -28, 7),
				new yystate(67, 26, 7),
				new yystate(67, 0, 4),
				new yystate(67, 23, 7),
				new yystate(67, 29, 7),
				new yystate(67, 41, 7),
				new yystate(67, 0, 3),
				new yystate(67, 28, 7),
				new yystate(67, 50, 7),
				new yystate(67, 0, 1),
				new yystate(0, 202, 2),
				new yystate(-68, 9, 15),
				new yystate(0, 0, 17),
				new yystate(72, 177, 16),
				new yystate(0, 141, 19),
				new yystate(-72, 10, 16),
				new yystate(0, 0, 18),
				new yystate(0, 0, 14),
				new yystate(0, 0, 24),
				new yystate(0, 0, 21),
				new yystate(0, 181, 22),
				new yystate(0, 0, 23)
			};
			yytables.yystate = state;

			final boolean backup[] = {
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false,
				false
			};
			yytables.yybackup = backup;
		}
	}
// line 99 ".\\AgentViewerLexer.l"


/////////////////////////////////////////////////////////////////////////////
// programs section

public void setDebug(boolean bDebug)
{
	this.bDebug=bDebug;
}

private void PRINT(String s)
{
	if(bDebug)
	{
		System.out.print(s);
	}
}

private void PRINT(char c)
{
	if(bDebug)
	{
		System.out.print(c);
	}
}

}


