/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements;

import java.util.Iterator;
import java.util.Vector;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteOperator implements Operator
{
	protected String sOperatorName;
	protected Vector vParameters;
	protected Vector vPreconditions;
	protected Vector vEffects;

	public ConcreteOperator(
		String sOperatorName,
		Vector vParameters,
		Vector vPreconditions,
		Vector vEffects)
	{
		this.sOperatorName = sOperatorName;
		this.vParameters = vParameters;
		this.vPreconditions = vPreconditions;
		this.vEffects = vEffects;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Operator#getPreconditions()
	 */
	public Vector getPreconditions()
	{
		return this.vPreconditions;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Operator#getEffects()
	 */
	public Vector getEffects()
	{
		return this.vEffects;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Operator#getTime()
	 */
	public int getTime()
	{
		return 0;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#getTruth()
	 */
	public boolean getTruth()
	{
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		if (this.vParameters == null)
			return 0;
		else
			return this.vParameters.size();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return this.vParameters;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		return this.sOperatorName;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		StringBuffer sbRes = new StringBuffer();
		sbRes.append(this.sOperatorName);

		if (this.vParameters != null)
		{
			sbRes.append("(");
			for (Iterator i = vParameters.iterator(); i.hasNext();)
			{
				Term t = (Term)i.next();
				sbRes.append(t.getKey());
				if (i.hasNext())
					sbRes.append(",");
			}
			sbRes.append(")");
		}

		return sbRes.toString();
	}

	public String toString()
	{
		StringBuffer sbRes = new StringBuffer();

		sbRes.append(this.getKey());
		if (this.vPreconditions != null)
		{
			sbRes.append("\npre(");
			for (Iterator i = this.vPreconditions.iterator(); i.hasNext();)
			{
				Predicate p = (Predicate)i.next();
				sbRes.append(p.toString());
				if (i.hasNext())
					sbRes.append(",");
			}
			sbRes.append(")");
		}

		if (this.vEffects != null)
		{
			sbRes.append("\npos(");
			for (Iterator i = this.vEffects.iterator(); i.hasNext();)
			{
				Predicate p = (Predicate)i.next();
				sbRes.append(p.toString());
				if (i.hasNext())
					sbRes.append(",");
			}
			sbRes.append(")");
		}

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#isFullyInstantiated()
	 */
	public boolean isFullyInstantiated()
	{
		if (this.vParameters != null)
		{
			for (Iterator i = vParameters.iterator(); i.hasNext();)
			{
				VariableTerm t = (VariableTerm)i.next();
				if (!t.isBound())
					return false;
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes = new StringBuffer();

		sbRes.append(this.sOperatorName);
		sbRes.append("/" + this.getArity());

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		Vector vNewParameters = null;
		Vector vNewPreconditions = null;
		Vector vNewEffects = null;
		
		if (this.vParameters != null)
		{
			vNewParameters = new Vector(this.vParameters.size());
			for (Iterator i = vParameters.iterator(); i.hasNext();)
			{
				Term t = (Term)i.next();
				t=t.copy();
				vNewParameters.add(t);
			}
		}

		if (this.vPreconditions != null)
		{
			vNewPreconditions = new Vector(this.vPreconditions.size());
			for (Iterator i = vPreconditions.iterator(); i.hasNext();)
			{
				Term t = (Term)i.next();
				vNewPreconditions.add(t.copy());
			}
		}

		if (this.vEffects != null)
		{
			vNewEffects = new Vector(this.vEffects.size());
			for (Iterator i = vEffects.iterator(); i.hasNext();)
			{
				Term t = (Term)i.next();
				vNewEffects.add(t.copy());
			}
		}

		return new ConcreteOperator(
			this.sOperatorName,
			vNewParameters,
			vNewPreconditions,
			vNewEffects);
	}
}
