/*
 * Created on 19/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.parser.elements;

import java.util.Vector;

/**
 * @author felipe
 */
public interface Operator extends Predicate
{
	public Vector getPreconditions();
	public Vector getEffects();
	public int getTime();
}
