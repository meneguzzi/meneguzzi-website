/*
 * Created on 19/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.parser.elements;

import java.util.Iterator;
import java.util.Vector;

/**
 * @author felipe
 */
public class ConcretePredicate implements Predicate
{
	protected String sPredicate;
	protected Vector vChildTerms = null;
	protected boolean bTruth = true;

	public ConcretePredicate(String sPredicate)
	{
		this.sPredicate = sPredicate;
	}

	public ConcretePredicate(String sPredicate, Vector vChildTerms)
	{
		this.sPredicate = sPredicate;
		this.vChildTerms = vChildTerms;
	}

	public ConcretePredicate(String sPredicate, Vector vChildTerms, boolean bTruth)
	{
		this.sPredicate = sPredicate;
		this.vChildTerms = vChildTerms;
		this.bTruth = bTruth;
	}

	public ConcretePredicate(Term term)
	{
		this.sPredicate = term.getName();
		this.vChildTerms = term.getTerms();
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Predicate#getTruth()
	 */
	public boolean getTruth()
	{
		return this.bTruth;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Term#getArity()
	 */
	public int getArity()
	{
		if (this.vChildTerms == null)
			return 0;
		else
			return vChildTerms.size();
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return this.vChildTerms;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Term#getName()
	 */
	public String getName()
	{
		return sPredicate;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		StringBuffer sbRes = new StringBuffer();
		sbRes.append(this.sPredicate);
		if (this.vChildTerms != null)
		{
			sbRes.append("(");
			for (Iterator i = vChildTerms.iterator(); i.hasNext();)
			{
				Term t = (Term) i.next();
				sbRes.append(t.getKey());
				if (i.hasNext())
					sbRes.append(",");
			}

			sbRes.append(")");
		}

		return sbRes.toString();
	}

	public String toString()
	{
		StringBuffer sbRes = new StringBuffer();
		if (!this.bTruth)
			sbRes.append("-");

		sbRes.append(this.sPredicate);
		if (this.vChildTerms != null)
		{
			sbRes.append("(");
			for (Iterator i = vChildTerms.iterator(); i.hasNext();)
			{
				Term t = (Term) i.next();
				sbRes.append(t.toString());
				if (i.hasNext())
					sbRes.append(",");
			}

			sbRes.append(")");
		}

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#isFullyInstantiated()
	 */
	public boolean isFullyInstantiated()
	{
		if (this.vChildTerms != null)
		{
			for (Iterator i = vChildTerms.iterator(); i.hasNext();)
			{
				Term t = (Term) i.next();
				if (t instanceof VariableTerm)
				{
					VariableTerm vt = (VariableTerm) t;
					if (!vt.isBound())
						return false;
				}
			}
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes = new StringBuffer();

		sbRes.append(this.sPredicate);
		sbRes.append("/" + this.getArity());

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		Vector vNewChildren = null;

		if (this.vChildTerms != null)
		{
			vNewChildren = new Vector(this.vChildTerms.size());
			for (Iterator i = vChildTerms.iterator(); i.hasNext();)
			{
				Term t = (Term) i.next();
				vNewChildren.add(t.copy());
			}
		}

		return new ConcretePredicate(this.sPredicate, vNewChildren, this.bTruth);
	}

	public Predicate not()
	{
		Vector vNewChildren = null;

		if (this.vChildTerms != null)
		{
			vNewChildren = new Vector(this.vChildTerms.size());
			for (Iterator i = vChildTerms.iterator(); i.hasNext();)
			{
				Term t = (Term) i.next();
				vNewChildren.add(t.copy());
			}
		}

		return new ConcretePredicate(this.sPredicate, vNewChildren, !this.bTruth);
	}
}
