/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements;

import java.util.Iterator;
import java.util.Vector;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PrologList implements Term
{
	protected Vector vItems;
	
	public PrologList(Vector vItems)
	{
		assert(vItems!=null);
		this.vItems=vItems;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		return vItems.size();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return vItems;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		return null;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		StringBuffer sbRes=new StringBuffer();
		
		sbRes.append("[");
		for(Iterator i=this.vItems.iterator(); i.hasNext();)
		{
			Term t=(Term)i.next();
			sbRes.append(t.toString());
			if(i.hasNext())
				sbRes.append(",");
		}
		sbRes.append("]");
		
		return sbRes.toString();
	}
	
	public String toString()
	{
		return this.getKey();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes=new StringBuffer();
		
		sbRes.append("/"+this.getArity());
		
		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		Vector vNewItems=new Vector(this.vItems);
		
		for(Iterator i=vItems.iterator();i.hasNext();)
		{
			Term t=(Term)i.next();
			vNewItems.add(t.copy());
		}
		
		return new PrologList(vNewItems);
	}

}
