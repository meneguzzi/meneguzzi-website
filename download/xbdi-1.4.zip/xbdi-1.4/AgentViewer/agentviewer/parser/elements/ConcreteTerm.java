/*
 * Created on 19/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.parser.elements;

import java.util.Iterator;
import java.util.Vector;

/**
 * @author felipe
 */
public class ConcreteTerm implements Term
{
	protected String sTerm;
	protected Vector vChildTerms=null;
	
	public ConcreteTerm(String sTerm)
	{
		this.sTerm=sTerm;
	}
	
	public ConcreteTerm(String sTerm, Vector vChildTerms)
	{
		this.sTerm=sTerm;
		this.vChildTerms=vChildTerms;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Term#getArity()
	 */
	public int getArity()
	{
		if(this.vChildTerms==null)
			return 0;
		else
			return vChildTerms.size();
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return this.vChildTerms;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.Term#getName()
	 */
	public String getName()
	{
		return sTerm;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		StringBuffer sbRes=new StringBuffer();
		sbRes.append(this.sTerm);
		if(this.vChildTerms!=null)
		{
			sbRes.append("(");
			for(Iterator i=vChildTerms.iterator(); i.hasNext();)
			{
				Term t=(Term)i.next();
				sbRes.append(t.getKey());
				if(i.hasNext())
					sbRes.append(",");
			}

			sbRes.append(")");
		}
		
		return sbRes.toString();
	}

	public String toString()
	{
		return this.getKey();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes=new StringBuffer();
		
		sbRes.append(this.sTerm);
		sbRes.append("/"+this.getArity());
		
		return sbRes.toString();
	}
	
	/*
	 *  (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		Vector vNew=null;
		if(this.vChildTerms!=null)
		{
			vNew=new Vector(vChildTerms.size());
			for(Iterator i=vChildTerms.iterator(); i.hasNext();)
			{
				Term tChild=(Term)i.next();
				tChild=tChild.copy();
				vNew.add(tChild);
			}
		}
		
		return new ConcreteTerm(this.sTerm, vNew);
	}
}
