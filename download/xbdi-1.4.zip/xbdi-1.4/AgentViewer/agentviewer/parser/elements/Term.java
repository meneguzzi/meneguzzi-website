/*
 * Created on 19/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.parser.elements;

import java.util.Vector;

/**
 * @author felipe
 */
public interface Term
{
	/**
	 * Returns the number of child terms this term has, should it be a functional term.
	 * This is also know as the "Arity" of the term. 
	 * @return The Term's arity.
	 */
	public int getArity();
	
	/**
	 * Returns the actual child terms this term has, should it be a functional term. 
	 * @return A list of child terms.
	 */
	public Vector getTerms();
	/**
	 * Returns the name of the term.
	 * @return The term's name.
	 */
	public String getName();
	
	/**
	 * Returns the key that should uniquely identify sintacticaly equal terms.
	 * @return The key to this term
	 */
	public String getKey();
	/**
	 * Returns the signature of this term, which should be the same in cas of potentially unifiable terms.
	 * The signature is represented by the following formula:
	 * <Term Name> + / + <Term Arity>
	 * @return The term's signature
	 */
	public String getSignature();
	
	/**
	 * Returns a hard copy of the current Term.
	 * That is, a copy occupying a different memory address than the original Term.
	 * Warning, this does not preserve variable uniqueness within a Term
	 * @return The copy
	 */
	public Term copy();
	
	/**
	 * Returns a String representation of this term, usually the original String that created the term.
	 * @return
	 */
	public String toString();
}
