/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements;

import java.util.Vector;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class VariableTerm implements Term
{
	protected String sName;
	protected Term tBinding = null;

	public VariableTerm(String sName)
	{
		this.sName = sName;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		if (tBinding == null)
			return 0;
		else
			return tBinding.getArity();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		if (tBinding == null)
			return null;
		else
			return tBinding.getTerms();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		if (tBinding == null)
			return this.sName;
		else
			return tBinding.getName();
	}

	public String getVariableName()
	{
		return this.sName;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		//TODO check if this is true;
		if (tBinding == null)
			return this.sName;
		else
			return this.tBinding.getKey();
	}

	public String toString()
	{
		return this.sName;
	}

	public boolean isBound()
	{
		if (this.tBinding != null)
		{
			if (!(tBinding instanceof VariableTerm))
				return true;
			else
				return ((VariableTerm)tBinding).isBound();
		} else
			return false;
	}

	public void bind(Term t)
	{
		if (!this.isBound())
			this.tBinding = t;
	}
	
	public Term unBind()
	{
		Term tRes=this.tBinding;
		this.tBinding=null;
		return tRes;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		if (this.isBound())
		{
			return this.tBinding.getSignature();
		} else
		{
			StringBuffer sbRes = new StringBuffer();

			sbRes.append(this.sName);
			sbRes.append("/" + this.getArity());

			return sbRes.toString();
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		if(this.isBound())
			return this.tBinding.copy();
		else
			return new VariableTerm(this.sName);
	}
}
