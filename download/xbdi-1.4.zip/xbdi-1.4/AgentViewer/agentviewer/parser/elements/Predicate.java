/*
 * Created on 19/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.parser.elements;

/**
 * @author felipe
 */
public interface Predicate extends Term
{
	public boolean getTruth();
	public boolean isFullyInstantiated();
}
