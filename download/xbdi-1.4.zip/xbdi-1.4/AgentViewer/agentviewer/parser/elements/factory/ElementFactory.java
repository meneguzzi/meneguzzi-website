/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import java.util.Iterator;
import java.util.Vector;

import agentviewer.parser.elements.ConcreteOperator;
import agentviewer.parser.elements.ConcretePredicate;
import agentviewer.parser.elements.ConcreteTerm;
import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.PrologList;
import agentviewer.parser.elements.Term;
import agentviewer.parser.elements.VariableTerm;

/**
 * The class responsible from instantiating all the elements collected during parse
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ElementFactory implements PredicateFactory, TermFactory, OperatorFactory
{
	public ElementFactory()
	{
	
	}
	
	public void newScope()
	{
	
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.PredicateFactory#createPredicate(java.lang.String, java.util.Vector, boolean)
	 */
	public Predicate createPredicate(String sPredicate, Vector vChildren, boolean bTruth)
	{
		return new ConcretePredicate(sPredicate, vChildren, bTruth);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.TermFactory#createTerm(java.lang.String, java.util.Vector)
	 */
	public Term createTerm(String sTerm, Vector vChildren)
	{
		if(sTerm==null)
		{
			return new PrologList(vChildren);
		}
		char cFirst=sTerm.charAt(0);
		if((cFirst=='_' || Character.isUpperCase(cFirst)) && vChildren==null)
			return new VariableTerm(sTerm);
		else
			return new ConcreteTerm(sTerm, vChildren);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.OperatorFactory#createOperator(java.lang.String, java.util.Vector, java.util.Vector, java.util.Vector)
	 */
	public Operator createOperator(
		String sOperator,
		Vector vParameters,
		Vector vPreconditions,
		Vector vEffects)
	{
		return new ConcreteOperator(sOperator, vParameters, vPreconditions, vEffects);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.OperatorFactory#checkOperator(agentviewer.parser.elements.Operator)
	 */
	public boolean checkOperator(Operator o)
	{
		Vector vParameters=o.getTerms();
		
		if(vParameters!=null)
		{
			for(Iterator i=vParameters.iterator();i.hasNext();)
			{
				Term t=(Term)i.next();
				if(!(t instanceof VariableTerm))
					return false;
			}
		}
	
		return true;
	}

	public boolean isFullyInstantiated(Vector v)
	{
		assert(v!=null);
		for(Iterator i=v.iterator(); i.hasNext();)
		{
			Object o=i.next();
			if(o instanceof Predicate)
			{
				Predicate p=(Predicate)o;
				if(!p.isFullyInstantiated())
					return false;
			}
		}
		return true;
	}
}
