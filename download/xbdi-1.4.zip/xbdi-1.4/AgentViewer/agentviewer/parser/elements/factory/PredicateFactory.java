/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import java.util.Vector;

import agentviewer.parser.elements.Predicate;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface PredicateFactory
{
	/**
	 * Creates a new Predicate from the given parameters
	 * @param sPredicate The name of the predicate
	 * @param vChildren The terms
	 * @param bTruth The explicit truth value for this predicate
	 * @return
	 */
	public Predicate createPredicate(String sPredicate, Vector vChildren, boolean bTruth);
}
