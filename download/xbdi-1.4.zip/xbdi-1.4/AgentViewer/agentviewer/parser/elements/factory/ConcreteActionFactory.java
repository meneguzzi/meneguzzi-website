/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import java.util.Vector;

import agentviewer.parser.elements.Action;
import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;
import agentviewer.parser.elements.VariableTerm;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteActionFactory implements ActionFactory
{
	public ConcreteActionFactory()
	{
	
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.ActionFactory#isOperatorHeader(agentviewer.parser.elements.Predicate, agentviewer.parser.elements.Operator)
	 */
	public boolean isOperatorHeader(Predicate pActionHeader, Operator oper)
	{
		return pActionHeader.getSignature().equals(oper.getSignature());
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.ActionFactory#createAction(agentviewer.parser.elements.Predicate, agentviewer.parser.elements.Operator)
	 */
	public Action createAction(Predicate pActionHeader, Operator oper) throws Exception
	{
		Action aNew=null;
		if(this.isOperatorHeader(pActionHeader, oper))
		{
			Vector vOperatorParameters=oper.getTerms();
			Vector vPredicateParameters=pActionHeader.getTerms();
			Operator oNew=oper;
			if(vOperatorParameters!=null)
			{
				for(int i=0;i<vOperatorParameters.size();i++)
				{
					VariableTerm vt=(VariableTerm)vOperatorParameters.elementAt(i);
					Term t=(Term)vPredicateParameters.elementAt(i);
					vt.bind(t);
				}
				oNew=(Operator)oper.copy();
				aNew=new Action(oNew.getName(), oNew.getTerms(), oNew.getPreconditions(), oNew.getEffects());
				
				for(int i=0;i<vOperatorParameters.size();i++)
				{
					VariableTerm vt=(VariableTerm)vOperatorParameters.elementAt(i);
					vt.unBind();
				}
			}else
				aNew=new Action(oNew.getName(), oNew.getTerms(), oNew.getPreconditions(), oNew.getEffects());
		}else
			throw new Exception(pActionHeader.toString()+" is not a header to "+oper.getKey());
		return aNew;
	}

}
