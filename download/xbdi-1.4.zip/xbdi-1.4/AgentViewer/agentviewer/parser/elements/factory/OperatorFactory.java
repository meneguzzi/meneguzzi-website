/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import java.util.Vector;

import agentviewer.parser.elements.Operator;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface OperatorFactory
{
	/**
	 * Creates a new STRIPS operator from the parameters
	 * @param sOperator The operator name
	 * @param vParameters The operator's parameters
	 * @param vPreconditions The operator's preconditions
	 * @param vEffects The operator's effects
	 * @return
	 */
	public Operator createOperator(String sOperator, Vector vParameters, Vector vPreconditions, Vector vEffects);
	
	public boolean checkOperator(Operator o);
}
