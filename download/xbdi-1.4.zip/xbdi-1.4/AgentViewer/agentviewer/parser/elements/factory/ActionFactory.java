/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import agentviewer.parser.elements.Action;
import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface ActionFactory
{
	public boolean isOperatorHeader(Predicate pActionHeader, Operator oper);
	
	public Action createAction(Predicate pActionHeader, Operator oper) throws Exception;
}
