/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.elements.factory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;
import agentviewer.parser.elements.VariableTerm;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ScopedElementFactory extends ElementFactory
{
	protected HashMap hmAtoms;
	protected HashMap hmVariables;
	protected HashMap hmPredicates;
	protected HashMap hmTerms;
	protected HashMap hmOperators;

	public ScopedElementFactory()
	{
		this.resetMaps();
	}

	protected void resetMaps()
	{
		hmAtoms = new HashMap();
		hmVariables = new HashMap();
		hmPredicates = new HashMap();
		hmTerms = new HashMap();
		hmOperators = new HashMap();
	}

	/**
	 * Changes the current scope
	 *
	 */
	public void newScope()
	{
		//this.resetMaps();
		hmVariables = new HashMap();
	}
	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.OperatorFactory#createOperator(java.lang.String, java.util.Vector, java.util.Vector, java.util.Vector)
	 */
	public Operator createOperator(
		String sOperator,
		Vector vParameters,
		Vector vPreconditions,
		Vector vEffects)
	{
		Operator o = super.createOperator(sOperator, vParameters, vPreconditions, vEffects);

		if (hmOperators.containsKey(o.getKey()))
		{
			o = (Operator)hmOperators.get(o.getKey());
		} else
		{
			hmOperators.put(o.getKey(), o);
		}

		return o;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.PredicateFactory#createPredicate(java.lang.String, java.util.Vector, boolean)
	 */
	public Predicate createPredicate(String sPredicate, Vector vChildren, boolean bTruth)
	{
		Predicate p = super.createPredicate(sPredicate, vChildren, bTruth);

		if (hmPredicates.containsKey(p.getKey()))
		{
			//p = (Predicate)hmPredicates.get(p.getKey());
		} else
		{
			hmPredicates.put(p.getKey(), p);
		}

		return p;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.factory.TermFactory#createTerm(java.lang.String, java.util.Vector)
	 */
	public Term createTerm(String sTerm, Vector vChildren)
	{
		Term t = super.createTerm(sTerm, vChildren);

		if (t instanceof VariableTerm)
		{
			if (hmVariables.containsKey(t.getKey()))
			{
				//System.out.println("Variable " + t.getName() + " already in ST");
				t = (Term)hmVariables.get(t.getKey());
			} else
			{
				//System.out.println("Adding variable " + t.getName() + " to ST");
				hmVariables.put(t.getKey(), t);
			}
		} else if (t.getArity() == 0)
		{
			if (hmAtoms.containsKey(t.getKey()))
			{
				t = (Term)hmAtoms.get(t.getKey());
			} else
			{
				hmAtoms.put(t.getKey(), t);
			}
		} else
		{
			if (hmTerms.containsKey(t.getKey()))
			{
				t = (Term)hmTerms.get(t.getKey());
			} else
			{
				hmTerms.put(t.getKey(), t);
			}
		}

		return t;
	}

	public String toString()
	{
		StringBuffer sbRes = new StringBuffer();
		sbRes.append("Contents of Symbol Table\n");
		sbRes.append("Atoms\n");
		for (Iterator i = hmAtoms.values().iterator(); i.hasNext();)
		{
			Term t = (Term)i.next();
			sbRes.append("\t"+t.toString() + "\n");
		}

		sbRes.append("Terms\n");
		for (Iterator i = hmTerms.values().iterator(); i.hasNext();)
		{
			Term t = (Term)i.next();
			sbRes.append("\t"+t.toString() + "\n");
		}

		sbRes.append("Predicates\n");
		for (Iterator i = hmPredicates.values().iterator(); i.hasNext();)
		{
			Predicate p = (Predicate)i.next();
			sbRes.append("\t"+p.toString() + "\n");
		}

		sbRes.append("Operators\n");
		for (Iterator i = hmOperators.values().iterator(); i.hasNext();)
		{
			Operator o = (Operator)i.next();
			sbRes.append("\t"+o.toString() + "\n");
		}

		return sbRes.toString();
	}
}
