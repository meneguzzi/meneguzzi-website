/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.Vector;

import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteDesire implements Desire
{
	public static String DES = "des";
	protected XBDIAgent xbdiAgent;
	protected Predicate pDesired;
	protected String sTime;
	protected String sPriority;

	protected Vector vCondition;

	public ConcreteDesire(XBDIAgent xbdiAgent, Predicate pDesired)
	{
		this.xbdiAgent = xbdiAgent;
		this.pDesired = pDesired;
		this.sTime = "Tf";
		this.sPriority = "[0.8]";

		this.vCondition = new Vector();
	}

	public ConcreteDesire(XBDIAgent xbdiAgent, Predicate pDesired, Vector vCondition)
	{
		this.xbdiAgent = xbdiAgent;
		this.pDesired = pDesired;
		this.sTime = "Tf";
		this.sPriority = "[0.8]";

		this.vCondition = vCondition;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Desire#getProperty()
	 */
	public Predicate getProperty()
	{
		return this.pDesired;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Desire#getCondition()
	 */
	public Vector getCondition()
	{
		return this.vCondition;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#getTruth()
	 */
	public boolean getTruth()
	{
		// Must check the condition
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#isFullyInstantiated()
	 */
	public boolean isFullyInstantiated()
	{
		return this.pDesired.isFullyInstantiated();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		return 4;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return this.pDesired.getTerms();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		return ConcreteDesire.DES;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		return this.pDesired.getKey();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes = new StringBuffer();

		sbRes.append(ConcreteDesire.DES);
		sbRes.append("/" + this.getArity());

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		return new ConcreteDesire(xbdiAgent, pDesired, vCondition);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Desire#getIdentity()
	 */
	public String getIdentity()
	{
		return xbdiAgent.getIdentity();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Desire#getTime()
	 */
	public String getTime()
	{
		return this.sTime;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Desire#getPriority()
	 */
	public String getPriority()
	{
		return this.sPriority;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentComponent#acceptVisitor(agentviewer.parser.xbdi.XBDIAgentVisitor)
	 */
	public void acceptVisitor(XBDIAgentVisitor visitor)
	{
		visitor.processDesire(this);
	}

}
