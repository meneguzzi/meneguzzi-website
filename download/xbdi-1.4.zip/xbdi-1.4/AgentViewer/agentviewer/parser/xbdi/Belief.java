/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import agentviewer.parser.elements.Predicate;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface Belief extends Predicate, XBDIAgentComponent
{
	/**
	 * 
	 * @return The property that the agent believes in
	 */
	public Predicate getProperty();

	/**
	 * 
	 * @return The identity of the agent that beliefs in this object
	 */
	public String getIdentity();
}
