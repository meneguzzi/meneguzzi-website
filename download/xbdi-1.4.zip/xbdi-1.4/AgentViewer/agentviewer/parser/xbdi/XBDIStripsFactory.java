/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.Iterator;
import java.util.Vector;

import agentviewer.parser.elements.ConcretePredicate;
import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class XBDIStripsFactory
{
	protected XBDIAgent createAgent(String sIdentity)
	{
		return new ConcreteXBDIAgent(sIdentity);
	}

	protected Vector createBeliefs(XBDIAgent xbdiAgent, Vector vStart)
	{
		Vector vBeliefs = new Vector(vStart.size());

		for (Iterator i = vStart.iterator(); i.hasNext();)
		{
			Predicate p = (Predicate)i.next();
			Belief b = new ConcreteBelief(xbdiAgent, p);
			vBeliefs.add(b);
		}

		return vBeliefs;
	}

	protected Vector createDesires(XBDIAgent xbdiAgent, Vector vGoal)
	{
		Vector vDesires = new Vector(vGoal.size());

		for (Iterator i = vGoal.iterator(); i.hasNext();)
		{
			Predicate p = (Predicate)i.next();
			Desire d = new ConcreteDesire(xbdiAgent, p);
			vDesires.add(d);
		}

		return vDesires;
	}

	protected Vector createActions(XBDIAgent xbdiAgent, Vector vOperators)
	{
		Vector vActions = new Vector(vOperators);

		for (Iterator i = vOperators.iterator(); i.hasNext();)
		{
			Operator o = (Operator)i.next();
			Vector vCondition=this.createBeliefs(xbdiAgent, o.getPreconditions());
			Vector vEffects=this.createBeliefs(xbdiAgent, o.getEffects());
			Action a = new ConcreteAction(xbdiAgent, new ConcretePredicate(o.getName(), o.getTerms()), vCondition, vEffects);
			vActions.add(a);
		}


		return vActions;
	}

	public XBDIAgent createAgent(
		String sIdentity,
		Vector vStart,
		Vector vGoal,
		Vector vOperators)
	{
		XBDIAgent xbdiAgent=this.createAgent(sIdentity);
		
		xbdiAgent.setBeliefs(this.createBeliefs(xbdiAgent, vStart));
		xbdiAgent.setDesires(this.createDesires(xbdiAgent, vGoal));
		xbdiAgent.setActions(this.createActions(xbdiAgent, vOperators));
		
		return xbdiAgent;
	}

}
