/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.Vector;

import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteAction implements Action
{
	public static final String ACT="act";
	
	protected XBDIAgent xbdiAgent;
	protected Predicate pActionHeader;
	protected Vector vCondition;
	protected Vector vEffects;
	
	public ConcreteAction(XBDIAgent xbdiAgent, Predicate pActionHeader, Vector vCondition, Vector vEffects)
	{
		this.xbdiAgent=xbdiAgent;
		this.pActionHeader=pActionHeader;
		
		//TODO Must perform some kind of checking here
		this.vCondition=vCondition;
		//TODO Same thing here
		this.vEffects=vEffects;
	}

	/*
	 *  (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Action#getActionHeader()
	 */
	public Predicate getActionHeader()
	{
		return this.pActionHeader;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Action#getCondition()
	 */
	public Vector getCondition()
	{
		return this.vCondition;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Action#getEffects()
	 */
	public Vector getEffects()
	{
		return this.vEffects;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#getTruth()
	 */
	public boolean getTruth()
	{
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#isFullyInstantiated()
	 */
	public boolean isFullyInstantiated()
	{
		return this.pActionHeader.isFullyInstantiated();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		return 2;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return this.pActionHeader.getTerms();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		return ConcreteAction.ACT;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		return this.pActionHeader.getKey();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes = new StringBuffer();

		sbRes.append(ConcreteAction.ACT);
		sbRes.append("/" + this.getArity());

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		return new ConcreteAction(this.xbdiAgent, this.pActionHeader, this.vCondition, this.vEffects);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Action#getIdentity()
	 */
	public String getIdentity()
	{
		return xbdiAgent.getIdentity();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentComponent#acceptVisitor(agentviewer.parser.xbdi.XBDIAgentVisitor)
	 */
	public void acceptVisitor(XBDIAgentVisitor visitor)
	{
		visitor.processAction(this);		
	}

}
