/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi.visitor;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Vector;

import agentviewer.parser.xbdi.Action;
import agentviewer.parser.xbdi.Belief;
import agentviewer.parser.xbdi.Desire;
import agentviewer.parser.xbdi.XBDIAgent;
import agentviewer.parser.xbdi.XBDIAgentComponent;
import agentviewer.parser.xbdi.XBDIAgentVisitor;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class XBDIAgentWriter implements XBDIAgentVisitor
{
	protected String sFilename;
	protected PrintWriter pwOut;

	public XBDIAgentWriter(String sFilename) throws IOException
	{
		this.sFilename = sFilename;
		pwOut = new PrintWriter(new BufferedWriter(new FileWriter(sFilename)));
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentVisitor#processComponent(agentviewer.parser.xbdi.XBDIAgentComponent)
	 */
	public void processComponent(XBDIAgentComponent xbdiComponent)
	{
		pwOut.println("% Could no process component " + xbdiComponent.getClass().toString());
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentVisitor#processAgent(agentviewer.parser.xbdi.XBDIAgent)
	 */
	public void processAgent(XBDIAgent xbdiAgent)
	{
		pwOut.println("%%%%%%%%%%%%%%%%%%%% Agent Desires %%%%%%%%%%%%%%%%%%%%%%%");
		this.processXBDIComponents(xbdiAgent.getDesires());
		pwOut.println();
		pwOut.println("%%%%%%%%%%%%%%%%%%%% Agent Identity %%%%%%%%%%%%%%%%%%%%%%");
		pwOut.println("identity(" + xbdiAgent.getIdentity() + ").");
		pwOut.println();
		pwOut.println("%%%%%%%%%%%%%%%%%%%% Agent Beliefs %%%%%%%%%%%%%%%%%%%%%%%");
		this.processXBDIComponents(xbdiAgent.getBeliefs());
		pwOut.println();
		pwOut.println("%%%%%%%%%%%%%%%%%%%% Agent Actions %%%%%%%%%%%%%%%%%%%%%%%");
		this.processXBDIComponents(xbdiAgent.getActions());

		pwOut.flush();
	}

	private void processXBDIComponents(Vector vComponents)
	{
		for (Iterator i = vComponents.iterator(); i.hasNext();)
		{
			XBDIAgentComponent xbdiComponent = (XBDIAgentComponent)i.next();
			xbdiComponent.acceptVisitor(this);
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentVisitor#processBelief(agentviewer.parser.xbdi.Belief)
	 */
	public void processBelief(Belief belief)
	{
		this.writeBelief(belief);
		pwOut.println(".");
	}

	protected void writeBelief(Belief belief)
	{
		pwOut.print("bel(" + belief.getIdentity() + ", " + belief.getProperty() + ")");
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentVisitor#processDesire(agentviewer.parser.xbdi.Desire)
	 */
	public void processDesire(Desire desire)
	{
		pwOut.println(
			"des("
				+ desire.getIdentity()
				+ ", "
				+ desire.getProperty()
				+ ","
				+ desire.getTime()
				+ ","
				+ desire.getPriority()
				+ ").");
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentVisitor#processAction(agentviewer.parser.xbdi.Action)
	 */
	public void processAction(Action action)
	{
		Vector vEffects = action.getEffects();
		pwOut.println("%Related to STRIPS Operator "+action.getActionHeader());
		for (Iterator i = vEffects.iterator(); i.hasNext();)
		{
			Belief bel = (Belief)i.next();
			pwOut.print(
				"act(" + action.getIdentity() + "," + action.getActionHeader().toString() + ")");
			pwOut.print("causes ");
			this.writeBelief(bel);

			Vector vCondition = action.getCondition();
			if (vCondition.size() > 0)
			{
				pwOut.println("");
				pwOut.print("\tif ");
				for (Iterator i2 = vCondition.iterator(); i2.hasNext();)
				{
					Belief bel2 = (Belief)i2.next();
					pwOut.print("\t");
					this.writeBelief(bel2);

					if (i2.hasNext())
						pwOut.println(",");
				}
			}
			pwOut.println(".");
			pwOut.println("");
		}
	}

}
