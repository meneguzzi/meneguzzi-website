/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.Vector;

import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.Term;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteBelief implements Belief
{
	public static final String BEL="bel";
	
	protected XBDIAgent xbdiAgent;
	protected Predicate pBelieved;
	
	public ConcreteBelief(XBDIAgent xbdiAgent, Predicate pBelieved)
	{
		this.xbdiAgent=xbdiAgent;
		this.pBelieved=pBelieved;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Belief#getProperty()
	 */
	public Predicate getProperty()
	{
		return this.pBelieved;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#getTruth()
	 */
	public boolean getTruth()
	{
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Predicate#isFullyInstantiated()
	 */
	public boolean isFullyInstantiated()
	{
		return this.pBelieved.isFullyInstantiated();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getArity()
	 */
	public int getArity()
	{
		return 2;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getTerms()
	 */
	public Vector getTerms()
	{
		return this.pBelieved.getTerms();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getName()
	 */
	public String getName()
	{
		return ConcreteBelief.BEL;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getKey()
	 */
	public String getKey()
	{
		return this.pBelieved.getKey();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#getSignature()
	 */
	public String getSignature()
	{
		StringBuffer sbRes = new StringBuffer();

		sbRes.append(ConcreteBelief.BEL);
		sbRes.append("/" + this.getArity());

		return sbRes.toString();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.elements.Term#copy()
	 */
	public Term copy()
	{
		return new ConcreteBelief(this.xbdiAgent, this.pBelieved);
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.Belief#getIdentity()
	 */
	public String getIdentity()
	{
		return this.xbdiAgent.getIdentity();
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentComponent#acceptVisitor(agentviewer.parser.xbdi.XBDIAgentVisitor)
	 */
	public void acceptVisitor(XBDIAgentVisitor visitor)
	{
		visitor.processBelief(this);
	}

}
