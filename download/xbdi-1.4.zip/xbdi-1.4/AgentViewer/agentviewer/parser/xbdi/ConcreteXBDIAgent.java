/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteXBDIAgent implements XBDIAgent
{
	protected String sIdentity;

	protected HashMap hmBeliefs;

	protected HashMap hmDesires;

	protected HashMap hmActions;

	public ConcreteXBDIAgent(String sIdentity)
	{
		this.sIdentity = sIdentity;
		this.hmBeliefs = new HashMap();
		this.hmDesires = new HashMap();
		this.hmActions = new HashMap();
	}

	public ConcreteXBDIAgent(String sIdentity, Vector vBeliefs, Vector vDesires, Vector vActions)
	{
		this.sIdentity = sIdentity;
		this.setBeliefs(vBeliefs);
		this.setDesires(vDesires);
		this.setActions(vActions);
	}

	/**
	 * This will probably change when I put some kind of consistency maintenance
	 * @param vBeliefs
	 */

	public void setBeliefs(Vector vBeliefs)
	{
		for (Iterator i = vBeliefs.iterator(); i.hasNext();)
		{
			Object o = i.next();
			if (o instanceof Belief)
			{
				Belief b = (Belief)o;
				this.hmBeliefs.put(b.getKey(), b);
			}
		}
	}

	public void setDesires(Vector vDesires)
	{
		for (Iterator i = vDesires.iterator(); i.hasNext();)
		{
			Object o = i.next();
			if (o instanceof Desire)
			{
				Desire d = (Desire)o;
				this.hmDesires.put(d.getKey(), d);
			}
		}
	}

	public void setActions(Vector vActions)
	{
		for (Iterator i = vActions.iterator(); i.hasNext();)
		{
			Object o = i.next();
			if (o instanceof Action)
			{
				Action a = (Action)o;
				this.hmActions.put(a.getKey(), a);
			}
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgent#getConstraints()
	 */
	public Vector getConstraints()
	{
		// TODO Put this somehow
		return null;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgent#getBeliefs()
	 */
	public Vector getBeliefs()
	{
		Vector vBeliefs = new Vector(hmBeliefs.values());
		return vBeliefs;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgent#getDesires()
	 */
	public Vector getDesires()
	{
		Vector vDesires = new Vector(hmDesires.values());
		return vDesires;
	}

	/* (non-Javadoc)
		 * @see agentviewer.parser.xbdi.XBDIAgent#getActions()
		 */
	public Vector getActions()
	{
		Vector vActions = new Vector(hmActions.values());
		return vActions;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgent#getIdentity()
	 */
	public String getIdentity()
	{
		return this.sIdentity;
	}

	/* (non-Javadoc)
	 * @see agentviewer.parser.xbdi.XBDIAgentComponent#acceptVisitor(agentviewer.parser.xbdi.XBDIAgentVisitor)
	 */
	public void acceptVisitor(XBDIAgentVisitor visitor)
	{
		visitor.processAgent(this);
	}
}
