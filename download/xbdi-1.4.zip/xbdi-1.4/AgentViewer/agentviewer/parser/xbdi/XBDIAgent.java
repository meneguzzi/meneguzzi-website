/*
 * Created on 11/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.parser.xbdi;

import java.util.Vector;
/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface XBDIAgent extends XBDIAgentComponent
{

	/**
	 * Returns the set of integrity constraints that this agent's behaviour must abide to
	 */
	public Vector getConstraints();

	/**
	 * Returns the current Beliefs the agent has
	 */
	public Vector getBeliefs();

	/**
	 * Returns the Desires this agent has.
	 */
	public Vector getDesires();

	/**
	 * Returns the name of the agent
	 */
	public String getIdentity();

	public Vector getActions();

	public void setBeliefs(Vector vBeliefs);

	public void setDesires(Vector vDesires);

	public void setActions(Vector vActions);

}
