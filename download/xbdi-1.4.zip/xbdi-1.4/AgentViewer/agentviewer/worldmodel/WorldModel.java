/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.worldmodel;

import java.util.Vector;

import agentviewer.parser.elements.Predicate;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface WorldModel
{
	/**
	 * Returns the truth value of the specified predicate within the world model.
	 * 
	 * @param pred A predicate whose truth value is intended to be known 
	 * @return The truth value of pred
	 */
	public boolean getTruth(Predicate pred);
	
	/**
	 * Returns the truth value of the conjunction of predicates supplied in v.
	 * @param v A conjunction of Predicates
	 * @return The truth value of the specified conjunction
	 */
	public boolean getTruth(Vector v);
	
	/**
	 * Sets the truth value for all the predicates contained in the vector
	 * @param v A list of the operators allowed in this world model
	 */
	public void setOperators(Vector v);
	
	/**
	 * Updates the world with a list of actions or new predicates.
	 * @param v
	 * @throws Exception Unsupported element is present in the vector
	 */
	public void updateWorld(Vector v) throws Exception;
	
	/**
	 * Updates the world with a predicate suppressing whathever truth value is already set.
	 * @param pred
	 */
	public void updateWorld(Predicate pred);
	
	/**
	 * Removes the specified predicate from the world model. This effectively makes the predicate
	 * implicitly false.
	 * @param pred The predicate whose key should be removed from the model
	 * @return The removed predicate
	 */
	public Predicate remove(Predicate pred);
	
	/**
	 * Updates the world by applying the specified action.
	 * @param pAction
	 */
	public void applyAction(Predicate pAction) throws Exception;
	
	/**
	 * Updates the current time stamp in the world and returns the new time
	 * @return
	 */
	public int updateTime();
	
	/**
	 * Sets the time to the specified value
	 * @param iTime
	 */
	public void setTime(int iTime);
	
	/**
	 * Gets the current time
	 * @return
	 */
	public int getTime();
	
	/**
	 * Returns a list of predicates specifying what is true and what is not
	 * @return
	 */
	public Vector getWorldState();
}
