/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.worldmodel;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import agentviewer.parser.elements.Action;
import agentviewer.parser.elements.Operator;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.factory.ActionFactory;
import agentviewer.parser.elements.factory.ConcreteActionFactory;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteWorldModel implements WorldModel
{
	protected HashMap hmTruth;
	protected HashMap hmOperators;
	
	protected ActionFactory aFactory;

	protected int iTime = 0;

	public ConcreteWorldModel()
	{
		this.hmTruth = new HashMap();
		this.hmOperators = new HashMap();
		aFactory=new ConcreteActionFactory();
	}

	public ConcreteWorldModel(Vector vStart) throws Exception
	{
		this.hmTruth = new HashMap();
		aFactory=new ConcreteActionFactory();
		this.updateWorld(vStart);
	}

	public ConcreteWorldModel(Vector vStart, Vector vOperators) throws Exception
	{
		assert(vOperators != null);
		this.hmTruth = new HashMap();
		this.hmOperators = new HashMap();
		this.setOperators(vOperators);
		aFactory=new ConcreteActionFactory();
		this.updateWorld(vStart);
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getTruth(agentviewer.parser.elements.Predicate)
	 */
	public boolean getTruth(Predicate pred)
	{
		if(this.hmTruth.containsKey(pred.getKey()))
		{
			Predicate p=(Predicate) hmTruth.get(pred.getKey());
			return p.getTruth()==pred.getTruth();
		}else
			return false;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getTruth(java.util.Vector)
	 */
	public boolean getTruth(Vector v)
	{
		for(Iterator i=v.iterator(); i.hasNext();)
		{
			Object o=i.next();
			if(o instanceof Predicate)
			{
				if(!this.getTruth((Predicate) o))
					return false;
			}else
				return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#setOperators(java.util.Vector)
	 */
	public void setOperators(Vector vOperators)
	{
		for (Iterator i = vOperators.iterator(); i.hasNext();)
		{
			Operator o = (Operator)i.next();
			hmOperators.put(o.getSignature(), o);
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateWorld(java.util.Vector)
	 */
	public void updateWorld(Vector v) throws Exception
	{
		assert(v != null);
		for (Iterator i = v.iterator(); i.hasNext();)
		{
			Object o = i.next();

			if (o instanceof Predicate)
			{
				this.updateWorld((Predicate)o);
			}else
				throw new Exception(
					"Class " + o.getClass().getName() + " is not supported by this world model.");
		}

	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateWorld(agentviewer.parser.elements.Predicate)
	 */
	public void updateWorld(Predicate pred)
	{
		String sKey = pred.getKey();
		if (!this.hmTruth.containsKey(sKey))
		{
			this.hmTruth.put(sKey, pred);
		} else
		{
			Predicate p = (Predicate)hmTruth.get(sKey);
			if (p.getTruth() != pred.getTruth())
				this.hmTruth.put(sKey, pred);
		}
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#remove(agentviewer.parser.elements.Predicate)
	 */
	public Predicate remove(Predicate pred)
	{
		if(hmTruth.containsKey(pred.getKey()))
		{
			return (Predicate)hmTruth.remove(pred.getKey());
		}else
			return null;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateWorld(javax.swing.Action)
	 */
	public void applyAction(Predicate pAction) throws Exception
	{
		System.out.print("Executing action "+pAction+" ... ");
		if(hmOperators.containsKey(pAction.getSignature()))
		{
			Operator oper=(Operator)hmOperators.get(pAction.getSignature());
			Action a=aFactory.createAction(pAction, oper);
			Vector vPreconditions=a.getPreconditions();
			Vector vEffects=a.getEffects();
			
			if(vPreconditions==null || this.getTruth(vPreconditions))
				this.updateWorld(vEffects);
			else
				throw new Exception("Precondition of "+a.getKey()+" does not hold.");
			System.out.println("Done");
		}else
			System.out.print("Failed");
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateTime()
	 */
	public int updateTime()
	{
		return ++iTime;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#setTime(int)
	 */
	public void setTime(int iTime)
	{
		this.iTime = iTime;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getTime()
	 */
	public int getTime()
	{
		return iTime;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getWorldState()
	 */
	public Vector getWorldState()
	{
		return new Vector(this.hmTruth.values());
	}

}
