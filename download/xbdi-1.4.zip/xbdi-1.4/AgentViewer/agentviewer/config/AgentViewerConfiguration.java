/*
 * Created on 16/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * @author felipe
 */
public abstract class AgentViewerConfiguration
{
	public static final String DEFAULT_PROPERTY_FILE = "AgentViewer.properties";
	
	public static final String SICSTUS_PATH_PROPERTY = "sicstus.path";
	public static final String SICSTUS_EXEC_PROPERTY = "sicstus.exec";
	
	public static final String XBDI_PATH_PROPERTY = "xbdi.path";
	public static final String XBDI_FILE_PROPERTY = "xbdi.file";
	public static final String XBDI_PLAN_FILE_PROPERTY = "xbdi.plan";
	
	public static final String XBDI_PORT_PROPERTY = "xbdi.port";
	public static final String XBDI_CLIENT_HOST_PROPERTY = "xbdi.client.host";
	public static final String XBDI_CLIENT_PORT_PROPERTY = "xbdi.client.port";

	public static final String AGENT_PATH_PROPERTY = "agent.path";
	public static final String COREO_PATH_PROPERTY = "coreo.path";


	public static final String SENSOR_WINDOW_PROPERTY = "ui.sensorwindow";
	
	public static Properties readProperties()
	{
		return AgentViewerConfiguration.readProperties(DEFAULT_PROPERTY_FILE);
	}

	/**
	 * @param sProperties
	 * @return
	 */
	public static Properties readProperties(String sProperties)
	{
		Properties pOptions = getDefaultProperties();

		try
		{
			pOptions.load(new FileInputStream(sProperties));
		} catch (FileNotFoundException e)
		{
			System.out.println("No Options File Found, using default options");
			try
			{
				pOptions.store(new FileOutputStream(sProperties), "Agent Viewer Options");
			} catch (FileNotFoundException e1)
			{
				e1.printStackTrace();
			} catch (IOException e1)
			{
				e1.printStackTrace();
			}
		} catch (IOException e)
		{
			System.out.println("Failed to load Options, using default options");
		}

		return pOptions;
	}

	public static Properties getDefaultProperties()
	{
		Properties pOptions = new Properties();

		pOptions.setProperty(XBDI_PATH_PROPERTY, "./");
		pOptions.setProperty(XBDI_FILE_PROPERTY, "kernel_boot.pl");
		pOptions.setProperty(XBDI_PLAN_FILE_PROPERTY, "planin.txt");
		pOptions.setProperty(XBDI_PORT_PROPERTY, "6666");
		pOptions.setProperty(XBDI_CLIENT_HOST_PROPERTY, "localhost");
		pOptions.setProperty(XBDI_CLIENT_PORT_PROPERTY, "6666");

		pOptions.setProperty(AGENT_PATH_PROPERTY, System.getProperty("user.dir"));
		pOptions.setProperty(COREO_PATH_PROPERTY, System.getProperty("user.dir"));

		//pOptions.setProperty("agentviewer.sicstus.path",System.getProperty("user.dir"));
		pOptions.setProperty(SICSTUS_EXEC_PROPERTY,"/bin/sicstus.exe");
		pOptions.setProperty(SICSTUS_PATH_PROPERTY,"C:/Program Files/SICStus Prolog/");
		pOptions.setProperty(SENSOR_WINDOW_PROPERTY,"true");

		return new Properties(pOptions);
	}
}
