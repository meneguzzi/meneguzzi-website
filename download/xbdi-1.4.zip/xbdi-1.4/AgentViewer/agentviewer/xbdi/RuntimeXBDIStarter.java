/*
 * Created on 01/06/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.xbdi;

import java.io.IOException;

import agentviewer.sicstus.SICStusRuntime;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class RuntimeXBDIStarter implements XBDIStarter
{
	protected SICStusRuntime sicstus;
	
	protected static final String PARSE_AGENT_PREDICATE = "parse";
	protected static final String RUN_COREGRAPHY_PREDICATE = "coreo";
	protected static final String START_SERVER_PREDICATE = "initXBDI2";
	protected static final String XBDI_PREDICATE = "initXBDI2";
	
	protected String sSICStusPath;
	protected String sSICStusExec;
	protected String sXBDIPath;
	protected String sXBDIFile;
	
	protected String sAgentFile;
	
	public RuntimeXBDIStarter() throws IOException
	{
		this.sSICStusPath="C:/Program Files/SICStus Prolog/";
		this.sSICStusExec="/bin/sicstus.exe";
		this.sXBDIPath=System.getProperty("user.dir");
		this.sXBDIFile="kernel_boot";
	}
	
	public RuntimeXBDIStarter(String sSICStusPath, String sXBDIPath, String sXBDIFile) throws IOException
	{
		this.sSICStusPath=sSICStusPath;
		this.sSICStusExec="/bin/sicstus.exe";
		this.sXBDIPath=sXBDIPath;
		this.sXBDIFile=sXBDIFile;
	}
	
	private void load() throws IOException
	{
		sAgentFile="teste.bdi";
		//sicstus=new SICStusRuntime(sXBDIPath, sXBDIFile);
		//sicstus=new SICStusRuntime(this.sSICStusPath+"/bin",sXBDIPath+"/"+sXBDIFile);
		sicstus=new SICStusRuntime(this.sSICStusPath+"/bin",sXBDIPath);
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#startUp()
	 */
	public void startUp() throws Exception
	{
		this.load();
		//sicstus.executeQuery("[\'"+sXBDIFile+"\'].");
		sicstus.executeQuery("working_directory(_,'"+this.sXBDIPath+"').");
		sicstus.executeQuery("[\'"+sXBDIFile+"\'].");
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#restart()
	 */
	public void restart() throws Exception
	{
		sicstus.halt();
		sicstus=new SICStusRuntime(this.sSICStusPath+"/bin",sXBDIPath);
		this.load();
		this.startUp();
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#parseAgent(java.lang.String)
	 */
	public boolean parseAgent(String sAgentFile) throws Exception
	{
		this.setAgentFile(sAgentFile);
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#runCoreography(java.lang.String)
	 */
	public boolean runCoreography(String sCoreoFile) throws Exception
	{
		//this.setCoreoFile(sCoreoFile);
		//sicstus.executeQuery(RuntimeXBDIStarter.XBDI_PREDICATE+"(\'"+this.sAgentFile+"\',\'"+sCoreoFile+"\').");
		sicstus.executeQuery("retract(planner(internal)).");
		sicstus.executeQuery("asserta(planner(external)).");
		this.setAgentFile(sAgentFile);
		this.setCoreoFile(sCoreoFile);
		sicstus.executeQuery(RuntimeXBDIStarter.XBDI_PREDICATE+".");
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#agentviewer.xbdi(java.lang.String, java.lang.String)
	 */
	public boolean xbdi(String sAgentFile, String sCoreoFile) throws Exception
	{
		this.setAgentFile(sAgentFile);
		this.setCoreoFile(sCoreoFile);
		//sicstus.executeQuery(RuntimeXBDIStarter.XBDI_PREDICATE+"("+sAgentFile+","+sCoreoFile+").");
		sicstus.executeQuery(RuntimeXBDIStarter.XBDI_PREDICATE+".");
		return true;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#startServer(int)
	 */
	public void startServer(int iPort) throws Exception
	{
		sicstus.executeQuery("retractall(xbdiport).");
		sicstus.executeQuery("retractall(modo).");
		sicstus.executeQuery("asserta(modo(kernel)).");
		sicstus.executeQuery("asserta(xbdiport("+iPort+")).");
		
		sicstus.executeQuery(RuntimeXBDIStarter.XBDI_PREDICATE+".");
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#stopServer()
	 */
	public void stopServer()
	{
		try
		{
			sicstus.halt();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#runQuery()
	 */
	public boolean runQuery(String sQuery)
	{
		sicstus.executeQuery(sQuery);
		return true;
	}

	public void setAgentFile(String sAgentFile)
	{
		sicstus.executeQuery("retractall(modo).");
		sicstus.executeQuery("asserta(modo(coreografia)).");
		sicstus.executeQuery("retractall(agentfile).");
		System.out.println(sAgentFile);
		sicstus.executeQuery("asserta(agentfile(\'"+sAgentFile+"\')).");
		//Test Code
		//sicstus.executeQuery("listing.");
		this.sAgentFile=sAgentFile;
	}
	
	public void setCoreoFile(String sCoreoFile)
	{
		sicstus.executeQuery("retractall(coreofile).");
		System.out.println(sCoreoFile);
		//sCoreoFile=sCoreoFile.replaceAll("\\","/");
		sicstus.executeQuery("asserta(coreofile(\'"+sCoreoFile+"\')).");
		//Test Code
		//sicstus.executeQuery("listing.");
	}
	
	public void finalize()
	{
		try
		{
			sicstus.halt();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}		
	}
}
