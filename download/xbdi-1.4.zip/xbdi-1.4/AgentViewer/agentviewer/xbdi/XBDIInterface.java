/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.xbdi;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface XBDIInterface
{
	public boolean parseAgent(String sAgentFile) throws Exception;
	
	public boolean runCoreography(String sCoreoFile) throws Exception;
	
	public boolean xbdi(String sAgentFile, String sCoreoFile) throws Exception;
	
	public void startServer(int iPort) throws Exception;
	
	public void stopServer();
	
	public boolean runQuery(String sQuery);
}
