/*
 * Created on 02/05/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.xbdi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author felipe
 */
public class CoreographyHandler
{

	/**
	 * 
	 */
	public CoreographyHandler()
	{
		super();
	}

	public String readCoreography(String sCoreoFile) throws IOException
	{
		return this.readCoreography(new File(sCoreoFile));
	}

	/** Reads a coreography file and returns a string containing it.
	*
	* 	Hopefully I will add some validation here sometime in the future
		* @author felipe
		* 
	*/
	public String readCoreography(File fCoreo) throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader(fCoreo));

		String sRes = new String();

		while (br.ready())
		{
			sRes += br.readLine() + System.getProperty("line.separator");
		}

		return sRes;
	}

	/** Writes a coreography to a file.
	*
	* 	Hopefully I will add some validation here sometime in the future
	* @author felipe
	* 
	*/
	public void writeCoreography(File fCoreo, String sCoreo) throws IOException
	{
		sCoreo.replaceAll("\n", System.getProperty("line.separator"));
		BufferedWriter bw = new BufferedWriter(new FileWriter(fCoreo));

		bw.write(sCoreo);

		bw.flush();
		bw.close();
	}

}
