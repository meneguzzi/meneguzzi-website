/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.xbdi.elements;

import agentviewer.parser.elements.Predicate;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ConcreteIntentionFactory implements IntentionFactory
{
	/* (non-Javadoc)
	 * @see agentviewer.xbdi.elements.IntentionFactory#isIntention(agentviewer.parser.elements.Predicate)
	 */
	public boolean isIntention(Predicate pred)
	{
		boolean bRes=false;
		
		if(PrimaryIntention.isPrimaryIntention(pred))
			bRes=true;
		if(RelativeIntention.isRelativeIntention(pred))
			bRes=true;
			
		return bRes;
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.elements.IntentionFactory#createIntention(agentviewer.parser.elements.Predicate)
	 */
	public Intention createIntention(Predicate pred) throws Exception
	{
		if(PrimaryIntention.isPrimaryIntention(pred))
			return new PrimaryIntention(pred);
		else if(RelativeIntention.isRelativeIntention(pred))
			return new RelativeIntention(pred);
		else
			return null;
	}

}
