/*
 * Created on 19/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.xbdi.elements;

import agentviewer.parser.elements.Predicate;

/**
 * @author felipe
 */
public interface Intention extends Predicate
{
	public String getAgent();
	public int getTime();
	public Predicate getProperty(); 
}
