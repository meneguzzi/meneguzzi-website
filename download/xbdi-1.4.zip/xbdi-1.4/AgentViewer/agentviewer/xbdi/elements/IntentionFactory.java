/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.xbdi.elements;

import agentviewer.parser.elements.Predicate;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface IntentionFactory
{
	public boolean isIntention(Predicate pred);
	public Intention createIntention(Predicate pred) throws Exception;
}
