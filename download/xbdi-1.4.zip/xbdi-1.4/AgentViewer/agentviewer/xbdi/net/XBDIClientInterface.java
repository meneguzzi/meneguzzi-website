/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.xbdi.net;

import java.io.IOException;
import java.net.UnknownHostException;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface XBDIClientInterface
{
	public void connect() throws UnknownHostException, IOException;
	public void close() throws IOException;
	public boolean isConnected();

	public void sendSensorInput(String sInput);
	public void sendSensorInput(String sClauses[], int iSenseTime, int iTime);

	public int availableActuatorOutput() throws IOException;
	public String getActuatorOutput() throws IOException;
	public String[] getActuatorOutputCommands() throws IOException;
}
