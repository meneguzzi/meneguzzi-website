/*
 * Created on 30/04/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.xbdi.net;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class XBDIDummyServer implements Runnable
{
	ServerSocket ssXBDIDummy;

	Socket sClient;

	Thread tServer;

	boolean bQuit;

	public XBDIDummyServer(int iPort) throws IOException
	{
		ssXBDIDummy = new ServerSocket(iPort, 1);
		ssXBDIDummy.setSoTimeout(100);

		tServer = new Thread(this);
		tServer.setDaemon(true);
		tServer.start();

		bQuit = false;
	}

	public void halt()
	{
		bQuit = true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run()
	{
		try
		{
			while (Thread.currentThread() == tServer)
			{
				try
				{
					sClient = ssXBDIDummy.accept();
					
					System.out.println("Received connection: "+sClient.getRemoteSocketAddress().toString());
					
					try
					{
						this.processClient(sClient);
					}catch(IOException ioe)
					{
						ioe.printStackTrace();
					}
					
				}catch(SocketTimeoutException ste)
				{
				
				}
				
				if (bQuit)
				{
					ssXBDIDummy.close();
					return;
				}
			}
		} catch (IOException e)
		{
			e.printStackTrace();
		}

	}

	protected void processClient(Socket sClient) throws IOException
	{
		PrintStream psOut=new PrintStream(sClient.getOutputStream());
		InputStreamReader isr=new InputStreamReader(sClient.getInputStream());
		
		while(sClient.isConnected())
		{
			char cRead=0;
			String sCommand;
			StringBuffer sbCommands=new StringBuffer();		
			while(cRead !='.')
			{
				cRead=(char)isr.read();
				sbCommands.append(cRead);
			}
			
			System.out.println("Read Command: "+sbCommands.toString());
			
			psOut.println(processCommands(sbCommands.toString()));
			psOut.flush();
		}
	}
	
	protected String processCommands(String sCommands)
	{
		StringBuffer sbRes=new StringBuffer();
		
		sbRes.append("read("+sCommands+").");
		
		return sbRes.toString();
	}
}
