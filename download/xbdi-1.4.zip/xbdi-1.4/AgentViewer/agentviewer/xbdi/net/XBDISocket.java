/*
 * Created on 30/04/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.xbdi.net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class XBDISocket implements XBDIClientInterface
{
	protected Socket sXBDI;
	
	protected String sHost;
	protected int iPort;
	
	protected PrintStream psOutgoing;
	protected BufferedReader brIncoming;
	
	public XBDISocket(String sHost, int iPort) throws UnknownHostException, IOException
	{
		this.sHost=sHost;
		this.iPort=iPort;
		//connect();
	}
	
	public void connect() throws UnknownHostException, IOException
	{
		sXBDI = new Socket(sHost, iPort);
		psOutgoing = new PrintStream(sXBDI.getOutputStream());
		brIncoming = new BufferedReader(new InputStreamReader(sXBDI.getInputStream()));
		sXBDI.setTcpNoDelay(true);
	}
	
	public void close() throws IOException
	{
		this.sendSensorInput("[halt].");
		sXBDI.shutdownInput();
		sXBDI.shutdownOutput();
		sXBDI.close();
		//sXBDI=null;
		//psOutgoing=null;
		//brIncoming=null;
	}
	
	public void sendSensorInput(String sInput)
	{
		if(sXBDI.isOutputShutdown() || sXBDI.isClosed())
			return;
			
		sInput.replace('\n', System.getProperty("line.separator").charAt(0));
		System.out.println("Sending: "+sInput);
		psOutgoing.println(sInput);
		psOutgoing.flush();
		//sXBDI.getOutputStream().flush();
	}
	
	public int availableActuatorOutput() throws IOException
	{
		if(sXBDI.isInputShutdown() || sXBDI.isClosed())
			return 0;
		else
			return sXBDI.getInputStream().available();
	}
	
	public String getActuatorOutput() throws IOException
	{
		if(sXBDI.isInputShutdown() || sXBDI.isClosed())
			return "";
		
		
		if(this.availableActuatorOutput()>0)
		{
			int iAvailable=this.availableActuatorOutput();
			//System.out.println("Available "+iAvailable);
			char res[]=new char[iAvailable];	
		
			//brIncoming.read(res, 0, res.length);
			//return new String(res);
			return brIncoming.readLine();
		
			
		}else
			return null;
	}
	
	public void sendSensorInput(String sClauses[], int iSenseTime, int iTime)
	{
		StringBuffer sbOut=new StringBuffer();
		
		//Ensure that we did not get a null pointer instead of an array
		assert sClauses != null;
		
		sbOut.append("[current_time(");
		sbOut.append(iTime);
		sbOut.append(")");
		
		if(sClauses.length != 0)
			sbOut.append(", ");
		
		for(int i=0; i<sClauses.length; i++)
		{
			if(i!=0)
				sbOut.append(", ");
			
			sbOut.append("sense(");
			sbOut.append(sClauses[i]);
			sbOut.append(", ");
			sbOut.append(iSenseTime);
			sbOut.append(")");
		}
		
		sbOut.append("].");
		
		this.sendSensorInput(sbOut.toString());
	}
	
	public String []getActuatorOutputCommands() throws IOException
	{
		String sOutput=this.getActuatorOutput();
		
		if(sOutput!=null)
		{
			ArrayList al=new ArrayList();
			StringTokenizer st=new StringTokenizer(sOutput, "[],\n\r");
		
			while(st.hasMoreTokens())
			{
				String s=st.nextToken();
				al.add(s);
			}
		
			String sRes[]=new String[al.size()];
			sRes=(String[])al.toArray(sRes);
			
			return sRes;
		}else
			return null;
	}
	
	public boolean isConnected()
	{
		if(sXBDI!=null)
			return sXBDI.isConnected();
		else
			return false;
	}
	/**
	 * @return
	 */
	public int getPort()
	{
		return iPort;
	}

	/**
	 * @return
	 */
	public String getHost()
	{
		return sHost;
	}

}
