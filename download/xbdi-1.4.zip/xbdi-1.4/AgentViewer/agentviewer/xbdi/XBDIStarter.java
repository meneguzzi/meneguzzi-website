/*
 * Created on 31/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.xbdi;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface XBDIStarter extends XBDIInterface
{
	public void startUp() throws Exception;
	
	public void restart() throws Exception;
	
}
