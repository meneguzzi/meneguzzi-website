package agentviewer.xbdi;
import se.sics.jasper.SICStus;
import se.sics.jasper.SPException;
import se.sics.jasper.SPPredicate;
import se.sics.jasper.SPTerm;
import agentviewer.xbdi.net.XBDIDummyServer;

/*
 * Created on 29/04/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */

/**
 * @author felipe
 */
public class JasperXBDIStarter implements XBDIStarter
{
	protected SICStus sp;

	protected String sSICStusPath;
	protected String sXBDIPath;
	protected String sXBDIFile;

	protected static final String PARSE_AGENT_PREDICATE = "initXBDI";
	protected static final String RUN_COREGRAPHY_PREDICATE = "runXBDI";
	protected static final String START_SERVER_PREDICATE = "runXBDI";
	protected static final String XBDI_PREDICATE = "agentviewer.xbdi";
	
	protected XBDIDummyServer xbdiDummy;

	/**
	 * 
	 */
	public JasperXBDIStarter() throws SPException
	{
		super();

		this.sSICStusPath = "C:/Program Files/SICStus Prolog/bin";

		this.sXBDIFile = "kernel_boot.pl";
		this.sXBDIPath = "./";
		
		this.loadXBDI();
	}
	
	public JasperXBDIStarter(String sSICStusPath, String sXBDIPath, String sXBDIFile) throws SPException
	{
		this.sSICStusPath = sSICStusPath;
		this.sXBDIPath = sXBDIPath; 
		this.sXBDIFile = sXBDIFile;
		this.loadXBDI();
	}
	
	private void loadXBDI() throws SPException
	{
		System.setProperty("java.library.path", this.sSICStusPath);
		sp = SICStus.getInitializedSICStus();
		if (sp == null)
			sp = new SICStus();
	}

	public void startUp() throws SPException
	{
		//sp.query(new SPPredicate(sp, "listing", 0,  null), new SPTerm[]{});
		sp = SICStus.getInitializedSICStus();
		if (sp == null)
			sp = new SICStus();

		sp.load(this.sXBDIPath+"/"+this.sXBDIFile);
	}

	public void restart() throws SPException
	{
		if(sp == null)
		{
			sp.finalize();
		}
			
		this.startUp();
	}

	public boolean parseAgent(String sAgentFile) throws SPException
	{
		SPPredicate spAgentPredicate =
			new SPPredicate(sp, JasperXBDIStarter.PARSE_AGENT_PREDICATE, 1, "");

		SPTerm sptAgentFile = new SPTerm(sp, sAgentFile);

		return sp.query(spAgentPredicate, new SPTerm[] { sptAgentFile });
	}

	public boolean runCoreography(String sCoreographyFile) throws SPException
	{
		SPPredicate spCoregraphyPredicate =
			new SPPredicate(sp, JasperXBDIStarter.RUN_COREGRAPHY_PREDICATE, 1, "");

		SPTerm sptCoreographyFile = new SPTerm(sp, sCoreographyFile);

		return sp.query(
			spCoregraphyPredicate,
			new SPTerm[] { sptCoreographyFile });
	}

	public boolean xbdi(String sAgentFile, String sCoreographyFile)
		throws SPException
	{
		SPPredicate spXBDIPredicate =
			new SPPredicate(sp, JasperXBDIStarter.XBDI_PREDICATE, 2, "");

		SPTerm sptAgentFile = new SPTerm(sp, sAgentFile);
		SPTerm sptCoreographyFile = new SPTerm(sp, sCoreographyFile);

		return sp.query(
			spXBDIPredicate,
			new SPTerm[] { sptAgentFile, sptCoreographyFile });
	}
	
	public void startServer(int iPort) throws SPException
	{
		SPPredicate spXBDIPredicate =
					new SPPredicate(sp, JasperXBDIStarter.START_SERVER_PREDICATE, 2, "");
		
		SPTerm sptPort = new SPTerm(sp, Integer.toString(iPort));
		
		boolean bRes = sp.query(
					spXBDIPredicate,
					new SPTerm[] { sptPort});
		/*try
		{
			xbdiDummy=new XBDIDummyServer(iPort);
		} catch (IOException e)
		{
			e.printStackTrace();
		}*/
	}
	
	public void stopServer()
	{
		/*xbdiDummy.halt();
		xbdiDummy=null;*/
	}

	/* (non-Javadoc)
	 * @see agentviewer.xbdi.XBDIStarter#runQuery()
	 */
	public boolean runQuery(String sQuery)
	{
		return false;
	}
}
