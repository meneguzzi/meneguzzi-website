/*
 * Created on 31/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.sicstus;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class SICStusRuntime implements Runnable
{
	private boolean bQuit = false;

	private Thread tOutReader;
	private Thread tErrReader;

	private Runtime rt;
	private Process pSicstus;
	
	private PrintWriter pwIn=null;
	private BufferedReader brOut=null;
	private BufferedReader brErr=null;
	
	private String sWorkDir;
	private String sSICStusExecutable;
	private String sBootfile;

	protected static String SICSTUS_EXEC="C:/Program Files/SICStus Prolog/bin/sicstus.exe";
	protected static String WORK_DIR="./";
	
	public SICStusRuntime(String sBootfile) throws IOException
	{
		this.sBootfile=sBootfile;
		this.sSICStusExecutable=SICSTUS_EXEC;
		this.sWorkDir=WORK_DIR;
		String sParams[] = null; //{ "-i", "-l", sBootfile };
		this.load(sParams);
	}

	public SICStusRuntime(String sWorkDir, String sBootfile) throws IOException
	{
		this.sWorkDir = sWorkDir;
		this.sSICStusExecutable=SICSTUS_EXEC;
		this.sBootfile=sBootfile;
		//String sParams[] = null; //{ "-i", "-l", sBootfile };
		//String sParams[] = {"SP_PATH=C:/Program Files/SICStus Prolog/library/x86-win32-nt-4"};
		String sParams[] = {"SP_PATH=C:/Program Files/SICStus Prolog/"};
		this.load(sParams);
	}
	
	public SICStusRuntime(String sSICStusExecutable, String sWorkDir, String sBootfile) throws IOException
	{
		this.sWorkDir = sWorkDir;
		this.sSICStusExecutable=SICSTUS_EXEC;
		this.sBootfile=sBootfile;
		this.sSICStusExecutable=sSICStusExecutable;
		//String sParams[] = { "-i", "-l", sBootfile };
		//String sParams[] = {"SP_PATH=C:/Program Files/SICStus Prolog/library/x86-win32-nt-4"};
		String sParams[] = {"SP_PATH=C:/Program Files/SICStus Prolog/"};
		this.load(sParams);
	}

	private void load(String sParams[]) throws IOException
	{
		rt = Runtime.getRuntime();
		//String sLibs="C:/Program Files/SICStus Prolog/bin;C:/Program Files/SICStus Prolog/library;C:/Program Files/SICStus Prolog/x86-win32-nt-4";
		//System.setProperty("java.library.path", System.getProperty("java.library.path")+";"+sLibs);
		//System.out.println(System.getProperty("java.library.path"));
		//rt.load("C:/Program Files/SICStus Prolog/library/x86-win32-nt-4/sockets.dll");
		//System.out.println("Current directory="+System.getProperty("user.dir"));
		System.out.println("Workdir for SICStus="+this.sWorkDir);
		//rt.loadLibrary("sockets");
		//rt.loadLibrary("sprt38");
		this.pSicstus =
			//rt.exec(this.sSICStusExecutable+" -i -l "+sBootfile, sParams, new File(this.sWorkDir));
			rt.exec(this.sSICStusExecutable, sParams, new File(this.sWorkDir));
			//rt.exec(this.sSICStusExecutable+" -m", sParams, new File(this.sWorkDir));
			//rt.exec("D:/DeploymentArea/x-bdi/x-bdi2.bat",sParams, new File(this.sWorkDir));
		this.startOutReader();
		this.startErrReader();
		this.flushError();
		OutputStreamWriter osw=new OutputStreamWriter(new BufferedOutputStream(pSicstus.getOutputStream()), "UTF-8");
		System.out.println("Enconding is "+osw.getEncoding());
		//pwIn=new PrintWriter(new OutputStreamWriter(new BufferedOutputStream(pSicstus.getOutputStream())), true);
		pwIn=new PrintWriter(osw, true);
	}

	public synchronized boolean executeQuery(String sQuery)
	{
		String sCommand = sQuery + System.getProperty("line.separator");
		try
		{
			System.out.println("Executing "+sCommand);
			//pSicstus.getOutputStream().write(sCommand.getBytes());
			//pSicstus.getOutputStream().flush();
			sCommand=sCommand.replace('\\','/');
			pwIn.println(sCommand);
			this.flushError();
		} catch (IOException e)
		{
			// TODO Put some error reporting or treatment here
			e.printStackTrace();
			return false;
		}

		this.notifyAll();
		return true;
	}

	private void startOutReader()
	{
		brOut=new BufferedReader(new InputStreamReader(pSicstus.getInputStream()));
		tOutReader = new Thread(this,"Out Reader");
		tOutReader.setDaemon(true);
		//tOutReader.setPriority(Thread.MAX_PRIORITY);
		tOutReader.start();
	}

	private void startErrReader()
	{
		brErr=new BufferedReader(new InputStreamReader(pSicstus.getErrorStream()));
		tErrReader = new Thread(this,"Error Reader");
		tErrReader.setDaemon(true);
		//tErrReader.setPriority(Thread.MAX_PRIORITY);
		tErrReader.start();
	}

	public synchronized void halt() throws InterruptedException
	{
		this.executeQuery("halt.");
		this.bQuit = true;
		this.pSicstus.waitFor();
		this.pSicstus.destroy();
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public synchronized void run()
	//public void run()
	{
		try
		{
			while (Thread.currentThread() == tOutReader)
			{
				//while (brOut.ready())
				while (pSicstus.getInputStream().available() != 0)
				{
					//System.out.print("read ");
					//String input = this.readLine(bisOut);
					while(brOut.ready())
					{
						String input = brOut.readLine();
						System.out.println(input);
						//char c=(char) brOut.read();
						//System.out.print(c);
					}
					

					//posSystemInWriter.write(" \n\r\t".getBytes());
				}
				if (bQuit)
					return;
				try
				{
					//this.notifyAll();
					this.wait(100);
				} catch (InterruptedException ie)
				{
					ie.printStackTrace();
				}
			}
			
			while (Thread.currentThread() == tErrReader)
			{
				//while (bisErr.ready())
				while (pSicstus.getErrorStream().available() != 0)
				{
					//System.out.println("Reading error");
					//System.out.print("read ");
					//String input = this.readLine(bisErr);
					
					while(brErr.ready())
					{
						String input=brErr.readLine();
						System.err.println(input);
						//char c=(char) pSicstus.getErrorStream().read();
						//System.err.print(c);
					}
				}
				if (bQuit)
					return;
				try
				{
					this.wait(100);
					//this.wait();
				} catch (InterruptedException ie)
				{
					ie.printStackTrace();
				}
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	protected String readLine(InputStream in) throws IOException
	{
		String sInput = "";
		do
		{
			int available = in.available();
			if (available == 0)
				break;
			byte b[] = new byte[available];
			in.read(b);
			sInput += new String(b, 0, b.length);
		} while (!sInput.endsWith("\n") && !sInput.endsWith("\r\n") && !bQuit);
		return sInput;
	}
	
	protected void flushError() throws IOException
	{
		String sCommand="flush_output(user_error)."+System.getProperty("line.separator");
		pSicstus.getOutputStream().write(sCommand.getBytes());
		pSicstus.getOutputStream().flush();
	}
	
	public void finalize()
	{
		try
		{
			this.halt();
		} catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}
}
