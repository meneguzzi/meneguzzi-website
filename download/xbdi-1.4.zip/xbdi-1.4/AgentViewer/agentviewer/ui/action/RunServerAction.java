/*
 * Created on 12/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.action;

import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.ImageIcon;

import agentviewer.config.AgentViewerConfiguration;
import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RunServerAction extends AgentViewerAction
{

	/**
	 * @param avKernel
	 */
	public RunServerAction(AgentViewerKernel avKernel)
	{
		super(avKernel);
		this.init();
	}

	private void init()
	{
		this.putValue(Action.NAME, "Run Server");
		this.putValue(Action.SHORT_DESCRIPTION, "Runs XBDI kernel receiving sensor input via a Server Socket");
		ImageIcon icon =
			new ImageIcon(getClass().getResource("/toolbarButtonGraphics/development/Host24.gif"));
		this.putValue(Action.SMALL_ICON, icon);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			String sPort =
				avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_PORT_PROPERTY);
			if (sPort != null)
				sPort = "6666";
			int iPort = Integer.parseInt(sPort);

			avKernel.getXBDIStarter().startServer(iPort);

			System.out.println("Server started");

			super.actionPerformed(e);
		} catch (Exception ex)
		{
			ex.printStackTrace();
		}

	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		super.update(avcSender);
	}

}
