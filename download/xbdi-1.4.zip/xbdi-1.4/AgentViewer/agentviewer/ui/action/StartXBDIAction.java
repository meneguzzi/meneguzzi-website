/*
 * Created on 12/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.action;

import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.ImageIcon;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class StartXBDIAction extends AgentViewerAction
{
	/**
	 * @param avKernel
	 */
	public StartXBDIAction(AgentViewerKernel avKernel)
	{
		super(avKernel);
		this.init();
	}
	
	private void init()
	{
		this.putValue(Action.NAME, "Start");
		this.putValue(Action.SHORT_DESCRIPTION, "Starts the XBDI kernel");
		ImageIcon icon=new ImageIcon(getClass().getResource("/toolbarButtonGraphics/media/Play24.gif"));
		this.putValue(Action.SMALL_ICON, icon);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			avKernel.getXBDIStarter().startUp();
			if (this.getValue(Action.NAME).equals("Start"))
			{
				this.putValue(Action.NAME, "Restart");
				this.putValue(Action.SHORT_DESCRIPTION, "Restarts the XBDI kernel");
				//jbLoadAgent.setEnabled(true);
				//jbRunCoreo.setEnabled(true);
				//jbRunQuery.setEnabled(true);
			}else
			{
				this.putValue(Action.NAME, "Start");
				this.putValue(Action.SHORT_DESCRIPTION, "Starts the XBDI kernel");
			}
			
			//Then notity the rest of the interface that we have connected
			//super.actionPerformed(e);
			if(this.avMediator!=null)
				this.avMediator.componentChanged(this);
		} catch (Exception ex)
		{
			ex.printStackTrace();
			System.err.println("Error Starting Up XBDI: " + ex.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		super.update(avcSender);
	}

}
