/*
 * Created on 12/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.action;

import java.awt.event.ActionEvent;

import javax.swing.Action;
import javax.swing.ImageIcon;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class StopServerAction extends AgentViewerAction
{

	/**
	 * @param avKernel
	 */
	public StopServerAction(AgentViewerKernel avKernel)
	{
		super(avKernel);
		this.init();
	}

	private void init()
	{
		this.putValue(Action.NAME, "Stop Server");
		this.putValue(Action.SHORT_DESCRIPTION, "Stops the XBDI kernel");
		ImageIcon icon =
			new ImageIcon(getClass().getResource("/toolbarButtonGraphics/media/Stop24.gif"));
		this.putValue(Action.SMALL_ICON, icon);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		avKernel.getXBDIStarter().stopServer();
		System.out.println("Server stopped");
		super.actionPerformed(e);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		super.update(avcSender);
	}

}
