/*
 * Created on 25/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.ui.action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.AgentViewerMediator;

/**
 * @author felipe
 */
public class AgentViewerAction extends AbstractAction implements AgentViewerComponent
{
	protected AgentViewerKernel avKernel=null;
	protected AgentViewerMediator avMediator=null;
	
	public AgentViewerAction(AgentViewerKernel avKernel)
	{
		this.avKernel=avKernel;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		// if an action has reached here, we have a problem
		if(avMediator!=null)
			avMediator.componentChanged(this);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		this.avMediator=avMediator;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// By defautlt do nothing		
	}

}
