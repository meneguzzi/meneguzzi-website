/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.window;

import javax.swing.JInternalFrame;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.AgentViewerMediator;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class AgentViewerWindow extends JInternalFrame implements AgentViewerComponent
{
	protected AgentViewerKernel avKernel;
	protected AgentViewerMediator avMediator;

	public AgentViewerWindow(String sWindowName, AgentViewerKernel avKernel)
	{
		super(sWindowName);
		this.avKernel = avKernel;
	}
	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		this.avMediator=avMediator;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// By default do nothing
	}

}
