/*
 * Created on 01/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.filefilter;

import java.io.File;

import javax.swing.filechooser.FileFilter;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AllFileChooser extends FileFilter
{
	public static String DESCRIPTION="All Files (*.*)";
	/* (non-Javadoc)
	 * @see javax.swing.filechooser.FileFilter#accept(java.io.File)
	 */
	public boolean accept(File arg0)
	{
		return true;
	}

	/* (non-Javadoc)
	 * @see javax.swing.filechooser.FileFilter#getDescription()
	 */
	public String getDescription()
	{
		return AllFileChooser.DESCRIPTION;
	}

}
