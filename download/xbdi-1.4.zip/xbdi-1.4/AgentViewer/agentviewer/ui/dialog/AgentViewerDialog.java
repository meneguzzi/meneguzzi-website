/*
 * Created on 12/10/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.dialog;

import java.awt.Frame;
import java.awt.HeadlessException;

import javax.swing.JDialog;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.AgentViewerMediator;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class AgentViewerDialog extends JDialog implements AgentViewerComponent
{
	protected AgentViewerKernel avKernel;
	protected AgentViewerMediator avMediator;
	

	/**
	 * @param owner
	 * @throws java.awt.HeadlessException
	 */
	public AgentViewerDialog(AgentViewerKernel avKernel, Frame owner) throws HeadlessException
	{
		super(owner);
		this.avKernel=avKernel;
	}

	/**
	 * @param owner
	 * @param modal
	 * @throws java.awt.HeadlessException
	 */
	public AgentViewerDialog(AgentViewerKernel avKernel, Frame owner, boolean modal) throws HeadlessException
	{
		super(owner, modal);
		this.avKernel=avKernel;
	}

	/**
	 * @param owner
	 * @param title
	 * @throws java.awt.HeadlessException
	 */
	public AgentViewerDialog(AgentViewerKernel avKernel, Frame owner, String title) throws HeadlessException
	{
		super(owner, title);
		this.avKernel=avKernel;
	}

	/**
	 * @param owner
	 * @param title
	 * @param modal
	 * @throws java.awt.HeadlessException
	 */
	public AgentViewerDialog(AgentViewerKernel avKernel, Frame owner, String title, boolean modal) throws HeadlessException
	{
		super(owner, title, modal);
		this.avKernel=avKernel;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		this.avMediator=avMediator;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// By default, do nothing
	}

}
