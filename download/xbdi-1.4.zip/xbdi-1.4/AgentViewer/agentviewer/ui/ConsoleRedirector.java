/*
 * Created on 30/04/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ConsoleRedirector extends JTextArea implements Runnable
{
	boolean bRedirected;

	private PrintStream psDefaultOut;
	private PrintStream psDefaultErr;
	private InputStream isDefaultIn;

	protected PrintStream psRedirectedOut;
	protected PrintStream psRedirectedErr;
	protected InputStream isRedirectedIn;

	protected PipedInputStream pisSystemOutReader;
	protected PipedOutputStream posSystemOutWriter;

	protected PipedInputStream pisSystemErrReader;
	protected PipedOutputStream posSystemErrWriter;

	protected PipedInputStream pisSystemInReader;
	protected PipedOutputStream posSystemInWriter;

	protected Thread tOutReader;
	protected Thread tErrReader;

	private boolean bQuit;
	
	protected JPopupMenu jpmPopup;

	public ConsoleRedirector() throws IOException
	{
		this.init();
	}

	private void init() throws IOException
	{
		this.bRedirected = false;
		bQuit = false;
		this.setEditable(false);
		
		jpmPopup = new JConsolePopupMenu();
		
		MouseListener ml= new PopupMouseAdapter();
		this.addMouseListener(ml);
		//this.redirectConsole();
	}

	public void redirectConsole() throws IOException
	{
		if (bRedirected)
			return;

		this.psDefaultErr = System.err;
		this.psDefaultOut = System.out;
		this.isDefaultIn = System.in;
		this.bRedirected = true;

		pisSystemOutReader = new PipedInputStream();
		posSystemOutWriter = new PipedOutputStream(pisSystemOutReader);
		System.setOut(new PrintStream(posSystemOutWriter));

		this.startOutReader();

		pisSystemErrReader = new PipedInputStream();
		posSystemErrWriter = new PipedOutputStream(pisSystemErrReader);
		System.setErr(new PrintStream(posSystemErrWriter));

		this.startErrReader();

		pisSystemInReader = new PipedInputStream();
		posSystemInWriter = new PipedOutputStream(pisSystemInReader);
		//System.setIn(pisSystemInReader);

		this.bRedirected = true;
	}

	private void startOutReader()
	{
		tOutReader = new Thread(this, "Console Out Reader");
		tOutReader.setDaemon(true);
		tOutReader.start();
	}

	private void startErrReader()
	{
		tErrReader = new Thread(this, "Console Error Reader");
		tErrReader.setDaemon(true);
		tErrReader.start();
	}

	public void restoreConsole()
	{
		this.bRedirected = false;
		System.setErr(psDefaultErr);
		System.setOut(psDefaultOut);
		//System.setIn(isDefaultIn);

		bQuit = true;
	}
	
	public void halt()
	{
		restoreConsole();
		this.bQuit=true;
	}

	public void finalize()
	{
		restoreConsole();
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public synchronized void run()
	{
		try
		{
			while (Thread.currentThread() == tOutReader)
			{
				try
				{
					this.wait(100);
				} catch (InterruptedException ie)
				{
				}
				if (pisSystemOutReader.available() != 0)
				{
					String input = this.readLine(pisSystemOutReader);
					append(input);
					this.setCaretPosition(this.getText().length()-1);
					//posSystemInWriter.write(" \n\r\t".getBytes());
				}
				if (bQuit)
					return;
			}

			while (Thread.currentThread() == tErrReader)
			{
				try
				{
					this.wait(100);
				} catch (InterruptedException ie)
				{
				}
				if (pisSystemErrReader.available() != 0)
				{
					String input = this.readLine(pisSystemErrReader);
					append(input);
					this.setCaretPosition(this.getText().length()-1);
				}
				if (bQuit)
					return;
			}
		} catch (Exception e)
		{
			append("\nConsole reports an Internal error.");
			append("The error is: " + e);
		}

	}

	protected String readLine(PipedInputStream pin) throws IOException
	{
		String sInput = "";
		do
		{
			int available = pin.available();
			if (available == 0)
				break;
			byte b[] = new byte[available];
			pin.read(b);
			sInput += new String(b, 0, b.length);
		} while (!sInput.endsWith("\n") && !sInput.endsWith("\r\n") && !bQuit);
		return sInput;
	}
	
	/*class PopupConsoleListener implements PopupMenuListener {
		public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
			System.out.println("Popup menu will be visible!");
		}
		public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
			System.out.println("Popup menu will be invisible!");
		}
		public void popupMenuCanceled(PopupMenuEvent e) {
			System.out.println("Popup menu is hidden!");
		}
	}*/
	
	private class JConsolePopupMenu extends JPopupMenu
	{
		public JConsolePopupMenu()
		{
			JMenuItem jmiClear=new JMenuItem("Clear");
			ActionListener alClear=new ActionListener(){
				public void actionPerformed(ActionEvent arg0)
				{
					ConsoleRedirector.this.setText("");
				}
			};
			jmiClear.addActionListener(alClear);
			this.add(jmiClear);
		}
	}

	
	private class PopupMouseAdapter extends MouseAdapter
	{
		public void mousePressed(MouseEvent e) { checkPopup(e); }
		public void mouseClicked(MouseEvent e) { checkPopup(e); }
		public void mouseReleased(MouseEvent e) { checkPopup(e); }
 
		private void checkPopup(MouseEvent e) {
			if (e.isPopupTrigger(  )) {
				jpmPopup.show(ConsoleRedirector.this, e.getX(  ), e.getY(  ));
			}
		}
	}

}
