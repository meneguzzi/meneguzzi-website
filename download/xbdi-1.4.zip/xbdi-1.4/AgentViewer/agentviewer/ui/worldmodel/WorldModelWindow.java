/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.worldmodel;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.AgentViewerMediator;
import agentviewer.ui.window.AgentViewerWindow;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WorldModelWindow extends AgentViewerWindow
{
	protected WorldModelViewer wmPanel;
	
	public WorldModelWindow(AgentViewerKernel avKernel)
	{
		super("World Model", avKernel);
		this.init();
	}
	
	private void init()
	{
		wmPanel=new WorldModelViewer(this.avKernel);
		this.getContentPane().add(wmPanel);
		
		this.setResizable(true);
		this.setIconifiable(true);
		this.setVisible(true);
		this.setSize(500, 200);
		this.setLocation(10, 200);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		// TODO Auto-generated method stub
		
	}
}
