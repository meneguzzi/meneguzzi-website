/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.worldmodel;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;

import agentviewer.config.AgentViewerConfiguration;
import agentviewer.parser.Parser;
import agentviewer.parser.elements.ConcretePredicate;
import agentviewer.parser.elements.ConcreteTerm;
import agentviewer.parser.elements.Predicate;
import agentviewer.parser.elements.PrologList;
import agentviewer.parser.elements.Term;
import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerMediator;
import agentviewer.ui.AgentViewerPanel;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.filefilter.TextFileFilter;
import agentviewer.worldmodel.WorldModel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class WorldModelViewer extends AgentViewerPanel
{
	protected JPanel jpNorth;

	protected JList jlWorldModel;
	protected DefaultListModel dlmParsedData;
	protected JButton jbReadWorldModel;

	protected JButton jbSendWorld;
	protected JButton jbAddPredicate;

	protected JLabel jlCurrentTime;
	protected JTextField jtfCurrentTime;
	protected JButton jbSetTime;

	protected JWorldModelPopupMenu jwPopupMenu;

	public WorldModelViewer(AgentViewerKernel avKernel)
	{
		super(avKernel);
		this.init();
	}

	private void init()
	{
		this.setLayout(new BorderLayout());

		if (avKernel.getWorldModel() instanceof DefaultListModel)
		{
			dlmParsedData = (DefaultListModel) avKernel.getWorldModel();
		} else
		{
			dlmParsedData = new DefaultListModel();
		}

		jlWorldModel = new JList(dlmParsedData);
		jlWorldModel.setCellRenderer(new PredicateCellRenderer());
		JScrollPane jspWorldModel = new JScrollPane(jlWorldModel);

		jwPopupMenu = new JWorldModelPopupMenu();
		MouseAdapter maPopup = new PopupMouseAdapter();
		jlWorldModel.addMouseListener(maPopup);
		this.add(jspWorldModel, BorderLayout.CENTER);

		jbSendWorld = new JButton("Send World");
		jbSendWorld.setToolTipText("Sends the world model to the agent.");
		ActionListener alSendWorld = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				PrologList plWorld = createCoreo();
				String s = plWorld.toString() + ".";
				System.out.println("I will send " + s);

				if (avKernel.getXBDIClientInterface().isConnected())
					avKernel.getXBDIClientInterface().sendSensorInput(s);

				updateWorldView();
			}
		};
		jbSendWorld.addActionListener(alSendWorld);

		jbReadWorldModel = new JButton("Read Model");
		jbReadWorldModel.setToolTipText("Tries to infer a world model from a STRIPS problem.");
		ActionListener alReadWorldModel = new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				String sStartdir = avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_PATH_PROPERTY);
				if (sStartdir == null)
					sStartdir = System.getProperty("user.dir");

				assert sStartdir != null;

				JFileChooser fc = new JFileChooser(sStartdir);
				FileFilter ffText = new TextFileFilter();
				//fc.addChoosableFileFilter(ffAgent);
				fc.setFileFilter(ffText);
				//fc.addChoosableFileFilter(new AllFileChooser());

				int returnVal = fc.showOpenDialog(jpThis);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					/*System.out.println(
						"You chose to open this file: "
							+ fc.getSelectedFile().getName());*/
					try
					{
						File fWorldModel = fc.getSelectedFile();
						Parser parser = avKernel.getParser();
						if (parser.parse(fWorldModel))
						{
							avKernel.getWorldModel().updateWorld(parser.getStart());
							avKernel.getWorldModel().setOperators(parser.getOperators());
							//System.out.println("Operators");
							//for(Iterator i=parser.getOperators().iterator();i.hasNext();)
							//	System.out.println(i.next());
							updateWorldView();
						} else
						{
							JOptionPane.showMessageDialog(
								jpThis,
								"Could not infer a world model from file",
								"Parse Error",
								JOptionPane.ERROR_MESSAGE);
						}
					} catch (IOException e)
					{
						JOptionPane.showMessageDialog(
							jpThis,
							e,
							e.getClass().getName(),
							JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					} catch (Exception e)
					{
						JOptionPane.showMessageDialog(
							jpThis,
							e,
							e.getClass().getName(),
							JOptionPane.ERROR_MESSAGE);
						e.printStackTrace();
					}

				}

			}
		};
		jbReadWorldModel.addActionListener(alReadWorldModel);

		jbAddPredicate = new JButton("Add Predicate");
		jbAddPredicate.setToolTipText("Reads a predicate and updates the World Model with it.");
		ActionListener alAddPredicate = new ActionListener()
		{

			public void actionPerformed(ActionEvent e)
			{
				try
				{
					String s =
						JOptionPane.showInputDialog(
							jpThis,
							"Write a predicate",
							"Predicate Input",
							JOptionPane.QUESTION_MESSAGE);
					avKernel.getParser().parsePredicates(s);
					Vector v = avKernel.getParser().getPredicates();
					avKernel.getWorldModel().updateWorld(v);
				} catch (Exception e1)
				{
					JOptionPane.showMessageDialog(
							jpThis,
							e1.getMessage(),
							e1.getClass().getName(),
							JOptionPane.QUESTION_MESSAGE);
					e1.printStackTrace();
				}
			}
		};
		jbAddPredicate.addActionListener(alAddPredicate);

		jlCurrentTime = new JLabel("Time");
		jtfCurrentTime = new JTextField("" + avKernel.getWorldModel().getTime(), 4);
		jbSetTime = new JButton("Set");
		jbSetTime.setToolTipText("Sets the current time in the World Model.");
		ActionListener alSetTime = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				int iTime = Integer.parseInt(jtfCurrentTime.getText().trim());
				avKernel.getWorldModel().setTime(iTime);
			}
		};
		jbSetTime.addActionListener(alSetTime);

		jpNorth = new JPanel();
		jpNorth.setLayout(new FlowLayout());
		this.add(jpNorth, BorderLayout.NORTH);

		jpNorth.add(jbSendWorld);
		jpNorth.add(jbAddPredicate);
		jpNorth.add(jbReadWorldModel);
		jpNorth.add(new JSeparator(JSeparator.VERTICAL));
		jpNorth.add(jlCurrentTime);
		jpNorth.add(jtfCurrentTime);
		jpNorth.add(jbSetTime);
	}

	protected PrologList createCoreo()
	{
		Vector v = new Vector(avKernel.getWorldModel().getWorldState());

		Term tTime = new ConcreteTerm("" + avKernel.getWorldModel().getTime());
		for (int i = 0; i < v.size(); i++)
		{
			Term t = (Term) v.get(i);
			Vector vParam = new Vector();
			vParam.add(t);
			vParam.add(tTime);
			Predicate pNew = new ConcretePredicate("sense", vParam);
			v.set(i, pNew);
		}

		tTime = new ConcreteTerm("" + avKernel.getWorldModel().updateTime());
		Vector vParam = new Vector();
		vParam.add(tTime);
		Predicate pTime = new ConcretePredicate("current_time", vParam);
		v.add(0, pTime);

		PrologList plWorld = new PrologList(v);

		return plWorld;
	}

	protected void updateWorldView()
	{
		this.jtfCurrentTime.setText("" + avKernel.getWorldModel().getTime());
		if (dlmParsedData instanceof WorldModel)
			return;
		dlmParsedData.removeAllElements();
		for (Iterator i = avKernel.getWorldModel().getWorldState().iterator(); i.hasNext();)
		{
			Object o = i.next();
			this.dlmParsedData.addElement(o);
		}
	}

	private class JWorldModelPopupMenu extends JPopupMenu
	{
		protected JMenuItem jmiPredicateName;
		protected JMenuItem jmiInvert;
		protected JMenuItem jmiRemove;
		protected Predicate pSelected = null;

		public JWorldModelPopupMenu()
		{
			jmiPredicateName = new JMenuItem("None");
			jmiPredicateName.setArmed(false);

			this.add(jmiPredicateName);
			this.add(new JPopupMenu.Separator());

			jmiInvert = new JMenuItem("Invert");
			ActionListener alInvert = new ActionListener()
			{
				public void actionPerformed(ActionEvent arg0)
				{
					if (pSelected != null)
					{
						for (int i = 0; i < jlWorldModel.getSelectedValues().length; i++)
						{
							pSelected = (Predicate) jlWorldModel.getSelectedValues()[i];
							pSelected = ((ConcretePredicate) pSelected).not();
							avKernel.getWorldModel().updateWorld(pSelected);
						}
						updateWorldView();
					}
				}
			};
			jmiInvert.addActionListener(alInvert);
			this.add(jmiInvert);

			jmiRemove = new JMenuItem("Remove");
			ActionListener alRemove = new ActionListener()
			{

				public void actionPerformed(ActionEvent e)
				{
					if (pSelected != null)
					{
						for (int i = 0; i < jlWorldModel.getSelectedValues().length; i++)
						{
							pSelected = (Predicate) jlWorldModel.getSelectedValues()[i];
							avKernel.getWorldModel().remove(pSelected);
						}
						updateWorldView();
					}
				}
			};
			jmiRemove.addActionListener(alRemove);
			this.add(jmiRemove);
		}

		public void getContext()
		{
			pSelected = (Predicate) jlWorldModel.getSelectedValue();

			if (pSelected == null)
			{
				this.jmiPredicateName.setText("None");
				this.jmiInvert.setEnabled(false);
				this.jmiRemove.setEnabled(false);
			} else
			{
				this.jmiPredicateName.setText(pSelected.toString());
				this.jmiInvert.setEnabled(true);
				this.jmiRemove.setEnabled(true);
			}
		}
	}

	private class PopupMouseAdapter extends MouseAdapter
	{
		public void mousePressed(MouseEvent e)
		{
			checkPopup(e);
		}
		public void mouseClicked(MouseEvent e)
		{
			checkPopup(e);
		}
		public void mouseReleased(MouseEvent e)
		{
			checkPopup(e);
		}

		private void checkPopup(MouseEvent e)
		{
			if (e.isPopupTrigger())
			{
				jwPopupMenu.getContext();
				jwPopupMenu.show(WorldModelViewer.this, e.getX(), e.getY());
			}
		}
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		// TODO Auto-generated method stub
		
	}
}
