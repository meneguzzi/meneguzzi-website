/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.worldmodel;

import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;

import agentviewer.parser.elements.Predicate;
import agentviewer.worldmodel.ConcreteWorldModel;
import agentviewer.worldmodel.WorldModel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class InterfaceWorldModel extends DefaultListModel implements WorldModel
{
	protected WorldModel wmWorld;

	public InterfaceWorldModel()
	{
		this.wmWorld = new ConcreteWorldModel();
	}
	
	public InterfaceWorldModel(WorldModel wmWorld)
	{
		this.wmWorld=wmWorld;
		this.updateInterface();
	}

	public InterfaceWorldModel(Vector vStart) throws Exception
	{
		wmWorld = new ConcreteWorldModel(vStart);
	}

	public InterfaceWorldModel(Vector vStart, Vector vOperators) throws Exception
	{
		wmWorld = new ConcreteWorldModel(vStart, vOperators);
	}
	
	private void updateInterface()
	{
		this.removeAllElements();
		Vector v=this.getWorldState();
		for(Iterator i=v.iterator();i.hasNext();)
		{
			Object o=i.next();
			this.addElement(o);
		}
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getTruth(agentviewer.parser.elements.Predicate)
	 */
	public boolean getTruth(Predicate pred)
	{
		return this.wmWorld.getTruth(pred);
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getTruth(java.util.Vector)
	 */
	public boolean getTruth(Vector v)
	{
		return this.wmWorld.getTruth(v);
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#setOperators(java.util.Vector)
	 */
	public void setOperators(Vector v)
	{
		wmWorld.setOperators(v);
		this.updateInterface();
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateWorld(java.util.Vector)
	 */
	public void updateWorld(Vector v) throws Exception
	{
		wmWorld.updateWorld(v);
		this.updateInterface();
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateWorld(agentviewer.parser.elements.Predicate)
	 */
	public void updateWorld(Predicate pred)
	{
		wmWorld.updateWorld(pred);
		this.updateInterface();
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#remove(agentviewer.parser.elements.Predicate)
	 */
	public Predicate remove(Predicate pred)
	{
		pred=wmWorld.remove(pred);
		if(pred!=null)
			this.updateInterface();
		return pred;
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#applyAction(agentviewer.parser.elements.Predicate)
	 */
	public void applyAction(Predicate pAction) throws Exception
	{
		wmWorld.applyAction(pAction);
		this.updateInterface();
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#updateTime()
	 */
	public int updateTime()
	{
		return wmWorld.updateTime();
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#setTime(int)
	 */
	public void setTime(int iTime)
	{
		wmWorld.setTime(iTime);
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getTime()
	 */
	public int getTime()
	{
		return wmWorld.getTime();
	}

	/* (non-Javadoc)
	 * @see agentviewer.worldmodel.WorldModel#getWorldState()
	 */
	public Vector getWorldState()
	{
		return wmWorld.getWorldState();
	}

}
