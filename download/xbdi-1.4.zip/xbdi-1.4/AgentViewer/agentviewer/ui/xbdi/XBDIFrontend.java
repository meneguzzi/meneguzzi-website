/*
 * Created on 01/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.xbdi;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JInternalFrame;

import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.AgentViewerMediator;
import agentviewer.ui.action.LoadAgentAction;
import agentviewer.ui.action.RunCoreographyAction;
import agentviewer.ui.action.RunQueryAction;
import agentviewer.ui.action.RunServerAction;
import agentviewer.ui.action.StartXBDIAction;
import agentviewer.ui.action.StopServerAction;
import agentviewer.ui.window.AgentViewerWindow;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class XBDIFrontend extends AgentViewerWindow implements AgentViewerMediator
{
	private JInternalFrame jifParent;

	protected JButton jbStart;

	protected JButton jbLoadAgent;
	protected JButton jbRunServer;
	protected JButton jbRunCoreo;
	protected JButton jbRunQuery;

	protected StartXBDIAction startXBDI;
	protected LoadAgentAction loadAgent;
	protected RunServerAction runServer;
	protected StopServerAction stopServer;
	protected RunCoreographyAction runCoreo;
	protected RunQueryAction runQuery;

	public XBDIFrontend(AgentViewerKernel avKernel)
	{
		super("XBDI Control", avKernel);

		jifParent = this;

		this.init();
	}

	public void init()
	{
		this.getContentPane().setLayout(new FlowLayout());

		startXBDI = new StartXBDIAction(avKernel);
		startXBDI.setMediator(this);

		loadAgent = new LoadAgentAction(avKernel);
		loadAgent.setMediator(this);

		runServer = new RunServerAction(avKernel);
		runServer.setMediator(this);

		stopServer = new StopServerAction(avKernel);
		stopServer.setMediator(this);

		runCoreo = new RunCoreographyAction(avKernel);
		runCoreo.setMediator(this);

		runQuery = new RunQueryAction(avKernel);
		runQuery.setMediator(this);

		jbStart = new JButton(startXBDI);
		jbLoadAgent = new JButton(loadAgent);
		jbRunServer = new JButton(runServer);
		jbRunCoreo = new JButton(runCoreo);
		jbRunQuery = new JButton(runQuery);

		this.getContentPane().add(jbStart);
		this.getContentPane().add(jbLoadAgent);
		this.getContentPane().add(jbRunServer);
		this.getContentPane().add(jbRunCoreo);
		this.getContentPane().add(jbRunQuery);

		this.setResizable(true);
		this.setIconifiable(true);
		this.setVisible(true);
		this.setSize(400, 120);
		this.setLocation(10, 10);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		startXBDI.update(avcSender);
		loadAgent.update(avcSender);
		runServer.update(avcSender);
		stopServer.update(avcSender);
		runCoreo.update(avcSender);
		runQuery.update(avcSender);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		super.setMediator(avMediator);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerMediator#componentChanged(agentviewer.ui.AgentViewerComponent)
	 */
	public void componentChanged(AgentViewerComponent avComponent)
	{
		if (avComponent == this.runServer)
			this.jbRunServer.setAction(stopServer);
		if (avComponent == this.stopServer)
			this.jbRunServer.setAction(runServer);

		startXBDI.update(avComponent);
		loadAgent.update(avComponent);
		runServer.update(avComponent);
		stopServer.update(avComponent);
		runCoreo.update(avComponent);
		runQuery.update(avComponent);
	}

}
