/*
 * Created on 01/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.xbdi;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import agentviewer.parser.Parser;
import agentviewer.parser.elements.Predicate;
import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerMediator;
import agentviewer.ui.AgentViewerPanel;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.xbdi.elements.ConcreteIntentionFactory;
import agentviewer.xbdi.elements.IntentionFactory;
import agentviewer.xbdi.elements.RelativeIntention;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class XBDIActuatorFrontend extends AgentViewerPanel implements Runnable
{
	/** The text area where raw actuator output is displayed*/
	protected JTextArea jtaResponse;
	
	/** The list where parsed actuator data is displayed*/
	protected JList jlIntentionList;
	protected DefaultListModel dlmParsedData;
	protected Parser parser;
	protected int iParseCaret=0;
	protected IntentionFactory iFactory;
	
	/** The popup menu responsible for executing actions within the world model*/
	protected JIntentionPopupMenu jiPopupMenu;

	/** The tabbed pane where the multiple actuator views are placed*/
	protected JTabbedPane jtbViews;

	private Thread tReceiver;

	private boolean bQuit;

	public XBDIActuatorFrontend(AgentViewerKernel avKernel)
	{
		super(avKernel);
		bQuit = false;
		dlmParsedData=new DefaultListModel();
		iFactory=new ConcreteIntentionFactory();

		this.init();
		this.restartData();
	}

	private void init()
	{
		this.setLayout(new BorderLayout());
		
		//The tabbed pane where input will be displayed
		this.jtbViews=new JTabbedPane();
		this.add(jtbViews, BorderLayout.CENTER);
		
		//The list where the parsed intentions are placed
		this.jlIntentionList = new JList(dlmParsedData);
		this.jlIntentionList.setCellRenderer(new IntentionCellRenderer());
		JScrollPane jspIntentions=new JScrollPane(jlIntentionList);
		//jtbViews.add("Intentions", jlIntentionList);
		jtbViews.add("Intentions", jspIntentions);
		
		//Puts the popup menu in the list
		jiPopupMenu=new JIntentionPopupMenu();
		MouseAdapter maIntention=new PopupMouseAdapter();
		jlIntentionList.addMouseListener(maIntention);
		//this.addMouseListener(maIntention);
		
		
		
		//The raw text component
		jtaResponse = new JTextArea();
		jtaResponse.setEditable(false);
		jtaResponse.setLineWrap(true);
		jtaResponse.setWrapStyleWord(true);
		JScrollPane jspResponse = new JScrollPane(jtaResponse);
		//this.add(jspResponse, BorderLayout.CENTER);
		jtbViews.add("Raw",jtaResponse);
		
		
		
		//this.add(jspResponse);
	}
	
	protected void restartData()
	{
		this.parser=new Parser();
		this.jtaResponse.setText("");
		//this.jlIntentionList.removeAll();
		this.dlmParsedData.removeAllElements();
		iParseCaret=0;
	}

	protected void updateList()
	{
		String sParse=jtaResponse.getText();
		int iParseTo=sParse.length();//Math.max(iParseCaret,sParse.indexOf('\n'));
		if(iParseTo<=iParseCaret)
			return;
		sParse=sParse.substring(this.iParseCaret,iParseTo);
		
		System.out.println("Parsing " + sParse);
		sParse = sParse.substring(1, sParse.length() - 1);
		
		if (parser.parsePredicates(sParse))
		{
			Vector vPredicates = parser.getPredicates();
			for (Iterator i = vPredicates.iterator(); i.hasNext();)
			{
				Predicate pred = (Predicate)i.next();
				if(iFactory.isIntention(pred))
					try
					{
						pred=iFactory.createIntention(pred);
					} catch (Exception e)
					{
						//Again it is impossible for this to happen
						e.printStackTrace();
					}
				//jtaResponse.append(pred.toString() + "\n");
				this.dlmParsedData.addElement(pred);
				
			}
			this.iParseCaret=iParseTo;
		}
	}

	public synchronized void start()
	{
		this.restartData();
		
		System.out.print("Starting Actuator Listener...");
		tReceiver = new Thread(this, "Actuator Output Reader");
		tReceiver.setDaemon(true);
		bQuit = false;
		tReceiver.start();
	}

	public synchronized void halt()
	{
		System.out.print("Stopping Actuator Listener...");
		bQuit = true;
	}

	public void finalize()
	{
		halt();
	}

	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public synchronized void run()
	{
		System.out.println("Done");
		while (Thread.currentThread() == tReceiver)
		{
			try
			{
				try
				{
					this.wait(100);
				} catch (InterruptedException e1)
				{ /*e1.printStackTrace();*/
				}
				if (avKernel.getXBDIClientInterface().isConnected())
				{
					String sRes = avKernel.getXBDIClientInterface().getActuatorOutput();
					if (sRes != null)
					{
						//SimplePrologList plCommands=new SimplePrologList(sRes);
						//jtaResponse.append(plCommands.toString());
						jtaResponse.append(sRes);
						jtaResponse.setCaretPosition(jtaResponse.getText().length() - 1);
						this.updateList();
					}
					//String sRes[]=xClient.getActuatorOutputCommands();
					//if(sRes!=null)
					//{
					//	for(int i=0; i<sRes.length; i++)
					//		jtaResponse.append(sRes[i]+"\n");
					//}
				} else
				{
					try
					{
						this.wait(500);
					} catch (InterruptedException e1)
					{ /*e1.printStackTrace();*/
					}
				}

				if (bQuit)
				{
					System.out.println("Done");
					return;
				}
			} catch (IOException e)
			{
				System.out.println(e);
				//e.printStackTrace();
			}
		}
	}

	private class JIntentionPopupMenu extends JPopupMenu
	{
		protected JMenuItem jmiIntentionName;
		protected JMenuItem jmiExecute;
		protected Predicate pSelected=null;
		
		public JIntentionPopupMenu()
		{
			jmiIntentionName=new JMenuItem("None");
			jmiIntentionName.setArmed(false);

			this.add(jmiIntentionName);
			this.add(new JPopupMenu.Separator());
			
			jmiExecute=new JMenuItem("Execute");
			ActionListener alExecute=new ActionListener(){
				public void actionPerformed(ActionEvent arg0)
				{
					if(pSelected instanceof RelativeIntention)
					{
						Predicate p=((RelativeIntention)pSelected).getAction();
						try
						{
							avKernel.getWorldModel().applyAction(p);
						} catch (Exception e)
						{
							// TODO Do some real error treatment here
							e.printStackTrace();
						}
					}
				}
			};
			jmiExecute.addActionListener(alExecute);
			this.add(jmiExecute);
		}
		
		public void getContext()
		{
			pSelected=(Predicate)jlIntentionList.getSelectedValue();
			
			if(pSelected==null)
			{
				this.jmiIntentionName.setText("None");
				this.jmiExecute.setEnabled(false);
			}
			else
			{
				this.jmiIntentionName.setText(pSelected.toString());
				if(pSelected instanceof RelativeIntention)
				{
					RelativeIntention ri=(RelativeIntention)pSelected;
					this.jmiExecute.setEnabled(true);
					this.jmiExecute.setToolTipText("Execute "+ri.getAction());
				}
				else
					this.jmiExecute.setEnabled(false);
			}
		}
	}

	
	private class PopupMouseAdapter extends MouseAdapter
	{
		public void mousePressed(MouseEvent e) { checkPopup(e); }
		public void mouseClicked(MouseEvent e) { checkPopup(e); }
		public void mouseReleased(MouseEvent e) { checkPopup(e); }
 
		private void checkPopup(MouseEvent e) {
			if (e.isPopupTrigger(  )) {
				jiPopupMenu.getContext();
				jiPopupMenu.show(XBDIActuatorFrontend.this, e.getX(  ), e.getY(  ));				
			}
		}
	}


	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		// TODO Auto-generated method stub
		
	}
}
