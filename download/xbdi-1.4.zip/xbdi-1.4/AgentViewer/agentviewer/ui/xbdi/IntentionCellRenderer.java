/*
 * Created on 20/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui.xbdi;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import agentviewer.parser.elements.Predicate;
import agentviewer.xbdi.elements.PrimaryIntention;
import agentviewer.xbdi.elements.RelativeIntention;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class IntentionCellRenderer extends JLabel implements ListCellRenderer
{
	// This is the only method defined by ListCellRenderer.
	// We just reconfigure the JLabel each time we're called.

	public Component getListCellRendererComponent(JList list, Object value, // value to display
	int index, // cell index
	boolean isSelected, // is the cell selected
	boolean cellHasFocus) // the list and the cell have the focus
	{
		if (isSelected)
		{
			setBackground(list.getSelectionBackground());
			setForeground(list.getSelectionForeground());
		} else
		{
			setBackground(list.getBackground());
			setForeground(list.getForeground());
		}
		
		String sText = null;
				
		Predicate p=(Predicate)value;
		if(PrimaryIntention.isPrimaryIntention(p))
		{
			setForeground(Color.BLUE);
			PrimaryIntention pi=(PrimaryIntention) value;
			sText=pi.getProperty().toString();
		}else if(RelativeIntention.isRelativeIntention(p))
		{
			setForeground(Color.RED);
			RelativeIntention ri=(RelativeIntention) value;
			sText=ri.getProperty().toString();
		}else 
		{
			sText=value.toString();
		}
		
		setText(sText);
		
		setEnabled(list.isEnabled());
		setFont(list.getFont());
		setOpaque(true);
		return this;
	}

}
