/*
 * Created on 01/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.xbdi;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;

import agentviewer.config.AgentViewerConfiguration;
import agentviewer.parser.Parser;
import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.AgentViewerMediator;
import agentviewer.ui.window.AgentViewerWindow;
import agentviewer.xbdi.net.XBDISocket;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class XBDISocketFrontend extends AgentViewerWindow
{
	protected JInternalFrame jifActuatorConsole;
	protected JInternalFrame jifSensorConsole;

	protected XBDIActuatorFrontend xActuator;
	protected XBDISensorFrontend xSensor;

	protected JButton jbConnect;
	protected JLabel jlHost;
	protected JLabel jlPort;

	protected XBDISocket xClient;

	public XBDISocketFrontend(AgentViewerKernel avKernel)
	{
		super("XBDI Client", avKernel);

		Properties pOptions = avKernel.getOptions();

		String sHost = pOptions.getProperty(AgentViewerConfiguration.XBDI_CLIENT_HOST_PROPERTY);
		int iPort = Integer.parseInt(pOptions.getProperty(AgentViewerConfiguration.XBDI_CLIENT_PORT_PROPERTY));

		try
		{
			xClient = new XBDISocket(sHost, iPort);
			avKernel.setXBDIClientInterface(xClient);
		} catch (UnknownHostException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}

		this.init();
	}

	private void init()
	{
		jlHost = new JLabel(avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_CLIENT_HOST_PROPERTY));
		jlPort = new JLabel(avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_CLIENT_PORT_PROPERTY));

		jbConnect = new JButton("Connect");
		jbConnect.setToolTipText("Connects to an XBDI Kernel");
		ActionListener alConnect = new ActionListener()
		{

			public void actionPerformed(ActionEvent arg0)
			{
				try
				{
					if(xSensor==null || xActuator==null)
						initChildWindows();
					
					if (jbConnect.getText().equals("Connect"))
					{
						System.out.print("Trying to connect to "+xClient.getHost()+":"+xClient.getPort()+"...");
						xClient.connect();
						System.out.println("Connected");
						jbConnect.setText("Disconnect");
						jbConnect.setToolTipText("Disconnects from the XBDI Kernel");
						jifActuatorConsole.setVisible(true);
						xActuator.start();
						
						boolean bSensor=Boolean.valueOf(avKernel.getOptions().getProperty(AgentViewerConfiguration.SENSOR_WINDOW_PROPERTY)).booleanValue();
						if(bSensor)
							jifSensorConsole.setVisible(true);
						try{
							String sPlanFile=avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_PATH_PROPERTY);
							sPlanFile+="/";
							sPlanFile+=avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_PLAN_FILE_PROPERTY);
							System.out.print("Trying to infer world model from "+sPlanFile+" ...");
							Parser parser=avKernel.getParser();
							parser.parse(new File(sPlanFile));
							avKernel.getWorldModel().updateWorld(parser.getStart());
							avKernel.getWorldModel().setOperators(parser.getOperators());
							System.out.println("Success");
						}catch(Exception e)
						{
							System.out.println("Failed '"+e.getMessage()+"'");
							e.printStackTrace();
						}
					} else
					{
						xClient.close();
						jbConnect.setText("Connect");
						jbConnect.setToolTipText("Connects to an XBDI Kernel");
						jifActuatorConsole.setVisible(false);
						xActuator.halt();
						jifSensorConsole.setVisible(false);
					}
					jlHost.setText(avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_CLIENT_HOST_PROPERTY));
					jlPort.setText(avKernel.getOptions().getProperty(AgentViewerConfiguration.XBDI_CLIENT_PORT_PROPERTY));
				} catch (UnknownHostException e)
				{
					e.printStackTrace();
				} catch (IOException e)
				{
					e.printStackTrace();
				}
			}
		};
		jbConnect.addActionListener(alConnect);

		this.getContentPane().setLayout(new FlowLayout());
		this.getContentPane().add(jbConnect);
		this.getContentPane().add(jlHost);
		this.getContentPane().add(jlPort);

		this.setResizable(true);
		this.setIconifiable(true);
		this.setVisible(true);
		this.setSize(300, 100);
		this.setLocation(10, 10);
	}

	private void initChildWindows()
	{
		jifActuatorConsole = new JInternalFrame("Actuator Output");
		//jifActuatorConsole.getContentPane().setLayout();
		xActuator = new XBDIActuatorFrontend(avKernel);
		jifActuatorConsole.getContentPane().add(xActuator);
		jifActuatorConsole.setResizable(true);
		jifActuatorConsole.setIconifiable(true);
		//jifActuatorConsole.setVisible(true);
		jifActuatorConsole.setSize(350, 600);
		jifActuatorConsole.setLocation(800, 10);

		this.getDesktopPane().add(jifActuatorConsole);

		jifSensorConsole = new JInternalFrame("Sensor Input");
		xSensor = new XBDISensorFrontend(avKernel);
		jifSensorConsole.getContentPane().add(xSensor);
		jifSensorConsole.setResizable(true);
		jifSensorConsole.setIconifiable(true);
		//jifSensorConsole.setVisible(true);
		jifSensorConsole.setSize(400, 600);
		jifSensorConsole.setLocation(10, 10);

		this.getDesktopPane().add(jifSensorConsole);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		// TODO Auto-generated method stub
		
	}
}
