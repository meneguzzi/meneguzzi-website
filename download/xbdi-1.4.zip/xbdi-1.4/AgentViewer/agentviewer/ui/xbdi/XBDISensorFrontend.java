/*
 * Created on 02/05/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.ui.xbdi;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileFilter;

import agentviewer.config.AgentViewerConfiguration;
import agentviewer.ui.AgentViewerComponent;
import agentviewer.ui.AgentViewerMediator;
import agentviewer.ui.AgentViewerPanel;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.filefilter.SenseFileFilter;
import agentviewer.xbdi.CoreographyHandler;

/**
 * @author felipe
 */
public class XBDISensorFrontend extends AgentViewerPanel
{
	protected CoreographyHandler crCoreo;
	
	protected JButton jbLoadCoreo;
	protected JButton jbSaveCoreo;
	//protected JButton jbSaveAsCoreo;
	protected JButton jbSendCoreo;
	protected JButton jbSendSelectedCoreo;
	
	protected JPanel jpButtons;
	protected JTextArea jtaCoreo;
	
	private JPanel jpParent;

	public XBDISensorFrontend(AgentViewerKernel avKernel)
	{
		super(avKernel);
		
		jpParent=this;
		
		crCoreo = new CoreographyHandler();
		
		this.init();
	}
	
	private void init()
	{
		jbLoadCoreo = new JButton("Load");
		jbLoadCoreo.setToolTipText("Loads a Coreography File");
		ActionListener alLoadCoreo = new ActionListener(){

			public void actionPerformed(ActionEvent arg0)
			{
				String sStartdir = avKernel.getOptions().getProperty(AgentViewerConfiguration.COREO_PATH_PROPERTY);
				if (sStartdir == null)
					sStartdir = System.getProperty("user.dir");

				assert sStartdir != null;

				JFileChooser fc = new JFileChooser(sStartdir);
				FileFilter ffCoreo = new SenseFileFilter();
				//fc.addChoosableFileFilter(ffAgent);
				fc.setFileFilter(ffCoreo);
				//fc.addChoosableFileFilter(new AllFileChooser());

				int returnVal = fc.showOpenDialog(jpParent);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					/*System.out.println(
						"You chose to open this file: "
							+ fc.getSelectedFile().getName());*/
					try
					{
						File fCoreo = fc.getSelectedFile();
						String sCoreo = crCoreo.readCoreography(fCoreo);
						jtaCoreo.setText(sCoreo);
					} catch (IOException e)
					{
						// TODO Deal with this differently
						e.printStackTrace();
					}

				}
				
			}
		};
		jbLoadCoreo.addActionListener(alLoadCoreo);
		
		jbSaveCoreo = new JButton("Save");
		jbSaveCoreo.setToolTipText("Saves the Coreography to a File");
		ActionListener alSaveCoreo = new ActionListener(){

			public void actionPerformed(ActionEvent arg0)
			{
				String sStartdir = avKernel.getOptions().getProperty(AgentViewerConfiguration.COREO_PATH_PROPERTY);
				if (sStartdir == null)
					sStartdir = System.getProperty("user.dir");

				assert sStartdir != null;

				JFileChooser fc = new JFileChooser(sStartdir);
				FileFilter ffCoreo = new SenseFileFilter();
				//fc.addChoosableFileFilter(ffAgent);
				fc.setFileFilter(ffCoreo);
				//fc.addChoosableFileFilter(new AllFileChooser());

				int returnVal = fc.showSaveDialog(jpParent);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					/*System.out.println(
						"You chose to open this file: "
							+ fc.getSelectedFile().getName());*/
					try
					{
						File fCoreo = fc.getSelectedFile();
						crCoreo.writeCoreography(fCoreo, jtaCoreo.getText());
					} catch (IOException e)
					{
						e.printStackTrace();
					}

				}
		
			}
		};
		jbSaveCoreo.addActionListener(alSaveCoreo);
		
		//jbSaveAsCoreo = new JButton("Save Coreo As");
		
		jbSendCoreo = new JButton("Send");
		jbSendCoreo.setToolTipText("Sends the Sensor Input File to XBDI");
		ActionListener alSendCoreo = new ActionListener(){

			public void actionPerformed(ActionEvent arg0)
			{
				avKernel.getXBDIClientInterface().sendSensorInput(jtaCoreo.getText());
		
			}
		};
		jbSendCoreo.addActionListener(alSendCoreo);
		
		jbSendSelectedCoreo = new JButton("Send Selected");
		jbSendSelectedCoreo.setToolTipText("Sends the Selected Sensor Text to XBDI");
		ActionListener alSendSelectedCoreo = new ActionListener(){

			public void actionPerformed(ActionEvent arg0)
			{
				avKernel.getXBDIClientInterface().sendSensorInput(jtaCoreo.getSelectedText());
		
			}
		};
		jbSendSelectedCoreo.addActionListener(alSendSelectedCoreo);
		
		
		this.setLayout(new BorderLayout());
		
		jpButtons = new JPanel();
		jpButtons.setLayout(new GridLayout(2,2));
		jpButtons.add(jbLoadCoreo);
		jpButtons.add(jbSaveCoreo);
		jpButtons.add(jbSendCoreo);
		jpButtons.add(jbSendSelectedCoreo);
		
		this.add(jpButtons, BorderLayout.NORTH);
		
		jtaCoreo = new JTextArea();
		JScrollPane jspCoreo = new JScrollPane(jtaCoreo);
		
		this.add(jspCoreo, BorderLayout.CENTER);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#update(agentviewer.ui.AgentViewerComponent)
	 */
	public void update(AgentViewerComponent avcSender)
	{
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerComponent#setMediator(agentviewer.ui.AgentViewerMediator)
	 */
	public void setMediator(AgentViewerMediator avMediator)
	{
		// TODO Auto-generated method stub
		
	}

}
