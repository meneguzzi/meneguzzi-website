/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui;

import javax.swing.JPanel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public abstract class AgentViewerPanel extends JPanel implements AgentViewerComponent
{
	protected AgentViewerKernel avKernel;
	protected JPanel jpThis;
	
	public AgentViewerPanel(AgentViewerKernel avKernel)
	{
		this.avKernel=avKernel;
		this.jpThis=this;
	}
}
