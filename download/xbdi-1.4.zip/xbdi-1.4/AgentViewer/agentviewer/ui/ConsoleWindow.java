/*
 * Created on 29/04/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui;

import java.io.IOException;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ConsoleWindow extends JInternalFrame
{
	protected ConsoleRedirector crConsole;
	
	public ConsoleWindow() throws IOException
	{
		super("Console");
			
		//this.setClosable(true);
		this.init();
		
		crConsole.redirectConsole();
		
	}
	
	private void init() throws IOException
	{
		crConsole = new ConsoleRedirector();
		
		JScrollPane jspConsole=new JScrollPane(crConsole);		
		this.getContentPane().add(jspConsole);
		
		this.setResizable(true);
		this.setIconifiable(true);
		this.setVisible(true);
		this.setSize(1000,200);
		this.setLocation(10,10);
	}
	
	public void halt()
	{
		crConsole.halt();
	}
}
