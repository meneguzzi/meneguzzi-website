/*
 * Created on 21/09/2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package agentviewer.ui;

import java.util.Properties;

import agentviewer.parser.Parser;
import agentviewer.worldmodel.WorldModel;
import agentviewer.xbdi.XBDIInterface;
import agentviewer.xbdi.XBDIStarter;
import agentviewer.xbdi.net.XBDIClientInterface;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface AgentViewerKernel
{
	public Parser getParser();
	
	public WorldModel getWorldModel();
	
	public XBDIInterface getXBDIInterface();
	public XBDIStarter getXBDIStarter();
	
	public void setXBDIClientInterface(XBDIClientInterface xClient);
	public XBDIClientInterface getXBDIClientInterface();
	
	public Properties getOptions();
}
