/*
 * Created on 29/04/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui;

import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import se.sics.jasper.SPException;
import agentviewer.config.AgentViewerConfiguration;
import agentviewer.parser.Parser;
import agentviewer.ui.options.AgentViewerOptionsDialog;
import agentviewer.ui.worldmodel.InterfaceWorldModel;
import agentviewer.ui.worldmodel.WorldModelWindow;
import agentviewer.ui.xbdi.XBDIFrontend;
import agentviewer.ui.xbdi.XBDISocketFrontend;
import agentviewer.worldmodel.WorldModel;
import agentviewer.xbdi.RuntimeXBDIStarter;
import agentviewer.xbdi.XBDIInterface;
import agentviewer.xbdi.XBDIStarter;
import agentviewer.xbdi.net.XBDIClientInterface;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AgentViewerMainWindow extends JFrame implements AgentViewerKernel
{
	/** The desktop panel where the function windows are placed.*/
	protected JDesktopPane jdpMainPanel;
	/** The console window where print lines are displayed.*/
	protected ConsoleWindow cvConsole;
	/** The Menu Bar used in the program.*/
	protected AgentViewerMenu avmMenu;
	
	/** A frontend interface for the XBDIStarter.*/
	protected XBDIFrontend xbdiFrontend;
	/** A frontend interface for the XBDIClientInterface communication class.*/
	protected XBDISocketFrontend xsfClient;
	/** The interface for XBDI itself*/
	protected XBDIStarter xbdi;
	/** The interface to an XBDI client*/
	protected XBDIClientInterface xClient;

	/** The dialog where options are set.*/
	protected AgentViewerOptionsDialog avOptions;
	/** The global options class.*/
	private Properties pOptions;
	
	/**	The parser used throughout the system.*/
	private Parser parser;
	
	/** The interface to the world model.*/
	protected WorldModelWindow wmWindow;
	/** The current worldmodel.*/
	private WorldModel wmWorld;

	public AgentViewerMainWindow() throws IOException, SPException
	{
		super("AgentViewer");

		this.initKernel();
		this.init();
	}
	
	private void initKernel() throws IOException
	{
		pOptions = AgentViewerConfiguration.readProperties();
		
		//agentviewer.xbdi = new JasperXBDIStarter(pOptions.getProperty("sicstus.path"), 
		//						pOptions.getProperty("xbdi.path"), 
		//						pOptions.getProperty("xbdi.file"));

		xbdi = new RuntimeXBDIStarter(pOptions.getProperty("sicstus.path"), 
										pOptions.getProperty("xbdi.path"), 
										pOptions.getProperty("xbdi.file"));
		
		//this.wmWorld=new ConcreteWorldModel();
		this.wmWorld=new InterfaceWorldModel();
		this.parser=new Parser();
	}

	private void init() throws IOException
	{
		jdpMainPanel = new JDesktopPane();
		this.setContentPane(jdpMainPanel);

		cvConsole = new ConsoleWindow();
		this.getContentPane().add(cvConsole);
		cvConsole.setLocation(0, 620);

		xbdiFrontend = new XBDIFrontend(this);
		this.getContentPane().add(xbdiFrontend);
		xbdiFrontend.setLocation(400, 10);
		
		xsfClient = new XBDISocketFrontend(this);
		this.getContentPane().add(xsfClient);
		xsfClient.setLocation(450, 150);
		
		wmWindow = new WorldModelWindow(this);
		this.getContentPane().add(wmWindow);
		wmWindow.setLocation(350, 300);

		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent evt)
			{
				xbdi=null;
				cvConsole.halt();
				cvConsole=null;
				System.runFinalization();
				System.exit(1);
			}
		});
		
		avmMenu = new AgentViewerMenu();
		this.setJMenuBar(avmMenu);
		
		avOptions = new AgentViewerOptionsDialog(this, this);

		this.setSize(Toolkit.getDefaultToolkit().getScreenSize());
		this.setMaximizedBounds(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		//this.setSize(800,600);
		this.show();
		
	}

	private class AgentViewerMenu extends JMenuBar
	{
		private JMenu jmOptionsMenu;
		private JMenuItem jmiOptions;
		
		public AgentViewerMenu()
		{
			jmOptionsMenu = new JMenu("Options");
			jmiOptions = new JMenuItem("AgentViewer Options");
			ActionListener alOptionsMenu=new ActionListener(){
				public void actionPerformed(ActionEvent arg0){
					AgentViewerMainWindow.this.avOptions.show();
				}
			};
			
			jmiOptions.addActionListener(alOptionsMenu);
			
			jmOptionsMenu.add(jmiOptions);
			this.add(jmOptionsMenu);
		}
	}
	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#getParser()
	 */
	public Parser getParser()
	{
		return this.parser;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#getWorldModel()
	 */
	public WorldModel getWorldModel()
	{
		return wmWorld;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#getXBDIInterface()
	 */
	public XBDIInterface getXBDIInterface()
	{
		return this.xbdi;
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#getXBDIStarter()
	 */
	public XBDIStarter getXBDIStarter()
	{
		return this.xbdi;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#getXBDIClientInterface()
	 */
	public XBDIClientInterface getXBDIClientInterface()
	{
		return xClient;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#getOptions()
	 */
	public Properties getOptions()
	{
		return this.pOptions;
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.AgentViewerKernel#setXBDIClientInterface(agentviewer.xbdi.net.XBDIClientInterface)
	 */
	public void setXBDIClientInterface(XBDIClientInterface xClient)
	{
		this.xClient=xClient;		
	}
}
