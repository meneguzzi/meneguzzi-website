/*
 * Created on 03/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.options;

import java.awt.GridLayout;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JTextArea;

import agentviewer.config.AgentViewerConfiguration;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class JXBDIClientOptions extends JOptionsPane
{
	protected JTextArea jtaServerHost;
	protected JTextArea jtaServerPort;

	/**
	 * @param pOptions
	 */
	public JXBDIClientOptions(Properties pOptions)
	{
		super(pOptions);
		this.init();
	}
	
	private void init()
	{
		JLabel jlServerHost = new JLabel("XBDI Client Host: ");
		jtaServerHost = new JTextArea(pOptions.getProperty(AgentViewerConfiguration.XBDI_CLIENT_HOST_PROPERTY));
		
		JLabel jlServerPort = new JLabel("XBDI Client Port: ");
		jtaServerPort = new JTextArea(pOptions.getProperty(AgentViewerConfiguration.XBDI_CLIENT_PORT_PROPERTY));
		
		this.setLayout(new GridLayout(3,2));
		
		this.add(jlServerHost);
		this.add(jtaServerHost);
		this.add(jlServerPort);
		this.add(jtaServerPort);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.options.JOptionsPane#setOptions()
	 */
	public void setOptions()
	{
		pOptions.setProperty(AgentViewerConfiguration.XBDI_CLIENT_HOST_PROPERTY, jtaServerHost.getText());
		pOptions.setProperty(AgentViewerConfiguration.XBDI_CLIENT_PORT_PROPERTY, jtaServerPort.getText());
	}

}
