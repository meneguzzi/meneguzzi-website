/*
 * Created on 03/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.options;

import java.util.Properties;

import javax.swing.JPanel;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public abstract class JOptionsPane extends JPanel
{
	protected Properties pOptions;
	
	public JOptionsPane(Properties pOptions)
	{
		this.pOptions=pOptions;
	}
	
	public abstract void setOptions();
	
}
