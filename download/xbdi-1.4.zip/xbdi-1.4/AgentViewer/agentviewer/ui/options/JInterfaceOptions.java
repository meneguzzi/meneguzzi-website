/*
 * Created on 25/09/2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package agentviewer.ui.options;

import java.awt.GridLayout;
import java.util.Properties;

import javax.swing.JCheckBox;

import agentviewer.config.AgentViewerConfiguration;

/**
 * @author felipe
 */
public class JInterfaceOptions extends JOptionsPane
{
	protected JCheckBox jcbSensor;

	/**
	 * @param pOptions
	 */
	public JInterfaceOptions(Properties pOptions)
	{
		super(pOptions);
		this.init();
	}

	private void init()
	{
		boolean bSensor=Boolean.valueOf(pOptions.getProperty(AgentViewerConfiguration.SENSOR_WINDOW_PROPERTY)).booleanValue();
		this.jcbSensor = new JCheckBox("Display Sensor Window",bSensor);
		
		this.setLayout(new GridLayout(1, 2));

		this.add(jcbSensor);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.options.JOptionsPane#setOptions()
	 */
	public void setOptions()
	{
		pOptions.setProperty(
			AgentViewerConfiguration.SENSOR_WINDOW_PROPERTY,
			Boolean.toString(jcbSensor.isSelected()));
	}

}
