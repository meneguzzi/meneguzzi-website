/*
 * Created on 03/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.options;

import java.awt.GridLayout;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JTextField;

import agentviewer.config.AgentViewerConfiguration;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class JXBDIOptions extends JOptionsPane
{
	protected JTextField jtfXBDIFile;
	protected JTextField jtfXBDIPath;
	protected JTextField jtfServerPort;
		
	public JXBDIOptions(Properties pOptions)
	{
		super(pOptions);
		this.init();
	}
	
	private void init()
	{
		JLabel jlXBDIPath = new JLabel("XBDI Path: ");
		jtfXBDIPath = new JTextField(pOptions.getProperty(AgentViewerConfiguration.XBDI_PATH_PROPERTY));
		
		JLabel jlXBDIFile=new JLabel("XBDI File: ");
		jtfXBDIFile = new JTextField(pOptions.getProperty(AgentViewerConfiguration.XBDI_FILE_PROPERTY));
		
		JLabel jlServerPort=new JLabel("XBDI Server Port:");
		jtfServerPort = new JTextField(pOptions.getProperty(AgentViewerConfiguration.XBDI_PORT_PROPERTY));
		
		this.setLayout(new GridLayout(3,2));
		this.add(jlXBDIPath);
		this.add(jtfXBDIPath);
		this.add(jlXBDIFile);
		this.add(jtfXBDIFile);
		this.add(jlServerPort);
		this.add(jtfServerPort);
	}
	
	/* (non-Javadoc)
	 * @see agentviewer.ui.options.JOptionsPane#setOptions(java.util.Properties)
	 */
	public void setOptions()
	{
		pOptions.setProperty(AgentViewerConfiguration.XBDI_PATH_PROPERTY, jtfXBDIPath.getText());
		pOptions.setProperty(AgentViewerConfiguration.XBDI_FILE_PROPERTY, jtfXBDIFile.getText());
		pOptions.setProperty(AgentViewerConfiguration.XBDI_PORT_PROPERTY, jtfServerPort.getText());
	}

}
