/*
 * Created on 03/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.options;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import agentviewer.config.AgentViewerConfiguration;
import agentviewer.ui.AgentViewerKernel;
import agentviewer.ui.dialog.AgentViewerDialog;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class AgentViewerOptionsDialog extends AgentViewerDialog
{
	protected JTabbedPane jtpOptionTypes;
	protected JPanel jpButtons;
	protected JButton jbOk;
	protected JButton jbCancel;
	protected JButton jbApply;

	protected Vector vOptionPanes;

	public AgentViewerOptionsDialog(AgentViewerKernel avKernel, Frame fOwner)
	{
		super(avKernel, fOwner, true);
		vOptionPanes = new Vector();
		this.init();
	}

	private void init()
	{
		jtpOptionTypes = new JTabbedPane();

		JOptionsPane jopGeneral = new JGeneralOptions(avKernel.getOptions());
		vOptionPanes.add(jopGeneral);
		jtpOptionTypes.addTab("General", null, jopGeneral, "General Options");

		JOptionsPane jopXBDI = new JXBDIOptions(avKernel.getOptions());
		vOptionPanes.add(jopXBDI);
		jtpOptionTypes.addTab(
			"XBDI",
			null,
			jopXBDI,
			"Locally running XBDI Options");

		JOptionsPane jopXBDIClient = new JXBDIClientOptions(avKernel.getOptions());
		vOptionPanes.add(jopXBDIClient);
		jtpOptionTypes.addTab(
			"XBDI Client",
			null,
			jopXBDIClient,
			"XBDI Socket Client Options");
		
		JOptionsPane jopInterface = new JInterfaceOptions(avKernel.getOptions());
		vOptionPanes.add(jopInterface);
		jtpOptionTypes.addTab("UI Options",null,jopInterface,"User Interface Options");

		jbOk = new JButton("OK");
		ActionListener alOk = new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				applyChanges();
				AgentViewerOptionsDialog.this.setVisible(false);
			}
		};
		jbOk.addActionListener(alOk);
		
		jbCancel = new JButton("Cancel");
		ActionListener alCancel = new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				AgentViewerOptionsDialog.this.setVisible(false);
			}
		};
		jbCancel.addActionListener(alCancel);


		jbApply = new JButton("Apply");
		ActionListener alApply = new ActionListener(){
			public void actionPerformed(ActionEvent arg0){
				applyChanges();
			}
		};
		jbApply.addActionListener(alApply);

		jpButtons = new JPanel();
		jpButtons.setLayout(new FlowLayout(FlowLayout.RIGHT));
		jpButtons.add(jbOk);
		jpButtons.add(jbCancel);
		jpButtons.add(jbApply);
		
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(jtpOptionTypes, BorderLayout.CENTER);
		this.getContentPane().add(jpButtons, BorderLayout.SOUTH);
		
		this.setSize(400,200);
		this.setLocation(400, 300);
	}

	private void applyChanges()
	{
		for (Iterator i = vOptionPanes.iterator(); i.hasNext();)
		{
			JOptionsPane jop = (JOptionsPane)i.next();
			jop.setOptions();
			try
			{
				avKernel.getOptions().store(new FileOutputStream(AgentViewerConfiguration.DEFAULT_PROPERTY_FILE),"Agent Viewer Options");
			} catch (FileNotFoundException e)
			{
				System.err.println("Could not write options: "+e.getMessage());
				//e.printStackTrace();
			} catch (IOException e)
			{
				System.err.println("Could not write options: "+e.getMessage());
				//e.printStackTrace();
			}
		}
	}
}
