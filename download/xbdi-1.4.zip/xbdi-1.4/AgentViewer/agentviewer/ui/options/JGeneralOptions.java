/*
 * Created on 03/05/2003
 *
 * To change the template for this generated file go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package agentviewer.ui.options;

import java.awt.GridLayout;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JTextField;

import agentviewer.config.AgentViewerConfiguration;

/**
 * @author Felipe
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class JGeneralOptions extends JOptionsPane
{
	protected JTextField jtfSICStusPath;
	
	protected JTextField jtfAgentPath;
	protected JTextField jtfCoreoPath;

	/**
	 * @param pOptions
	 */
	public JGeneralOptions(Properties pOptions)
	{
		super(pOptions);
		this.init();
	}
	
	private void init()
	{
		JLabel jlSICStusPath = new JLabel("SICStus path: "); 
		jtfSICStusPath = new JTextField(pOptions.getProperty(AgentViewerConfiguration.SICSTUS_PATH_PROPERTY));
		
		JLabel jlAgentPath = new JLabel("Agent search path: "); 
		jtfAgentPath = new JTextField(pOptions.getProperty(AgentViewerConfiguration.AGENT_PATH_PROPERTY));
		
		JLabel jlCoreoPath = new JLabel("Coreography search path: "); 
		jtfCoreoPath = new JTextField(pOptions.getProperty(AgentViewerConfiguration.COREO_PATH_PROPERTY));
		
		this.setLayout(new GridLayout(3,2));
		
		this.add(jlSICStusPath);
		this.add(jtfSICStusPath);
		this.add(jlAgentPath);
		this.add(jtfAgentPath);
		this.add(jlCoreoPath);
		this.add(jtfCoreoPath);
	}

	/* (non-Javadoc)
	 * @see agentviewer.ui.options.JOptionsPane#setOptions()
	 */
	public void setOptions()
	{
		pOptions.setProperty(AgentViewerConfiguration.SICSTUS_PATH_PROPERTY, jtfSICStusPath.getText());
		pOptions.setProperty(AgentViewerConfiguration.AGENT_PATH_PROPERTY, jtfAgentPath.getText());
		pOptions.setProperty(AgentViewerConfiguration.COREO_PATH_PROPERTY, jtfCoreoPath.getText());
	}

}
