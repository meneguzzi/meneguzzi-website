#ifndef CONSOLEOUT_H
#define CONSOLEOUT_H

#include<iostream>
using std::cout;
using std::cin;
using std::endl;

#define WRITE(T) cout<<T
#define WRITELN(T) cout<<T<<endl

#endif
