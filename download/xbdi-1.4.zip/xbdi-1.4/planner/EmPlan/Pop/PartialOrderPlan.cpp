// Plan.cpp: implementation of the Plan class.
//
//////////////////////////////////////////////////////////////////////

#include "PartialOrderPlan.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

RobinsonUnify PartialOrderPlan::unification;

PartialOrderPlan::PartialOrderPlan(PredicateVector pvStart, PredicateVector pvGoal)
{
	PredicateVector pvEmpty;
	TermVector dvEmpty;

	this->oStart=new Operator("start", dvEmpty, pvEmpty, pvStart, true, false);
	this->oGoal=new Operator("goal", dvEmpty, pvGoal, pvEmpty, true, false);
	
	ovSteps.push_back(oStart);
	ovSteps.push_back(oGoal);
		
	olvOrder.push_back(new OrderLink(oStart, oGoal));
}

PartialOrderPlan::~PartialOrderPlan()
{
	for(OperatorVector::iterator i=ovSteps.begin(); i!=ovSteps.end(); i++)
	{
		delete *i;
	}
}

//According to "http://www.cs.wisc.edu/~dyer/cs540/notes/pop.html", 
//if there is no CausalLink to a given precondition, then this precondition
//has not been dealt with, therefore, the plan is not complete

//This mehtod not only determines if the plan is complete or not, but it "calculates"
//the difference between the current plan, and the goal state
bool PartialOrderPlan::isSolution()
{
	bool bRes=true;
	this->omUnfulfilled.clear();
	//return this->pvOpen->size()==0;
	for(OperatorVector::iterator i=ovSteps.begin(); i!=ovSteps.end(); i++)
	{
		Operator *o=(*i);
		PredicateVector pvPreconds=o->getPreconds();
		for(PredicateVector::iterator j=pvPreconds.begin(); j!=pvPreconds.end(); j++)
		{
			Predicate *p=(*j);
			bool bHasCausalLink=false;
			for(CausalLinkVector::iterator k=clvCauses.begin(); k!=clvCauses.end(); k++)
			{
				if((*k)->caused(p))
					bHasCausalLink=true;
			}
			if(!bHasCausalLink)
			{
				this->omUnfulfilled[p]=o;
				bRes=false;
			}
		}
	}

	return bRes;
}


//Adds predicates to the list of Open-predicates, checking if these are not already in the start state
/*void Plan::addOpenPredicates(PredicateVector *pv)
{
	PredicateVector *pvStart=oStart->getEffects();

 	for(PredicateVector::iterator i=pv->begin(); i!=pv->end(); i++)
 	{
		for(PredicateVector::iterator j=pvStart->begin(); j!=pvStart->end(); j++)
		{
			if(unification.unifyPredicates(*i, *j))
				this->pvOpen->push_back(*i);
		}
 	}
}*/

Predicate *PartialOrderPlan::selectSubgoal()
{
	Predicate *pRes;
	if(this->omUnfulfilled.size()>0)
	{
		//Looks weird, but it gets the first field(index) of the first element (the begin iterator)
		//in the Map
		pRes= omUnfulfilled.begin()->first;
	}else
		pRes=NULL;

	return pRes;
}

Operator * PartialOrderPlan::getOperatorFromGoal(Predicate *p)
{
	return omUnfulfilled[p];
}

bool PartialOrderPlan::chooseOperator(Predicate *pCause, Operator *oCause, OperatorVector ovOps)
{
	Operator *oNew;

	bool bOperatorFound=false;
	bool bNewOperator=false;

	PRINTL("Resolving sub-goal: " << pCause->toString())

	//First, try to find a step within the plan that may satisty the goal
	for(OperatorVector::iterator i=ovSteps.begin(); (i!=ovSteps.end() && !bOperatorFound); i++)
	{
		oNew=(*i);
		PredicateVector pvEffects=oNew->getEffects();

		for(PredicateVector::iterator j=pvEffects.begin(); (j!=pvEffects.end() && !bOperatorFound); j++)
		{
			Predicate *p=(*j);
			if((pCause->isNegative()==p->isNegative()) && unification.unifyPredicates(pCause, p))
			{
				PRINTL("Resolved "<< pCause->toString() <<" through: " << p->toString() << endl)
				bOperatorFound=true;
			}
		}
	}

	for(OperatorVector::iterator i2=ovOps.begin(); (i2!=ovOps.end() && !bOperatorFound); i2++)
	{
		oNew=new Operator(*i2);
		//PRINTL(o->toString())
		PredicateVector pvEffects=oNew->getEffects();

		for(PredicateVector::iterator j=pvEffects.begin(); (j!=pvEffects.end() && !bOperatorFound); j++)
		{
			Predicate *p=(*j);
			if((pCause->isNegative()==p->isNegative()) && unification.unifyPredicates(pCause, p))
			{
				PRINTL("Resolved "<< pCause->toString() <<" through: " << p->toString() << endl)
				bOperatorFound=true;
				bNewOperator=true;
			}
		}
		
		if(!bOperatorFound)
		{
			//PRINTL(o->toString())
			delete oNew;
			oNew=NULL;
		}
	}

	if(bOperatorFound)
	{
		PRINTL("Choosen operator "<< oNew->toString() << endl)
		CausalLink *cl=new CausalLink(pCause, oNew, oCause);
		clvCauses.push_back(cl);
		
		OrderLink *ol=new OrderLink(oNew, oCause);
		olvOrder.push_back(ol);
		if(bNewOperator)
		{
			this->ovSteps.push_back(oNew);
			
			ol=new OrderLink(oNew, oGoal);
			olvOrder.push_back(ol);
			ol=new OrderLink(oStart, oNew);
			olvOrder.push_back(ol);
		}
	}

	return bOperatorFound;
}

string PartialOrderPlan::toString()
{
	string sRes="Plan: ";
	for(OperatorVector::iterator i=ovSteps.begin(); i!=ovSteps.end(); i++)
	{
		Operator *o=*i;
		sRes+="\n"+o->toString();
	}

	return sRes;
}

//Old style
/*bool Plan::resolveThreats()
{
	bool bRes = true;
	for(OperatorVector::iterator i=ovSteps->begin(); i!=ovSteps->end(); i++)
	{
		Operator *o=*i;
		for(CausalLinkVector::iterator j=clvCauses->begin(); j!=clvCauses->end(); j++)
		{
			CausalLink *cl=*j;
			if(cl->getStep1()==o || cl->getStep2()==o)
				continue;

			PredicateVector *pv=cl->getStep1()->getEffects();

			//Try to find a threatening predicate
			for(PredicateVector::iterator k=pv->begin(); k!=pv->end(); k++)
			{
				//A threat was detected
				if(o->threatened(*k))
				{//Then deal with it
					//Either promote the step, or demote it
					PRINTL("Threat detected!!")
				}
			}

		}
	}

	return bRes;
}*/

bool PartialOrderPlan::resolveThreats()
{
	bool bRes = true;
	for(OperatorVector::iterator i=ovSteps.begin(); i!=ovSteps.end(); i++)
	{
		Operator *o=*i;
		for(OperatorVector::iterator j=ovSteps.begin(); j!=ovSteps.end(); j++)
		{
			Operator *oThreat=*j;
			if(oThreat==o)
				continue;

			PredicateVector pv=oThreat->getEffects();

			//Try to find a threatening predicate
			for(PredicateVector::iterator k=pv.begin(); k!=pv.end(); k++)
			{
				//A threat was detected
				if(o->threatened(*k))
				{//Then deal with it
					//Either promote the step, or demote it
					PRINTL("Threat detected!!")
				}
			}

		}
	}

	return bRes;
}

OperatorVector PartialOrderPlan::getStepSequence()
{
	OperatorVector ovPlan;

	ovPlan.resize(this->ovSteps.size());

	ovPlan[0]=this->oStart;
	ovPlan[ovPlan.size()-1]=oGoal;

	for(OperatorVector::iterator i=ovSteps.begin(); i!=ovSteps.end(); i++)
	{

		for(OrderLinkVector::iterator j=olvOrder.begin(); j!=olvOrder.end(); j++)
		{
		
		}
	}

	return ovPlan;
}
