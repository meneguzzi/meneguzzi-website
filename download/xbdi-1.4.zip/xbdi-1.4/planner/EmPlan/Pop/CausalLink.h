// ausalLink.h: interface for the CausalLink class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUSALLINK_H__B9038E45_82D2_49A4_8CD4_8A1106920F1C__INCLUDED_)
#define AFX_AUSALLINK_H__B9038E45_82D2_49A4_8CD4_8A1106920F1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Predicate.h"
#include "Term.h"
#include "Operator.h"

#include <vector>
using std::vector;

#include <string>
using std::string;

class CausalLink  
{
protected:
	Predicate *pPrecond;
	Operator *oStep1;
	Operator *oStep2;
public:
	Operator * getStep2();
	Operator * getStep1();
	bool caused(Predicate *p);
	CausalLink(Predicate *pPrecond, Operator *oStep1, Operator *oStep2);
	virtual ~CausalLink();

	string toString();
};

typedef vector<CausalLink *> CausalLinkVector;

#endif // !defined(AFX_AUSALLINK_H__B9038E45_82D2_49A4_8CD4_8A1106920F1C__INCLUDED_)
