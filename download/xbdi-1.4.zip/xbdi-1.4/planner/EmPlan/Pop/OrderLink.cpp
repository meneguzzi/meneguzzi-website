// OrderLink.cpp: implementation of the OrderLink class.
//
//////////////////////////////////////////////////////////////////////

#include "OrderLink.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

OrderLink::OrderLink(Operator *oBefore, Operator *oAfter)
{
	this->oBefore=oBefore;
	this->oAfter=oAfter;
}

OrderLink::~OrderLink()
{

}

bool OrderLink::before(Operator *o1, Operator *o2)
{
	return (o1==this->oBefore && o2==this->oAfter);
}
