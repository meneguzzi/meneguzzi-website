// RobinsonUnify.h: interface for the RobinsonUnify class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ROBINSONUNIFY_H__97258EDD_AACA_48F5_A26B_6A4B24A80B59__INCLUDED_)
#define AFX_ROBINSONUNIFY_H__97258EDD_AACA_48F5_A26B_6A4B24A80B59__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "UnificationAlgorithm.h"
#include "Predicate.h"
#include "Term.h"

#include "Debug.h"

class RobinsonUnify : public UnificationAlgorithm  
{
protected:
	bool mergeVariables(TermMap *dnm1, TermMap *dnm2);
	bool unify(Term *k1, Term *k2);
	Term *dn1, *dn2;
	TermMap *dnmVariables;
public:
	RobinsonUnify();
	virtual ~RobinsonUnify();

	virtual bool unifyPredicates(Predicate *p1, Predicate *p2);
	Term *getUnifiedNode();
	Term *getUnifiedNode2();
};

#endif // !defined(AFX_ROBINSONUNIFY_H__97258EDD_AACA_48F5_A26B_6A4B24A80B59__INCLUDED_)
