// Substitution.h: interface for the Substitution class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(SUBSTITUTION_H)
#define SUBSTITUTION_H

#include "Predicate.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <map>
using std::map;
using std::less;

//typedef map<string, Term, less<string>> BindingMap;

//typedef map<string, Symbol *, less<string> > MSymbols;

class Substitution
{
protected:
	//BindingMap bmBindings();
public:
	Predicate applySubstitution(const Predicate &p);
	Substitution();
	virtual ~Substitution();

	void addSubstitution(string sVariable, const Term &t);

	const Substitution &operator=(const Substitution &sRight);

};

#endif // !defined(SUBSTITUTION_H)
