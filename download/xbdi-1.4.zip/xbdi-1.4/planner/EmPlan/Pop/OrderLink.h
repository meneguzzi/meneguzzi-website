// OrderLink.h: interface for the OrderLink class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ORDERLINK_H__800B6AD5_834D_4783_890B_44B9E46B500C__INCLUDED_)
#define AFX_ORDERLINK_H__800B6AD5_834D_4783_890B_44B9E46B500C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Operator.h"

#include <vector>
using std::vector;

class OrderLink  
{
protected:
	Operator *oBefore;
	Operator *oAfter;
public:
	bool before(Operator *o1, Operator *o2);
	OrderLink(Operator *oBefore, Operator *oAfter);
	virtual ~OrderLink();

};

typedef vector<OrderLink *> OrderLinkVector;

#endif // !defined(AFX_ORDERLINK_H__800B6AD5_834D_4783_890B_44B9E46B500C__INCLUDED_)
