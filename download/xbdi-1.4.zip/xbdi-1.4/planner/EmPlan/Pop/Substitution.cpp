// Substitution.cpp: implementation of the Substitution class.
//
//////////////////////////////////////////////////////////////////////

#include "Substitution.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Substitution::Substitution()
{

}

Substitution::~Substitution()
{

}

Predicate Substitution::applySubstitution(const Predicate &p)
{
	//Predicate pRes;
	
	return p;
}

const Substitution &Substitution::operator=(const Substitution &sRight)
{
	if(this != &sRight)
	{
		//do stuff here
		//this->bmBindings=sRight.bmBindings;
	}

	return *this;
}

void Substitution::addSubstitution(string sVariable, const Term &t)
{
	//bmBindings[sVariable]=t;
}