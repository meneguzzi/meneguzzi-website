#ifndef WYACC_H
#define WYACC_H

/************************************************************
wyacc.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yywpars.h>

#endif
