#ifndef WCYACC_H
#define WCYACC_H

/************************************************************
wcyacc.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yywcpars.h>

#endif
