#ifndef MLEX_H
#define MLEX_H

/************************************************************
mlex.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yymlex.h>

#endif
