#ifndef CYACC_H
#define CYACC_H

/************************************************************
cyacc.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yycpars.h>

#endif
