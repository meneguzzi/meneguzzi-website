#ifndef MYACC_H
#define MYACC_H

/************************************************************
myacc.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yympars.h>

#endif
