#ifndef WMYACC_H
#define WMYACC_H

/************************************************************
wmyacc.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yywmpars.h>

#endif
