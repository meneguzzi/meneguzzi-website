#ifndef WLEX_H
#define WLEX_H

/************************************************************
wlex.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yywlex.h>

#endif
