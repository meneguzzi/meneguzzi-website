#ifndef YACC_H
#define YACC_H

/************************************************************
yacc.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yypars.h>

#endif
