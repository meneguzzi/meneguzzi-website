#ifndef CLEX_H
#define CLEX_H

/************************************************************
clex.h
This file can be freely modified for the generation of
custom code.

Copyright (c) 1999-2003 Bumble-Bee Software Ltd.
************************************************************/

#include <yyclex.h>

#endif
