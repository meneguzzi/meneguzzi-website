unknown_predicate_handler(G, U, fail) :- 	nl, nl,
							write('Predicate '),
							write(G),
							write(' failed!!!'),
							nl,nl.

:- dynamic modo/1.
:- dynamic agentfile/1.
:- dynamic coreofile/1.
:- dynamic planner/1.
:- dynamic xbdiport/1.
:- dynamic xbdihost/1.
:- dynamic current_time/1.

:- use_module(library(system)).
:- use_module(library(socket)).
%:- consult('sockets').
%:- consult('system').

:- consult('planner').
:- consult('v24_paulo/boot').
%:- consult('slx/boot').
:- consult('kernel_parser').
:- consult('kernel_coreo').
:- consult('kernel_revise').
:- consult('kernel_sockets').

initXBDI2 :- 	clean_environment,
			clean_rules,
			clean_triggers,
			clean_seeds,
			clean_inconsis_rules_source,
			%reset_defaults_config,
			read_file('eventc.plx'),
			%config_xbdi,
			current_time(Tempo),
			call_process_term(current_time(Tempo)),
			agentfile(Arq),
			parse(Arq),
			modo(Mode),
			generate_int_file([]),
			goXBDI(Mode).

initXBDI :- 	clean_environment,
			clean_rules,
			clean_triggers,
			clean_seeds,
			clean_inconsis_rules_source,
			reset_defaults_config,
			read_file('eventc.plx'),
			config_xbdi, displayconfig,
			current_time(Tempo),
			call_process_term(current_time(Tempo)),
			agentfile(Arq),
			parse(Arq),
			modo(Mode),
			generate_int_file([]),
			goXBDI(Mode).

goXBDI(coreografia) :-	revise_intentions,
				coreofile(Arq),
				coreo(Arq).
goXBDI(kernel)	:-	revise_intentions,
				kernel.

/********
* Config. default
********/
/** modo(kernel|coreografia) **/
modo(coreografia).
/** agentfile('nome.bdi').**/
agentfile('x-bdi.bdi').
/** coreofile('nome.sen') **/
coreofile('x-bdi.sen').
/** current_time(Valor)  **/
current_time(1).
/** xbdiport(Value) **/
xbdiport(6666).
/** xbdihost(name) **/
xbdihost('localhost').
/** planner(internal|external) **/
planner(internal).

reset_defaults_config :-
	retract(modo(_)),
	assert(modo(coreografia)),
	retract(agentfile(_)),
	assert(agentfile('x-bdi.bdi')),
	retract(coreofile(_)),
	assert(coreofile('x-bdi.sen')),
	retract(current_time(_)),
	assert(current_time(1)),
	retract(xbdiport(_)),
	assert(xbdiport(6666)),
	retract(xbdihost(_)),
	assert(xbdihost('localhost')),
	retract(planner(_)),
	assert(planner(internal)).

config_xbdi :-	file_exists('xbdi.pref'),
			see('xbdi.pref'),
			read_config,
			seen.
config_xbdi.

read_config :-	repeat,
			read(Term),
			process_config_term(Term, Res),
			call(Res).
read_config.

process_config_term(end_of_file, true) :- !.
process_config_term(modo(kernel), false) :- !,
		retract(modo(_)),
		assert(modo(kernel)).
process_config_term(modo(coreografia), false) :- !,
		retract(modo(_)),
		assert(modo(coreografia)).
process_config_term(modo(_), false) :- !.
process_config_term(xbdiport(Nro), false) :- !,
		retract(xbdiport(_)),
		assert(xbdiport(Nro)).
process_config_term(xbdihost(Name), false) :- !,
		retract(xbdihost(_)),
		assert(xbdihost(Name)).
process_config_term(agentfile(Nome), false) :- !,
		retract(agentfile(_)),
		assert(agentfile(Nome)).
process_config_term(coreofile(Nome), false) :-	!, 
		retract(coreofile(_)),
		assert(coreofile(Nome)).
process_config_term(current_time(Tempo), false) :- !,
		retract(current_time(_)),
		assert(current_time(Tempo)).
process_config_term(planner(external), false) :- !,
		retract(planner(_)),
		assert(planner(external)).
process_config_term(planner(internal), false) :- !,
		retract(planner(_)),
		assert(planner(internal)).
process_config_term(planner(_), false) :- !.
process_config_term(_, false) :- !,
		nl, 
		write('***********************************'), nl,
		write('Invalid config option - ignoring...'),
		write('***********************************'), nl,
		nl, nl.

/*********
* Limpa os gatilhos  estabelecidos, os revisables
* e as regras de contradi��o, 
* para iniciar uma nova revis�o.
*************/

clean_environment :- 
	clean_revisables,
	clean_inconsis_rules,
	clean_intentions.

clean_triggers :-
	retractall(trigger(_,_)).


clean_revisables :-
	retractall(revisable(_)).

clean_inconsis_rules :-
	clause(rule(inconsistent, Rule),_,Ref),
	Rule \= (holds_at(P,T),holds_at(-P,T)),
	not_in_inconsis_rule(Rule),
      erase(Ref),
	fail.
clean_inconsis_rules.

not_in_inconsis_rule(Rule) :- 
	inconsis_rule((<- IRule)),
	IRule = Rule,
	!, fail.
not_in_inconsis_rule(_).
	

clean_inconsis_rules_source :-
	retractall(inconsis_rule(_)).

/***retract_rule(Rule) :-
		retract(rule(inconsistent, Rule)),
		!. ***/

clean_intentions :-
	clean_int_to,
	clean_int_that.

clean_int_to :-
	clause(rule(holds_at(P,_),_), _, Ref),
	nonvar(P),
	P = int_to(_, _, _),
	erase(Ref),
	fail.
clean_int_to.

clean_int_that :-
	clause(rule(holds_at(P,_),_), _, Ref),
	nonvar(P),
	P = int_that(_, _, _, _, _),
	erase(Ref),
	fail.
clean_int_that.

clean_rules :- retractall(rules(_,_)).

clean_seeds :- 
		retract(time_seed(_)),
		assert(time_seed(0)),
		retract(initial_number(_)),
		assert(initial_number(0)),
		retract(event_seed(_)),
		assert(event_seed(0)).

%Added for convenience

displayconfig :-
		modo(A), write(modo(A)),nl,
		planner(B), write(planner(B)),nl,
		agentfile(C), write(agentfile(C)),nl,
		coreofile(D), write(coreofile(D)),nl,
		xbdihost(E), write(xbdihost(E)),nl,
		xbdiport(F), write(xbdiport(F)),nl,
		current_time(G), write(current_time(G)),nl.