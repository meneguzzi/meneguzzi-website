package org.soton.orpheus.tac;

public interface TestConstants {
	public static final String TEST_AGENT_SOURCE = "test-agent.asl";
}
